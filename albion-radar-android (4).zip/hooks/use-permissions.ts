import { useEffect } from 'react';
import { Alert, Platform } from 'react-native';
import { vpnService, overlayService } from '@/lib/native/vpn-bridge';

/**
 * Hook to request VPN and overlay permissions automatically on app startup
 */
export function usePermissions() {
  useEffect(() => {
    if (Platform.OS === 'android') {
      requestPermissionsSequentially();
    }
  }, []);
}

/**
 * Request permissions sequentially
 */
async function requestPermissionsSequentially() {
  try {
    // First, request VPN permission
    console.log('Requesting VPN permission...');
    const vpnGranted = await vpnService.requestPermission();
    
    if (vpnGranted) {
      console.log('VPN permission granted');
    } else {
      console.warn('VPN permission denied');
      Alert.alert(
        'VPN Permission Required',
        'VPN permission is required for packet capture. Please enable it in system settings.'
      );
    }

    // Then, request overlay permission
    console.log('Requesting overlay permission...');
    const overlayGranted = await overlayService.requestPermission();
    
    if (overlayGranted) {
      console.log('Overlay permission granted');
    } else {
      console.warn('Overlay permission denied');
      Alert.alert(
        'Overlay Permission Required',
        'Overlay permission is required to display radar on top of the game. Please enable it in system settings.'
      );
    }
  } catch (error) {
    console.error('Error requesting permissions:', error);
  }
}
