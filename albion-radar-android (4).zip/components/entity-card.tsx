/**
 * Entity Card Component
 * Displays detailed information about resources, mobs, players, and chests
 * Follows OpenRadar UI/UX patterns with professional formatting
 */

import React from 'react';
import { View, Text, Image, Pressable } from 'react-native';
import { cn } from '@/lib/utils';

export type EntityType = 'resource' | 'mob' | 'player' | 'chest';

export interface ResourceCardData {
  type: 'resource';
  resourceType: string; // WOOD, ROCK, FIBER, HIDE, ORE
  tier: number;
  enchantment: number; // 0-4
  name: string;
  rarity: string;
  charges: number;
  maxCharges: number;
  position: { x: number; y: number };
  distance: number;
  icon?: string;
}

export interface MobCardData {
  type: 'mob';
  name: string;
  tier: number;
  category: string;
  threatLevel: 'safe' | 'caution' | 'danger' | 'extreme';
  health: number;
  maxHealth: number;
  healthPercent: number;
  position: { x: number; y: number };
  distance: number;
  avatar?: string;
}

export interface PlayerCardData {
  type: 'player';
  name: string;
  guild?: string;
  alliance?: string;
  faction?: string;
  status: 'passive' | 'faction' | 'hostile';
  position: { x: number; y: number };
  distance: number;
}

export interface ChestCardData {
  type: 'chest';
  chestType: string;
  rarity: string;
  position: { x: number; y: number };
  distance: number;
}

type EntityCardProps = ResourceCardData | MobCardData | PlayerCardData | ChestCardData;

/**
 * Get threat level color
 */
function getThreatColor(threatLevel: string): string {
  const colors: Record<string, string> = {
    safe: '#00FF88',
    caution: '#FFFF00',
    danger: '#FFA500',
    extreme: '#FF0000',
    passive: '#00FF88',
    faction: '#FFA500',
    hostile: '#FF0000',
  };
  return colors[threatLevel] || '#FFFFFF';
}

/**
 * Get rarity color
 */
function getRarityColor(rarity: string): string {
  const colors: Record<string, string> = {
    common: '#FFFFFF',
    uncommon: '#1EFF00',
    rare: '#0070DD',
    epic: '#A335EE',
    legendary: '#FF8000',
  };
  return colors[rarity] || '#FFFFFF';
}

/**
 * Format distance for display
 */
function formatDistance(distance: number): string {
  if (distance < 1000) {
    return `${Math.round(distance)}m`;
  }
  return `${(distance / 1000).toFixed(1)}km`;
}

/**
 * Resource Card Component
 */
function ResourceCard({ data }: { data: ResourceCardData }) {
  const color = getRarityColor(data.rarity);

  return (
    <Pressable
      className="bg-surface rounded-lg p-3 mb-2 border border-border"
      style={({ pressed }) => [pressed && { opacity: 0.7 }]}
    >
      <View className="flex-row items-center gap-3">
        {/* Icon */}
        <View
          className="w-12 h-12 rounded bg-background items-center justify-center"
          style={{ borderColor: color, borderWidth: 2 }}
        >
          <Text className="text-lg font-bold" style={{ color }}>
            {data.resourceType.charAt(0)}
          </Text>
        </View>

        {/* Content */}
        <View className="flex-1">
          {/* Name and Tier */}
          <Text className="text-foreground font-semibold">
            T{data.tier} {data.name}
            {data.enchantment > 0 && (
              <Text className="text-warning">.{data.enchantment}</Text>
            )}
          </Text>

          {/* Details */}
          <View className="flex-row gap-2 mt-1">
            <Text className="text-muted text-xs">{data.resourceType}</Text>
            <Text className="text-muted text-xs">•</Text>
            <Text className="text-muted text-xs">{data.rarity}</Text>
            <Text className="text-muted text-xs">•</Text>
            <Text className="text-muted text-xs">{formatDistance(data.distance)}</Text>
          </View>

          {/* Charges */}
          <View className="mt-1 bg-background rounded h-2 overflow-hidden">
            <View
              className="bg-primary h-full"
              style={{
                width: `${(data.charges / data.maxCharges) * 100}%`,
              }}
            />
          </View>
          <Text className="text-muted text-xs mt-1">
            Charges: {data.charges}/{data.maxCharges}
          </Text>
        </View>

        {/* Position */}
        <Text className="text-muted text-xs text-right">
          ({data.position.x}, {data.position.y})
        </Text>
      </View>
    </Pressable>
  );
}

/**
 * Mob Card Component
 */
function MobCard({ data }: { data: MobCardData }) {
  const color = getThreatColor(data.threatLevel);
  const healthPercent = Math.round((data.health / data.maxHealth) * 100);

  return (
    <Pressable
      className="bg-surface rounded-lg p-3 mb-2 border border-border"
      style={({ pressed }) => [pressed && { opacity: 0.7 }]}
    >
      <View className="flex-row items-center gap-3">
        {/* Avatar */}
        <View
          className="w-12 h-12 rounded bg-background items-center justify-center"
          style={{ borderColor: color, borderWidth: 2 }}
        >
          <Text className="text-lg font-bold" style={{ color }}>
            {data.category.charAt(0).toUpperCase()}
          </Text>
        </View>

        {/* Content */}
        <View className="flex-1">
          {/* Name and Category */}
          <Text className="text-foreground font-semibold" style={{ color }}>
            {data.name}
          </Text>

          {/* Details */}
          <View className="flex-row gap-2 mt-1">
            <Text className="text-muted text-xs">T{data.tier}</Text>
            <Text className="text-muted text-xs">•</Text>
            <Text className="text-muted text-xs capitalize">{data.category}</Text>
            <Text className="text-muted text-xs">•</Text>
            <Text className="text-muted text-xs">{formatDistance(data.distance)}</Text>
          </View>

          {/* Health Bar */}
          <View className="mt-1 bg-background rounded h-3 overflow-hidden">
            <View
              className="h-full"
              style={{
                width: `${healthPercent}%`,
                backgroundColor: color,
              }}
            />
          </View>
          <Text className="text-muted text-xs mt-1">
            Health: {data.health}/{data.maxHealth} ({healthPercent}%)
          </Text>
        </View>

        {/* Threat Badge */}
        <View
          className="px-2 py-1 rounded"
          style={{ backgroundColor: color, opacity: 0.2 }}
        >
          <Text className="text-xs font-semibold capitalize" style={{ color }}>
            {data.threatLevel}
          </Text>
        </View>
      </View>
    </Pressable>
  );
}

/**
 * Player Card Component
 */
function PlayerCard({ data }: { data: PlayerCardData }) {
  const color = getThreatColor(data.status);

  return (
    <Pressable
      className="bg-surface rounded-lg p-3 mb-2 border border-border"
      style={({ pressed }) => [pressed && { opacity: 0.7 }]}
    >
      <View className="flex-row items-center gap-3">
        {/* Avatar */}
        <View
          className="w-12 h-12 rounded-full bg-background items-center justify-center"
          style={{ borderColor: color, borderWidth: 2 }}
        >
          <Text className="text-lg font-bold" style={{ color }}>
            {data.name.charAt(0).toUpperCase()}
          </Text>
        </View>

        {/* Content */}
        <View className="flex-1">
          {/* Name */}
          <Text className="text-foreground font-semibold" style={{ color }}>
            {data.name}
          </Text>

          {/* Guild/Alliance */}
          {(data.guild || data.alliance) && (
            <Text className="text-muted text-xs">
              {data.guild && `[${data.guild}]`}
              {data.alliance && ` ${data.alliance}`}
            </Text>
          )}

          {/* Details */}
          <View className="flex-row gap-2 mt-1">
            {data.faction && (
              <>
                <Text className="text-muted text-xs">{data.faction}</Text>
                <Text className="text-muted text-xs">•</Text>
              </>
            )}
            <Text className="text-muted text-xs">{formatDistance(data.distance)}</Text>
          </View>
        </View>

        {/* Status Badge */}
        <View
          className="px-2 py-1 rounded"
          style={{ backgroundColor: color, opacity: 0.2 }}
        >
          <Text className="text-xs font-semibold capitalize" style={{ color }}>
            {data.status}
          </Text>
        </View>
      </View>
    </Pressable>
  );
}

/**
 * Chest Card Component
 */
function ChestCard({ data }: { data: ChestCardData }) {
  const color = getRarityColor(data.rarity);

  return (
    <Pressable
      className="bg-surface rounded-lg p-3 mb-2 border border-border"
      style={({ pressed }) => [pressed && { opacity: 0.7 }]}
    >
      <View className="flex-row items-center gap-3">
        {/* Icon */}
        <View
          className="w-12 h-12 rounded bg-background items-center justify-center"
          style={{ borderColor: color, borderWidth: 2 }}
        >
          <Text className="text-lg" style={{ color }}>
            📦
          </Text>
        </View>

        {/* Content */}
        <View className="flex-1">
          {/* Name */}
          <Text className="text-foreground font-semibold">
            {data.chestType} Chest
          </Text>

          {/* Details */}
          <View className="flex-row gap-2 mt-1">
            <Text className="text-muted text-xs capitalize">{data.rarity}</Text>
            <Text className="text-muted text-xs">•</Text>
            <Text className="text-muted text-xs">{formatDistance(data.distance)}</Text>
          </View>
        </View>

        {/* Position */}
        <Text className="text-muted text-xs text-right">
          ({data.position.x}, {data.position.y})
        </Text>
      </View>
    </Pressable>
  );
}

/**
 * Main Entity Card Component
 */
export function EntityCard(props: EntityCardProps) {
  switch (props.type) {
    case 'resource':
      return <ResourceCard data={props} />;
    case 'mob':
      return <MobCard data={props} />;
    case 'player':
      return <PlayerCard data={props} />;
    case 'chest':
      return <ChestCard data={props} />;
    default:
      return null;
  }
}

export default EntityCard;
