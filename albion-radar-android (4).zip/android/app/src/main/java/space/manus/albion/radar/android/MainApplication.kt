package space.manus.albion.radar.android

import android.app.Application
import android.util.Log
import com.facebook.react.PackageList
import com.facebook.react.ReactApplication
import com.facebook.react.ReactNativeHost
import com.facebook.react.ReactPackage
import com.facebook.react.shell.MainReactPackage
import com.facebook.soloader.SoLoader
import expo.modules.core.interfaces.Package
import space.manus.albion.radar.android.vpn.AlbionVpnServiceModule
import space.manus.albion.radar.android.overlay.OverlayModule

/**
 * Main Application class for Albion Online Radar
 */
class MainApplication : Application(), ReactApplication {
    companion object {
        private const val TAG = "MainApplication"
    }

    private val mReactNativeHost = object : ReactNativeHost(this) {
        override fun getPackages(): List<ReactPackage> {
            val packages = PackageList(this).packages
            packages.add(MainReactPackage())
            packages.add(AlbionRadarPackage())
            return packages
        }

        override fun getJSMainModuleName(): String = "index"

        override fun getUseDeveloperSupport(): Boolean = BuildConfig.DEBUG

        override fun getRedirectUrl(): String? = null
    }

    override fun getReactNativeHost(): ReactNativeHost = mReactNativeHost

    override fun onCreate() {
        super.onCreate()
        Log.d(TAG, "MainApplication created")
        
        SoLoader.init(this, false)
        
        if (BuildConfig.DEBUG) {
            Log.d(TAG, "Debug mode enabled")
        }
    }
}

/**
 * Custom React Package for Albion Radar modules
 */
class AlbionRadarPackage : ReactPackage {
    override fun createNativeModules(reactContext: com.facebook.react.bridge.ReactApplicationContext): List<com.facebook.react.bridge.NativeModule> {
        return listOf(
            AlbionVpnServiceModule(reactContext),
            OverlayModule(reactContext)
        )
    }

    override fun createViewManagers(reactContext: com.facebook.react.bridge.ReactApplicationContext): List<com.facebook.react.uimanager.ViewManager<*, *>> {
        return emptyList()
    }
}
