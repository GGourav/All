package space.manus.albion.radar.android.overlay

import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PixelFormat
import android.os.Build
import android.util.AttributeSet
import android.util.Log
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import com.facebook.react.bridge.*
import kotlin.math.sqrt

/**
 * Overlay View for displaying radar on top of the game
 */
class RadarOverlayView(context: Context, attrs: AttributeSet? = null) : View(context, attrs) {
    companion object {
        private const val TAG = "RadarOverlayView"
    }

    private val paint = Paint().apply {
        isAntiAlias = true
        strokeWidth = 2f
    }

    private var entities: List<Map<String, Any>> = emptyList()
    private var playerPosition: Pair<Float, Float> = Pair(0f, 0f)
    private var zoom: Float = 1f
    private var offsetX: Float = 0f
    private var offsetY: Float = 0f

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val width = width.toFloat()
        val height = height.toFloat()
        val centerX = width / 2
        val centerY = height / 2

        // Draw background
        paint.color = 0x80000000.toInt()
        canvas.drawRect(0f, 0f, width, height, paint)

        // Draw grid
        paint.color = 0x40FFFFFF
        paint.strokeWidth = 1f
        val gridSize = 50f * zoom
        var x = offsetX % gridSize
        while (x < width) {
            canvas.drawLine(x, 0f, x, height, paint)
            x += gridSize
        }
        var y = offsetY % gridSize
        while (y < height) {
            canvas.drawLine(0f, y, width, y, paint)
            y += gridSize
        }

        // Draw player position
        paint.color = 0xFF00FF00.toInt()
        paint.strokeWidth = 2f
        canvas.drawCircle(centerX, centerY, 8f, paint)

        // Draw entities
        for (entity in entities) {
            val type = entity["type"] as? String ?: continue
            val x = (entity["x"] as? Number)?.toFloat() ?: continue
            val y = (entity["y"] as? Number)?.toFloat() ?: continue

            val screenX = centerX + (x - playerPosition.first) * zoom + offsetX
            val screenY = centerY + (y - playerPosition.second) * zoom + offsetY

            if (screenX < -50 || screenX > width + 50 || screenY < -50 || screenY > height + 50) {
                continue
            }

            when (type) {
                "resource" -> {
                    paint.color = 0xFF00FF00.toInt()
                    canvas.drawCircle(screenX, screenY, 4f * zoom, paint)
                }
                "mob" -> {
                    val threat = entity["threat"] as? String ?: "normal"
                    paint.color = when (threat) {
                        "safe" -> 0xFF00FF00.toInt()
                        "caution" -> 0xFFFFFF00.toInt()
                        "danger" -> 0xFFFFA500.toInt()
                        else -> 0xFFFF0000.toInt()
                    }
                    canvas.drawCircle(screenX, screenY, 6f * zoom, paint)
                }
                "player" -> {
                    paint.color = 0xFFFFFFFF.toInt()
                    canvas.drawCircle(screenX, screenY, 5f * zoom, paint)
                }
                "chest" -> {
                    paint.color = 0xFFFFD700.toInt()
                    canvas.drawRect(screenX - 4f, screenY - 4f, screenX + 4f, screenY + 4f, paint)
                }
            }
        }
    }

    fun updateEntities(newEntities: List<Map<String, Any>>) {
        entities = newEntities
        invalidate()
    }

    fun updatePlayerPosition(x: Float, y: Float) {
        playerPosition = Pair(x, y)
        invalidate()
    }

    fun setZoom(newZoom: Float) {
        zoom = newZoom.coerceIn(0.5f, 5f)
        invalidate()
    }

    fun setOffset(x: Float, y: Float) {
        offsetX = x
        offsetY = y
        invalidate()
    }
}

/**
 * Overlay Activity
 */
class OverlayActivity : Activity() {
    companion object {
        private const val TAG = "OverlayActivity"
    }

    private var radarView: RadarOverlayView? = null
    private var windowManager: WindowManager? = null
    private var layoutParams: WindowManager.LayoutParams? = null
    private var lastX: Float = 0f
    private var lastY: Float = 0f
    private var isDragging: Boolean = false

    override fun onStart() {
        super.onStart()
        Log.d(TAG, "Overlay activity started")
    }

    override fun onStop() {
        super.onStop()
        Log.d(TAG, "Overlay activity stopped")
    }

    fun showOverlay(context: Context) {
        try {
            windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            radarView = RadarOverlayView(context)

            layoutParams = WindowManager.LayoutParams().apply {
                type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                } else {
                    WindowManager.LayoutParams.TYPE_PHONE
                }
                format = PixelFormat.TRANSLUCENT
                flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                width = 400
                height = 400
                x = 0
                y = 0
            }

            radarView?.setOnTouchListener { _, event ->
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        isDragging = true
                        lastX = event.rawX
                        lastY = event.rawY
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        if (isDragging) {
                            val deltaX = event.rawX - lastX
                            val deltaY = event.rawY - lastY
                            layoutParams?.x = (layoutParams?.x ?: 0) + deltaX.toInt()
                            layoutParams?.y = (layoutParams?.y ?: 0) + deltaY.toInt()
                            windowManager?.updateViewLayout(radarView, layoutParams)
                            lastX = event.rawX
                            lastY = event.rawY
                        }
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        isDragging = false
                        true
                    }
                    else -> false
                }
            }

            windowManager?.addView(radarView, layoutParams)
            Log.d(TAG, "Overlay shown")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to show overlay", e)
        }
    }

    fun hideOverlay() {
        try {
            if (radarView != null && windowManager != null) {
                windowManager?.removeView(radarView)
                radarView = null
                Log.d(TAG, "Overlay hidden")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to hide overlay", e)
        }
    }

    fun updateOverlay(entities: List<Map<String, Any>>, playerX: Float, playerY: Float) {
        radarView?.updateEntities(entities)
        radarView?.updatePlayerPosition(playerX, playerY)
    }
}

/**
 * React Native Module for Overlay
 */
class OverlayModule(reactContext: ReactApplicationContext) : ReactContextBaseJavaModule(reactContext) {
    companion object {
        private const val TAG = "OverlayModule"
        private var overlayActivity: OverlayActivity? = null
    }

    override fun getName(): String = "OverlayModule"

    @ReactMethod
    fun showOverlay(promise: Promise) {
        try {
            if (overlayActivity == null) {
                overlayActivity = OverlayActivity()
            }
            overlayActivity?.showOverlay(reactApplicationContext)
            promise.resolve(null)
        } catch (e: Exception) {
            Log.e(TAG, "Error showing overlay", e)
            promise.reject("OVERLAY_ERROR", e.message)
        }
    }

    @ReactMethod
    fun hideOverlay(promise: Promise) {
        try {
            overlayActivity?.hideOverlay()
            promise.resolve(null)
        } catch (e: Exception) {
            Log.e(TAG, "Error hiding overlay", e)
            promise.reject("OVERLAY_ERROR", e.message)
        }
    }

    @ReactMethod
    fun updateOverlay(entities: ReadableArray, playerX: Double, playerY: Double, promise: Promise) {
        try {
            val entityList = mutableListOf<Map<String, Any>>()
            for (i in 0 until entities.size()) {
                val entity = entities.getMap(i)
                val map = mutableMapOf<String, Any>()
                val iterator = entity.keySetIterator()
                while (iterator.hasNextKey()) {
                    val key = iterator.nextKey()
                    map[key] = entity.getDynamic(key)
                }
                entityList.add(map)
            }
            overlayActivity?.updateOverlay(entityList, playerX.toFloat(), playerY.toFloat())
            promise.resolve(null)
        } catch (e: Exception) {
            Log.e(TAG, "Error updating overlay", e)
            promise.reject("OVERLAY_ERROR", e.message)
        }
    }
}
