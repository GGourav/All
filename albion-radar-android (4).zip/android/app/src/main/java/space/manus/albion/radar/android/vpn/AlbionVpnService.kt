package space.manus.albion.radar.android.vpn

import android.app.Service
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.util.Log
import com.facebook.react.bridge.*
import com.facebook.react.modules.core.DeviceEventManagerModule
import java.io.FileInputStream
import java.io.FileOutputStream
import kotlin.concurrent.thread

/**
 * Albion Online Radar - VPN Service
 * Captures UDP packets on port 5056 (Albion game server)
 */
class AlbionVpnService : VpnService() {
    companion object {
        private const val TAG = "AlbionVpnService"
        private const val ALBION_PORT = 5056
        private const val BUFFER_SIZE = 65536
        private const val MTU = 1500
    }

    private var vpnInterface: ParcelFileDescriptor? = null
    private var isRunning = false
    private var packetThread: Thread? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.d(TAG, "VPN Service started")
        return START_STICKY
    }

    override fun onDestroy() {
        Log.d(TAG, "VPN Service destroyed")
        stopVpn()
        super.onDestroy()
    }

    fun startVpn(config: ReadableMap) {
        if (isRunning) {
            Log.w(TAG, "VPN already running")
            return
        }

        isRunning = true
        val port = config.getInt("port").takeIf { it > 0 } ?: ALBION_PORT

        Log.d(TAG, "Starting VPN on port $port")

        val intent = VpnService.prepare(this)
        if (intent != null) {
            startActivity(intent)
            return
        }

        setupVpnInterface()
        packetThread = thread(name = "AlbionPacketCapture") {
            capturePackets(port)
        }
    }

    fun stopVpn() {
        if (!isRunning) {
            Log.w(TAG, "VPN not running")
            return
        }

        isRunning = false
        vpnInterface?.close()
        vpnInterface = null
        packetThread?.interrupt()
        packetThread = null

        Log.d(TAG, "VPN stopped")
    }

    private fun setupVpnInterface() {
        try {
            val builder = Builder()
            builder.setSession("AlbionRadar")
            builder.addAddress("192.0.2.1", 24)
            builder.addRoute("0.0.0.0", 0)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                builder.setMetered(false)
            }

            vpnInterface = builder.establish()
            Log.d(TAG, "VPN interface established")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to setup VPN interface", e)
        }
    }

    private fun capturePackets(port: Int) {
        try {
            val vpnInput = FileInputStream(vpnInterface?.fileDescriptor)
            val vpnOutput = FileOutputStream(vpnInterface?.fileDescriptor)
            val buffer = ByteArray(BUFFER_SIZE)

            while (isRunning) {
                try {
                    val bytesRead = vpnInput.read(buffer)
                    if (bytesRead <= 0) continue

                    val packet = parsePacket(buffer, bytesRead, port)
                    if (packet != null) {
                        Log.d(TAG, "Packet captured: ${packet["sourceIp"]} -> ${packet["destIp"]}")
                    }

                    vpnOutput.write(buffer, 0, bytesRead)
                    vpnOutput.flush()

                } catch (e: InterruptedException) {
                    break
                } catch (e: Exception) {
                    Log.e(TAG, "Error processing packet", e)
                }
            }

            vpnInput.close()
            vpnOutput.close()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to capture packets", e)
        }
    }

    private fun parsePacket(buffer: ByteArray, length: Int, targetPort: Int): Map<String, Any>? {
        try {
            if (length < 20) return null

            val version = (buffer[0].toInt() and 0xF0) shr 4
            val headerLength = (buffer[0].toInt() and 0x0F) * 4
            val protocol = buffer[9].toInt() and 0xFF

            if (version != 4 || protocol != 17) return null

            val sourceIp = "${buffer[12].toInt() and 0xFF}.${buffer[13].toInt() and 0xFF}.${buffer[14].toInt() and 0xFF}.${buffer[15].toInt() and 0xFF}"
            val destIp = "${buffer[16].toInt() and 0xFF}.${buffer[17].toInt() and 0xFF}.${buffer[18].toInt() and 0xFF}.${buffer[19].toInt() and 0xFF}"

            if (length < headerLength + 8) return null

            val sourcePort = ((buffer[headerLength].toInt() and 0xFF) shl 8) or (buffer[headerLength + 1].toInt() and 0xFF)
            val destPort = ((buffer[headerLength + 2].toInt() and 0xFF) shl 8) or (buffer[headerLength + 3].toInt() and 0xFF)

            if (destPort != targetPort && sourcePort != targetPort) return null

            val payloadStart = headerLength + 8
            val payloadLength = length - payloadStart
            if (payloadLength <= 0) return null

            val payload = ByteArray(payloadLength)
            System.arraycopy(buffer, payloadStart, payload, 0, payloadLength)

            return mapOf(
                "timestamp" to System.currentTimeMillis(),
                "sourceIp" to sourceIp,
                "destIp" to destIp,
                "port" to (if (destPort == targetPort) destPort else sourcePort),
                "data" to android.util.Base64.encodeToString(payload, android.util.Base64.NO_WRAP),
                "length" to payloadLength
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing packet", e)
            return null
        }
    }

    fun getStats(): Map<String, Any> {
        return mapOf(
            "isRunning" to isRunning,
            "timestamp" to System.currentTimeMillis()
        )
    }
}

/**
 * React Native Module Bridge
 */
class AlbionVpnServiceModule(reactContext: ReactApplicationContext) : ReactContextBaseJavaModule(reactContext) {
    companion object {
        private const val TAG = "AlbionVpnServiceModule"
        private var vpnService: AlbionVpnService? = null
    }

    override fun getName(): String = "AlbionVpnService"

    @ReactMethod
    fun startVpnService(config: ReadableMap, promise: Promise) {
        try {
            if (vpnService == null) {
                vpnService = AlbionVpnService()
            }
            vpnService?.startVpn(config)
            promise.resolve(null)
        } catch (e: Exception) {
            Log.e(TAG, "Error starting VPN service", e)
            promise.reject("VPN_ERROR", e.message)
        }
    }

    @ReactMethod
    fun stopVpnService(promise: Promise) {
        try {
            vpnService?.stopVpn()
            promise.resolve(null)
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping VPN service", e)
            promise.reject("VPN_ERROR", e.message)
        }
    }

    @ReactMethod
    fun getVpnStats(promise: Promise) {
        try {
            val stats = vpnService?.getStats() ?: mapOf("isRunning" to false)
            promise.resolve(stats)
        } catch (e: Exception) {
            Log.e(TAG, "Error getting VPN stats", e)
            promise.reject("VPN_ERROR", e.message)
        }
    }

    @ReactMethod
    fun requestVpnPermission(promise: Promise) {
        try {
            val intent = VpnService.prepare(reactApplicationContext)
            if (intent != null) {
                reactApplicationContext.startActivity(intent)
                promise.resolve(false)
            } else {
                promise.resolve(true)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error requesting VPN permission", e)
            promise.reject("VPN_ERROR", e.message)
        }
    }
}
