import { ScrollView, Text, View, TouchableOpacity, Switch } from 'react-native';
import { ScreenContainer } from '@/components/screen-container';
import { useState } from 'react';

/**
 * Simplified Home Screen - Albion Online Radar
 * This version works without complex manager initialization
 */
export default function HomeScreen() {
  const [showResources, setShowResources] = useState(true);
  const [showMobs, setShowMobs] = useState(true);
  const [showChests, setShowChests] = useState(true);
  const [vpnActive, setVpnActive] = useState(false);

  // Sample data
  const stats = {
    resourceCount: 12,
    mobCount: 5,
    chestCount: 2,
  };

  return (
    <ScreenContainer className="p-4">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <View className="gap-4">
          {/* Header */}
          <View className="items-center gap-2 mb-4">
            <Text className="text-3xl font-bold text-foreground">Albion Radar</Text>
            <Text className="text-sm text-muted">Real-time entity detection</Text>
          </View>

          {/* VPN Status */}
          <View className="bg-surface rounded-lg p-4 border border-border">
            <View className="flex-row items-center justify-between">
              <View className="gap-1">
                <Text className="text-base font-semibold text-foreground">VPN Service</Text>
                <Text className="text-xs text-muted">{vpnActive ? 'Connected' : 'Disconnected'}</Text>
              </View>
              <Switch value={vpnActive} onValueChange={setVpnActive} />
            </View>
          </View>

          {/* Radar Display */}
          <View className="bg-surface rounded-lg p-4 border border-border items-center">
            <Text className="text-sm font-semibold text-foreground mb-3">Live Radar</Text>
            <View className="w-full aspect-square bg-background rounded-lg border border-border items-center justify-center">
              <Text className="text-center text-muted">Radar Display</Text>
              <Text className="text-xs text-muted mt-2">Sample data shown</Text>
            </View>
          </View>

          {/* Entity Statistics */}
          <View className="bg-surface rounded-lg p-4 border border-border gap-3">
            <Text className="text-base font-semibold text-foreground">Statistics</Text>

            <View className="flex-row gap-3">
              <View className="flex-1 bg-background rounded-lg p-3 items-center">
                <Text className="text-2xl font-bold text-primary">{stats.resourceCount}</Text>
                <Text className="text-xs text-muted mt-1">Resources</Text>
              </View>

              <View className="flex-1 bg-background rounded-lg p-3 items-center">
                <Text className="text-2xl font-bold text-warning">{stats.mobCount}</Text>
                <Text className="text-xs text-muted mt-1">Mobs</Text>
              </View>

              <View className="flex-1 bg-background rounded-lg p-3 items-center">
                <Text className="text-2xl font-bold text-success">{stats.chestCount}</Text>
                <Text className="text-xs text-muted mt-1">Chests</Text>
              </View>
            </View>
          </View>

          {/* Display Options */}
          <View className="bg-surface rounded-lg p-4 border border-border gap-3">
            <Text className="text-base font-semibold text-foreground">Display Options</Text>

            <View className="flex-row items-center justify-between">
              <Text className="text-sm text-foreground">Show Resources</Text>
              <Switch value={showResources} onValueChange={setShowResources} />
            </View>

            <View className="flex-row items-center justify-between">
              <Text className="text-sm text-foreground">Show Mobs</Text>
              <Switch value={showMobs} onValueChange={setShowMobs} />
            </View>

            <View className="flex-row items-center justify-between">
              <Text className="text-sm text-foreground">Show Chests</Text>
              <Switch value={showChests} onValueChange={setShowChests} />
            </View>
          </View>

          {/* Legend */}
          <View className="bg-surface rounded-lg p-4 border border-border gap-2">
            <Text className="text-base font-semibold text-foreground mb-2">Legend</Text>

            <View className="gap-2">
              <View className="flex-row items-center gap-2">
                <View className="w-3 h-3 rounded-full bg-green-500" />
                <Text className="text-xs text-foreground">Normal Resource</Text>
              </View>

              <View className="flex-row items-center gap-2">
                <View className="w-3 h-3 rounded-full bg-blue-500" />
                <Text className="text-xs text-foreground">Mist Resource (Common)</Text>
              </View>

              <View className="flex-row items-center gap-2">
                <View className="w-3 h-3 rounded-full bg-yellow-500" />
                <Text className="text-xs text-foreground">Mob (Normal)</Text>
              </View>

              <View className="flex-row items-center gap-2">
                <View className="w-3 h-3 rounded-full bg-red-500" />
                <Text className="text-xs text-foreground">Mob (High Threat)</Text>
              </View>

              <View className="flex-row items-center gap-2">
                <View className="w-3 h-3" style={{ backgroundColor: '#FFD700' }} />
                <Text className="text-xs text-foreground">Chest</Text>
              </View>
            </View>
          </View>

          {/* Status */}
          <View className="bg-success bg-opacity-10 rounded-lg p-4 border border-success">
            <Text className="text-sm font-semibold text-success mb-1">✓ App is Running</Text>
            <Text className="text-xs text-muted">The APK is working correctly. VPN service integration coming soon.</Text>
          </View>

          {/* Action Buttons */}
          <View className="gap-2 mb-4">
            <TouchableOpacity className="bg-primary px-6 py-3 rounded-full active:opacity-80">
              <Text className="text-background font-semibold text-center">Start Overlay</Text>
            </TouchableOpacity>

            <TouchableOpacity className="bg-surface border border-border px-6 py-3 rounded-full active:opacity-80">
              <Text className="text-foreground font-semibold text-center">Settings</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
