import React, { useState, useEffect } from 'react';
import { ScrollView, Text, View, TouchableOpacity, Switch, FlatList, Alert } from 'react-native';
import { ScreenContainer } from '@/components/screen-container';
import { EntityCard } from '@/components/entity-card';
import { RadarView } from '@/components/radar-view';
import RadarEngine from '@/lib/radar/radar-engine';
import { vpnService, overlayService } from '@/lib/native/vpn-bridge';
import { usePermissions } from '@/hooks/use-permissions';

const radarEngine = new RadarEngine();

interface TabState {
  radar: boolean;
  resources: boolean;
  mobs: boolean;
  players: boolean;
  stats: boolean;
}

export default function HomeScreen() {
  // Request permissions on app startup
  usePermissions();

  const [vpnEnabled, setVpnEnabled] = useState(false);
  const [overlayEnabled, setOverlayEnabled] = useState(false);
  const [activeTab, setActiveTab] = useState<keyof TabState>('radar');
  const [entities, setEntities] = useState<any[]>([]);
  const [stats, setStats] = useState<any>(null);
  const [radarRunning, setRadarRunning] = useState(false);

  useEffect(() => {
    // Setup radar engine listeners
    radarEngine.on('started', () => {
      setRadarRunning(true);
      Alert.alert('Radar Started', 'Packet capture is now active');
    });

    radarEngine.on('stopped', () => {
      setRadarRunning(false);
      Alert.alert('Radar Stopped', 'Packet capture has been stopped');
    });

    radarEngine.on('entity-update', (entity: any) => {
      setEntities(prev => {
        const updated = [...prev];
        const index = updated.findIndex(e => e.id === entity.id);
        if (index >= 0) {
          updated[index] = entity;
        } else {
          updated.push(entity);
        }
        return updated.slice(-1000); // Keep last 1000 entities
      });
    });

    radarEngine.on('stats', (newStats: any) => {
      setStats(newStats);
    });

    radarEngine.on('error', (error: Error) => {
      Alert.alert('Radar Error', error.message);
    });

    return () => {
      radarEngine.removeAllListeners();
    };
  }, []);

  const toggleVpn = async () => {
    try {
      if (!vpnEnabled) {
        // Request permission first
        const hasPermission = await vpnService.requestPermission();
        if (!hasPermission) {
          Alert.alert('VPN Permission Required', 'Please grant VPN permission in the system dialog');
          return;
        }

        // Start radar engine
        await radarEngine.start();
        setVpnEnabled(true);
      } else {
        // Stop radar engine
        await radarEngine.stop();
        setVpnEnabled(false);
      }
    } catch (error: any) {
      Alert.alert('VPN Error', error.message || 'Failed to toggle VPN');
    }
  };

  const toggleOverlay = async () => {
    try {
      if (!overlayEnabled) {
        await overlayService.show();
        setOverlayEnabled(true);
      } else {
        await overlayService.hide();
        setOverlayEnabled(false);
      }
    } catch (error: any) {
      Alert.alert('Overlay Error', error.message || 'Failed to toggle overlay');
    }
  };

  const getFilteredEntities = () => {
    if (activeTab === 'resources') return entities.filter(e => e.type === 'resource');
    if (activeTab === 'mobs') return entities.filter(e => e.type === 'mob');
    if (activeTab === 'players') return entities.filter(e => e.type === 'player');
    return entities;
  };

  const filteredEntities = getFilteredEntities();

  return (
    <ScreenContainer className="flex-1 bg-background">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="flex-1">
        <View className="p-4 gap-4">
          {/* Header */}
          <View className="gap-2">
            <Text className="text-3xl font-bold text-foreground">Albion Radar</Text>
            <Text className="text-sm text-muted">
              {radarRunning ? '🟢 Active' : '🔴 Inactive'}
            </Text>
          </View>

          {/* VPN Control */}
          <View className="bg-surface rounded-lg p-4 gap-3 border border-border">
            <View className="flex-row items-center justify-between">
              <View className="gap-1">
                <Text className="text-base font-semibold text-foreground">VPN Service</Text>
                <Text className="text-xs text-muted">Packet capture on port 5056</Text>
              </View>
              <Switch
                value={vpnEnabled}
                onValueChange={toggleVpn}
                disabled={radarRunning}
              />
            </View>
          </View>

          {/* Overlay Control */}
          <View className="bg-surface rounded-lg p-4 gap-3 border border-border">
            <View className="flex-row items-center justify-between">
              <View className="gap-1">
                <Text className="text-base font-semibold text-foreground">Overlay</Text>
                <Text className="text-xs text-muted">Display radar on top of game</Text>
              </View>
              <Switch
                value={overlayEnabled}
                onValueChange={toggleOverlay}
              />
            </View>
          </View>

          {/* Tab Navigation */}
          <View className="flex-row gap-2 bg-surface rounded-lg p-2 border border-border">
            {(['radar', 'resources', 'mobs', 'players', 'stats'] as const).map(tab => (
              <TouchableOpacity
                key={tab}
                onPress={() => setActiveTab(tab)}
                className={`flex-1 py-2 px-3 rounded ${
                  activeTab === tab ? 'bg-primary' : 'bg-background'
                }`}
              >
                <Text
                  className={`text-xs font-semibold text-center ${
                    activeTab === tab ? 'text-background' : 'text-foreground'
                  }`}
                >
                  {tab.charAt(0).toUpperCase() + tab.slice(1)}
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          {/* Content Area */}
          {activeTab === 'radar' && (
            <View className="bg-surface rounded-lg p-4 border border-border h-80">
              <RadarView
                resources={entities.filter(e => e.type === 'resource')}
                mobs={entities.filter(e => e.type === 'mob')}
                players={entities.filter(e => e.type === 'player')}
                chests={entities.filter(e => e.type === 'chest')}
                playerPosition={stats?.playerPosition || { x: 0, y: 0 }}
              />
            </View>
          )}

          {activeTab === 'stats' && stats && (
            <View className="bg-surface rounded-lg p-4 gap-3 border border-border">
              <View className="gap-2">
                <Text className="text-sm font-semibold text-foreground">Statistics</Text>
                <View className="gap-1">
                  <Text className="text-xs text-muted">Packets: {stats.packetsProcessed}</Text>
                  <Text className="text-xs text-muted">Entities: {stats.entitiesTracked}</Text>
                  <Text className="text-xs text-muted">Resources: {stats.resources}</Text>
                  <Text className="text-xs text-muted">Mobs: {stats.mobs}</Text>
                  <Text className="text-xs text-muted">Players: {stats.players}</Text>
                  <Text className="text-xs text-muted">Chests: {stats.chests}</Text>
                </View>
              </View>
            </View>
          )}

          {(activeTab === 'resources' || activeTab === 'mobs' || activeTab === 'players') && (
            <View className="gap-2">
              <Text className="text-sm font-semibold text-foreground">
                {activeTab.charAt(0).toUpperCase() + activeTab.slice(1)} ({filteredEntities.length})
              </Text>
              {filteredEntities.length === 0 ? (
                <View className="bg-surface rounded-lg p-4 border border-border">
                  <Text className="text-sm text-muted text-center">No {activeTab} detected</Text>
                </View>
              ) : (
                <FlatList
                  scrollEnabled={false}
                  data={filteredEntities.slice(0, 20)}
                  keyExtractor={item => String(item.id)}
                  renderItem={({ item }) => {
                    const cardData = {
                      ...item,
                      type: item.type,
                    };
                    return <EntityCard {...cardData} />;
                  }}
                  ItemSeparatorComponent={() => <View className="h-2" />}
                />
              )}
            </View>
          )}

          {/* Legend */}
          <View className="bg-surface rounded-lg p-4 gap-2 border border-border">
            <Text className="text-sm font-semibold text-foreground">Threat Levels</Text>
            <View className="gap-1">
              <View className="flex-row items-center gap-2">
                <View className="w-3 h-3 rounded-full bg-green-500" />
                <Text className="text-xs text-muted">Safe</Text>
              </View>
              <View className="flex-row items-center gap-2">
                <View className="w-3 h-3 rounded-full bg-yellow-500" />
                <Text className="text-xs text-muted">Caution</Text>
              </View>
              <View className="flex-row items-center gap-2">
                <View className="w-3 h-3 rounded-full bg-orange-500" />
                <Text className="text-xs text-muted">Danger</Text>
              </View>
              <View className="flex-row items-center gap-2">
                <View className="w-3 h-3 rounded-full bg-red-500" />
                <Text className="text-xs text-muted">Extreme</Text>
              </View>
            </View>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
