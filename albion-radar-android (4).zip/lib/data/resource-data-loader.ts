/**
 * Resource Data Loader
 * Loads and indexes all 251 resource variants from the game data
 * Supports filtering, search, and statistics
 */

import harvestablesData from '@/data/harvestables.json';

export enum ResourceType {
  WOOD = 'WOOD',
  ROCK = 'ROCK',
  FIBER = 'FIBER',
  HIDE = 'HIDE',
  ORE = 'ORE',
}

export enum ResourceRarity {
  Common = 'common',
  Uncommon = 'uncommon',
  Rare = 'rare',
  Epic = 'epic',
  Legendary = 'legendary',
}

export interface ResourceVariant {
  tier: number;
  item: string;
  respawn: number;
  harvest: number;
  tool: boolean;
  maxcharges: number;
  startcharges: number;
  chargeup?: number;
}

export interface ResourceDefinition {
  type: ResourceType;
  tier: number;
  item: string;
  displayName: string;
  respawnTime: number;
  harvestAmount: number;
  requiresTool: boolean;
  maxCharges: number;
  startCharges: number;
  chargeUpRate: number;
  rarity: ResourceRarity;
}

class ResourceDataLoader {
  private resourcesMap: Map<string, ResourceDefinition> = new Map();
  private resourcesByType: Map<ResourceType, ResourceDefinition[]> = new Map();
  private resourcesByTier: Map<number, ResourceDefinition[]> = new Map();
  private resourcesByRarity: Map<ResourceRarity, ResourceDefinition[]> = new Map();

  constructor() {
    this.loadResourceData();
  }

  /**
   * Load and index all resource data
   */
  private loadResourceData(): void {
    const data = harvestablesData as Record<string, ResourceVariant[]>;

    Object.entries(data).forEach(([resourceType, variants]) => {
      const type = resourceType as ResourceType;

      variants.forEach((variant, index) => {
        const rarity = this.calculateRarity(type, variant.tier, variant.chargeup);
        const displayName = this.generateDisplayName(type, variant);
        const resourceId = `${type}_T${variant.tier}_${index}`;

        const resourceDef: ResourceDefinition = {
          type,
          tier: variant.tier,
          item: variant.item,
          displayName,
          respawnTime: variant.respawn,
          harvestAmount: variant.harvest,
          requiresTool: variant.tool,
          maxCharges: variant.maxcharges,
          startCharges: variant.startcharges,
          chargeUpRate: variant.chargeup || 0,
          rarity,
        };

        // Index by ID
        this.resourcesMap.set(resourceId, resourceDef);

        // Index by type
        if (!this.resourcesByType.has(type)) {
          this.resourcesByType.set(type, []);
        }
        this.resourcesByType.get(type)!.push(resourceDef);

        // Index by tier
        if (!this.resourcesByTier.has(variant.tier)) {
          this.resourcesByTier.set(variant.tier, []);
        }
        this.resourcesByTier.get(variant.tier)!.push(resourceDef);

        // Index by rarity
        if (!this.resourcesByRarity.has(rarity)) {
          this.resourcesByRarity.set(rarity, []);
        }
        this.resourcesByRarity.get(rarity)!.push(resourceDef);
      });
    });

    console.log(`✓ Loaded ${this.resourcesMap.size} resource variants`);
  }

  /**
   * Calculate rarity based on tier and charge-up rate
   * Higher charge-up rate = higher rarity (mist resources)
   */
  private calculateRarity(type: ResourceType, tier: number, chargeup?: number): ResourceRarity {
    if (!chargeup || chargeup === 0) {
      return ResourceRarity.Common;
    }

    // Mist resources have higher charge-up rates
    if (chargeup > 2.0) {
      return ResourceRarity.Legendary;
    }
    if (chargeup > 1.5) {
      return ResourceRarity.Epic;
    }
    if (chargeup > 1.0) {
      return ResourceRarity.Rare;
    }
    if (chargeup > 0.5) {
      return ResourceRarity.Uncommon;
    }

    return ResourceRarity.Common;
  }

  /**
   * Generate display name for resource
   */
  private generateDisplayName(type: ResourceType, variant: ResourceVariant): string {
    const tierName = this.getTierName(type, variant.tier);
    return `${tierName} ${type}`;
  }

  /**
   * Get tier-specific name (e.g., "Birch" for T2 Wood)
   */
  private getTierName(type: ResourceType, tier: number): string {
    const tierNames: Record<ResourceType, Record<number, string>> = {
      [ResourceType.WOOD]: {
        1: 'Birch',
        2: 'Birch',
        3: 'Chestnut',
        4: 'Chestnut',
        5: 'Ashwood',
        6: 'Ashwood',
        7: 'Heartwood',
        8: 'Heartwood',
      },
      [ResourceType.ROCK]: {
        1: 'Granite',
        2: 'Granite',
        3: 'Sandstone',
        4: 'Sandstone',
        5: 'Limestone',
        6: 'Limestone',
        7: 'Marble',
        8: 'Marble',
      },
      [ResourceType.FIBER]: {
        1: 'Flax',
        2: 'Flax',
        3: 'Hemp',
        4: 'Hemp',
        5: 'Silk',
        6: 'Silk',
        7: 'Nettle',
        8: 'Nettle',
      },
      [ResourceType.HIDE]: {
        1: 'Leather',
        2: 'Leather',
        3: 'Rawhide',
        4: 'Rawhide',
        5: 'Thick Hide',
        6: 'Thick Hide',
        7: 'Scaled Hide',
        8: 'Scaled Hide',
      },
      [ResourceType.ORE]: {
        1: 'Copper',
        2: 'Copper',
        3: 'Tin',
        4: 'Tin',
        5: 'Iron',
        6: 'Iron',
        7: 'Steel',
        8: 'Steel',
      },
    };

    return tierNames[type]?.[tier] || `T${tier}`;
  }

  /**
   * Get resource by ID
   */
  getResourceById(resourceId: string): ResourceDefinition | undefined {
    return this.resourcesMap.get(resourceId);
  }

  /**
   * Get resources by type
   */
  getResourcesByType(type: ResourceType): ResourceDefinition[] {
    return this.resourcesByType.get(type) || [];
  }

  /**
   * Get resources by tier
   */
  getResourcesByTier(tier: number): ResourceDefinition[] {
    return this.resourcesByTier.get(tier) || [];
  }

  /**
   * Get resources by rarity
   */
  getResourcesByRarity(rarity: ResourceRarity): ResourceDefinition[] {
    return this.resourcesByRarity.get(rarity) || [];
  }

  /**
   * Get all resources
   */
  getAllResources(): ResourceDefinition[] {
    return Array.from(this.resourcesMap.values());
  }

  /**
   * Filter resources by multiple criteria
   */
  filterResources(criteria: {
    types?: ResourceType[];
    tiers?: number[];
    rarities?: ResourceRarity[];
    requiresTool?: boolean;
    searchTerm?: string;
  }): ResourceDefinition[] {
    let results = this.getAllResources();

    if (criteria.types && criteria.types.length > 0) {
      results = results.filter((r) => criteria.types!.includes(r.type));
    }

    if (criteria.tiers && criteria.tiers.length > 0) {
      results = results.filter((r) => criteria.tiers!.includes(r.tier));
    }

    if (criteria.rarities && criteria.rarities.length > 0) {
      results = results.filter((r) => criteria.rarities!.includes(r.rarity));
    }

    if (criteria.requiresTool !== undefined) {
      results = results.filter((r) => r.requiresTool === criteria.requiresTool);
    }

    if (criteria.searchTerm) {
      const term = criteria.searchTerm.toLowerCase();
      results = results.filter(
        (r) =>
          r.displayName.toLowerCase().includes(term) ||
          r.item.toLowerCase().includes(term) ||
          r.type.toLowerCase().includes(term)
      );
    }

    return results;
  }

  /**
   * Get statistics about loaded resources
   */
  getStatistics() {
    return {
      totalResources: this.resourcesMap.size,
      typeDistribution: Object.fromEntries(
        Array.from(this.resourcesByType.entries()).map(([type, resources]) => [
          type,
          resources.length,
        ])
      ),
      tierDistribution: Object.fromEntries(
        Array.from(this.resourcesByTier.entries()).map(([tier, resources]) => [
          `T${tier}`,
          resources.length,
        ])
      ),
      rarityDistribution: Object.fromEntries(
        Array.from(this.resourcesByRarity.entries()).map(([rarity, resources]) => [
          rarity,
          resources.length,
        ])
      ),
    };
  }

  /**
   * Get rarity color for UI display
   */
  getRarityColor(rarity: ResourceRarity): string {
    const colors: Record<ResourceRarity, string> = {
      [ResourceRarity.Common]: '#FFFFFF',
      [ResourceRarity.Uncommon]: '#1EFF00',
      [ResourceRarity.Rare]: '#0070DD',
      [ResourceRarity.Epic]: '#A335EE',
      [ResourceRarity.Legendary]: '#FF8000',
    };
    return colors[rarity];
  }
}

// Create singleton instance
export const resourceDataLoader = new ResourceDataLoader();

// Export for use in components
export function getResourceDefinition(resourceId: string): ResourceDefinition | undefined {
  return resourceDataLoader.getResourceById(resourceId);
}

export function getAllResourceDefinitions(): ResourceDefinition[] {
  return resourceDataLoader.getAllResources();
}

export function getResourceStatistics() {
  return resourceDataLoader.getStatistics();
}

export function getRarityColor(rarity: ResourceRarity): string {
  return resourceDataLoader.getRarityColor(rarity);
}
