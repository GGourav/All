/**
 * Mob Data Loader
 * Loads and indexes all 4,528 mob definitions from the game data
 * Provides efficient lookup and filtering capabilities
 */

import mobsData from '@/data/mobs.json';

export interface MobData {
  u: string;           // Unique ID
  t: number;          // Tier (1-8)
  c: string;          // Category
  n: string;          // Display name (localization key)
  fame?: number;      // Fame reward
  hp?: number;        // Health points
  avatar?: string;    // Avatar/icon identifier
  danger?: string;    // Danger level
}

export enum MobThreatLevel {
  Safe = 'safe',
  Caution = 'caution',
  Danger = 'danger',
  Extreme = 'extreme',
}

export interface MobDefinition {
  typeId: number;
  uniqueId: string;
  displayName: string;
  tier: number;
  category: string;
  threatLevel: MobThreatLevel;
  health: number;
  fame: number;
  avatar: string;
  danger: string;
}

class MobDataLoader {
  private mobsMap: Map<string, MobDefinition> = new Map();
  private mobsByTier: Map<number, MobDefinition[]> = new Map();
  private mobsByCategory: Map<string, MobDefinition[]> = new Map();
  private mobsByThreat: Map<MobThreatLevel, MobDefinition[]> = new Map();

  constructor() {
    this.loadMobData();
  }

  /**
   * Load and index all mob data
   */
  private loadMobData(): void {
    const mobs = mobsData as MobData[];

    mobs.forEach((mobData, index) => {
      const threatLevel = this.calculateThreatLevel(mobData);
      const mobDef: MobDefinition = {
        typeId: index,
        uniqueId: mobData.u,
        displayName: mobData.n,
        tier: mobData.t,
        category: mobData.c,
        threatLevel,
        health: mobData.hp || 0,
        fame: mobData.fame || 0,
        avatar: mobData.avatar || '',
        danger: mobData.danger || 'normal',
      };

      // Index by unique ID
      this.mobsMap.set(mobData.u, mobDef);

      // Index by tier
      if (!this.mobsByTier.has(mobData.t)) {
        this.mobsByTier.set(mobData.t, []);
      }
      this.mobsByTier.get(mobData.t)!.push(mobDef);

      // Index by category
      if (!this.mobsByCategory.has(mobData.c)) {
        this.mobsByCategory.set(mobData.c, []);
      }
      this.mobsByCategory.get(mobData.c)!.push(mobDef);

      // Index by threat level
      if (!this.mobsByThreat.has(threatLevel)) {
        this.mobsByThreat.set(threatLevel, []);
      }
      this.mobsByThreat.get(threatLevel)!.push(mobDef);
    });

    console.log(`✓ Loaded ${this.mobsMap.size} mob definitions`);
  }

  /**
   * Calculate threat level based on tier, category, and danger
   */
  private calculateThreatLevel(mobData: MobData): MobThreatLevel {
    const tier = mobData.t;
    const category = mobData.c?.toLowerCase() || '';
    const danger = mobData.danger?.toLowerCase() || '';

    // Boss and mini-boss are always dangerous
    if (category === 'boss' || category === 'miniboss' || category === 'champion') {
      return MobThreatLevel.Extreme;
    }

    // Elite danger level
    if (danger === 'elite' || danger === 'veteran') {
      return MobThreatLevel.Danger;
    }

    // Roaming mobs
    if (danger === 'roaming') {
      if (tier >= 6) return MobThreatLevel.Danger;
      if (tier >= 4) return MobThreatLevel.Caution;
    }

    // Tier-based threat
    if (tier >= 7) return MobThreatLevel.Extreme;
    if (tier >= 5) return MobThreatLevel.Danger;
    if (tier >= 3) return MobThreatLevel.Caution;

    return MobThreatLevel.Safe;
  }

  /**
   * Get mob by unique ID
   */
  getMobByUniqueId(uniqueId: string): MobDefinition | undefined {
    return this.mobsMap.get(uniqueId);
  }

  /**
   * Get mob by type ID (index)
   */
  getMobByTypeId(typeId: number): MobDefinition | undefined {
    const mobs = mobsData as MobData[];
    if (typeId < 0 || typeId >= mobs.length) return undefined;
    const mobData = mobs[typeId];
    return this.mobsMap.get(mobData.u);
  }

  /**
   * Get all mobs of a specific tier
   */
  getMobsByTier(tier: number): MobDefinition[] {
    return this.mobsByTier.get(tier) || [];
  }

  /**
   * Get all mobs of a specific category
   */
  getMobsByCategory(category: string): MobDefinition[] {
    return this.mobsByCategory.get(category) || [];
  }

  /**
   * Get all mobs of a specific threat level
   */
  getMobsByThreat(threatLevel: MobThreatLevel): MobDefinition[] {
    return this.mobsByThreat.get(threatLevel) || [];
  }

  /**
   * Get all mobs
   */
  getAllMobs(): MobDefinition[] {
    return Array.from(this.mobsMap.values());
  }

  /**
   * Filter mobs by multiple criteria
   */
  filterMobs(criteria: {
    tiers?: number[];
    categories?: string[];
    threatLevels?: MobThreatLevel[];
    searchTerm?: string;
  }): MobDefinition[] {
    let results = this.getAllMobs();

    if (criteria.tiers && criteria.tiers.length > 0) {
      results = results.filter((m) => criteria.tiers!.includes(m.tier));
    }

    if (criteria.categories && criteria.categories.length > 0) {
      results = results.filter((m) => criteria.categories!.includes(m.category));
    }

    if (criteria.threatLevels && criteria.threatLevels.length > 0) {
      results = results.filter((m) => criteria.threatLevels!.includes(m.threatLevel));
    }

    if (criteria.searchTerm) {
      const term = criteria.searchTerm.toLowerCase();
      results = results.filter(
        (m) =>
          m.displayName.toLowerCase().includes(term) ||
          m.uniqueId.toLowerCase().includes(term) ||
          m.category.toLowerCase().includes(term)
      );
    }

    return results;
  }

  /**
   * Get statistics about loaded mobs
   */
  getStatistics() {
    return {
      totalMobs: this.mobsMap.size,
      tierDistribution: Object.fromEntries(
        Array.from(this.mobsByTier.entries()).map(([tier, mobs]) => [tier, mobs.length])
      ),
      categoryDistribution: Object.fromEntries(
        Array.from(this.mobsByCategory.entries()).map(([cat, mobs]) => [cat, mobs.length])
      ),
      threatDistribution: Object.fromEntries(
        Array.from(this.mobsByThreat.entries()).map(([threat, mobs]) => [threat, mobs.length])
      ),
    };
  }
}

// Create singleton instance
export const mobDataLoader = new MobDataLoader();

// Export for use in components
export function getMobDefinition(typeId: number): MobDefinition | undefined {
  return mobDataLoader.getMobByTypeId(typeId);
}

export function getAllMobDefinitions(): MobDefinition[] {
  return mobDataLoader.getAllMobs();
}

export function getMobStatistics() {
  return mobDataLoader.getStatistics();
}
