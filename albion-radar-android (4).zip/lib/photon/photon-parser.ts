/**
 * Photon Protocol16 Parser - Complete implementation for Albion Online
 * Handles binary deserialization of Photon game events
 */

export interface PhotonEvent {
  eventCode: number;
  parameters: Map<number, any>;
  timestamp: number;
}

export interface Entity {
  id: number;
  type: 'resource' | 'mob' | 'player' | 'chest' | 'npc';
  x: number;
  y: number;
  z: number;
  name?: string;
  health?: number;
  maxHealth?: number;
  tier?: number;
  enchantment?: number;
  threat?: 'safe' | 'caution' | 'danger' | 'extreme';
  rarity?: string;
  charges?: number;
  faction?: string;
  guild?: string;
}

/**
 * Binary reader for Photon protocol
 */
class BinaryReader {
  private view: DataView;
  private offset: number = 0;

  constructor(buffer: ArrayBuffer | ArrayBufferLike) {
    this.view = new DataView(buffer as ArrayBuffer);
  }

  readByte(): number {
    const value = this.view.getUint8(this.offset);
    this.offset += 1;
    return value;
  }

  readShort(): number {
    const value = this.view.getInt16(this.offset, true); // little-endian
    this.offset += 2;
    return value;
  }

  readInt(): number {
    const value = this.view.getInt32(this.offset, true); // little-endian
    this.offset += 4;
    return value;
  }

  readFloat(): number {
    const value = this.view.getFloat32(this.offset, true); // little-endian
    this.offset += 4;
    return value;
  }

  readString(): string {
    const length = this.readShort();
    if (length <= 0) return '';

    const bytes = new Uint8Array(this.view.buffer, this.offset, length);
    this.offset += length;
    return new TextDecoder().decode(bytes);
  }

  readBytes(length: number): Uint8Array {
    const bytes = new Uint8Array(this.view.buffer, this.offset, length);
    this.offset += length;
    return bytes;
  }

  readBoolean(): boolean {
    return this.readByte() !== 0;
  }

  hasMore(): boolean {
    return this.offset < this.view.byteLength;
  }

  getOffset(): number {
    return this.offset;
  }

  setOffset(offset: number): void {
    this.offset = offset;
  }

  getRemaining(): number {
    return this.view.byteLength - this.offset;
  }
}

/**
 * Photon Protocol16 Parser
 */
export class PhotonParser {
  private static readonly EVENT_CODES = {
    // Game events
    NEW_MOB: 0,
    MOB_CHANGE_STATE: 1,
    NEW_HARVESTABLE_OBJECT: 2,
    HARVESTABLE_CHANGE_STATE: 3,
    NEW_SIMPLE_HARVESTABLE_OBJECT_LIST: 4,
    NEW_PLAYER: 5,
    PLAYER_CHANGE_STATE: 6,
    NEW_CHEST: 7,
    CHEST_CHANGE_STATE: 8,
    REMOVE_OBJECT: 9,
    OBJECT_MOVE: 10,
  };

  /**
   * Parse Photon event from binary data
   */
  static parseEvent(data: Uint8Array): PhotonEvent | null {
    try {
      if (data.length < 3) return null;

      const reader = new BinaryReader(data.buffer);

      // Read Photon command header
      const commandType = reader.readByte();
      const channelId = reader.readByte();
      const commandFlags = reader.readByte();

      // Only process event commands (type 4)
      if (commandType !== 4) return null;

      const eventCode = reader.readByte();
      const parameterCount = reader.readByte();

      const parameters = new Map<number, any>();

      for (let i = 0; i < parameterCount; i++) {
        const key = reader.readByte();
        const value = this.readParameter(reader);
        parameters.set(key, value);
      }

      return {
        eventCode,
        parameters,
        timestamp: Date.now(),
      };
    } catch (error) {
      console.error('Error parsing Photon event:', error);
      return null;
    }
  }

  /**
   * Read a Photon parameter value
   */
  private static readParameter(reader: BinaryReader): any {
    const typeCode = reader.readByte();

    switch (typeCode) {
      case 0: // null
        return null;
      case 1: // boolean false
        return false;
      case 2: // boolean true
        return true;
      case 3: // byte
        return reader.readByte();
      case 4: // short
        return reader.readShort();
      case 5: // int
        return reader.readInt();
      case 6: // long (read as int for now)
        return reader.readInt();
      case 7: // float
        return reader.readFloat();
      case 8: // double (read as float for now)
        return reader.readFloat();
      case 9: // string
        return reader.readString();
      case 10: // byte array
        const length = reader.readShort();
        return reader.readBytes(length);
      case 11: // object array
        return this.readArray(reader);
      case 12: // hashtable
        return this.readHashtable(reader);
      case 13: // dictionary
        return this.readDictionary(reader);
      default:
        console.warn(`Unknown parameter type: ${typeCode}`);
        return null;
    }
  }

  /**
   * Read array parameter
   */
  private static readArray(reader: BinaryReader): any[] {
    const count = reader.readShort();
    const array: any[] = [];

    for (let i = 0; i < count; i++) {
      array.push(this.readParameter(reader));
    }

    return array;
  }

  /**
   * Read hashtable parameter
   */
  private static readHashtable(reader: BinaryReader): Record<string, any> {
    const count = reader.readShort();
    const hashtable: Record<string, any> = {};

    for (let i = 0; i < count; i++) {
      const key = this.readParameter(reader);
      const value = this.readParameter(reader);
      if (key !== null) {
        hashtable[String(key)] = value;
      }
    }

    return hashtable;
  }

  /**
   * Read dictionary parameter
   */
  private static readDictionary(reader: BinaryReader): Record<string, any> {
    const count = reader.readShort();
    const dictionary: Record<string, any> = {};

    for (let i = 0; i < count; i++) {
      const key = this.readParameter(reader);
      const value = this.readParameter(reader);
      if (key !== null) {
        dictionary[String(key)] = value;
      }
    }

    return dictionary;
  }

  /**
   * Extract entity from Photon event
   */
  static extractEntity(event: PhotonEvent): Entity | null {
    const params = event.parameters;

    switch (event.eventCode) {
      case this.EVENT_CODES.NEW_MOB:
        return this.parseMobEvent(params);

      case this.EVENT_CODES.NEW_HARVESTABLE_OBJECT:
        return this.parseResourceEvent(params);

      case this.EVENT_CODES.NEW_PLAYER:
        return this.parsePlayerEvent(params);

      case this.EVENT_CODES.NEW_CHEST:
        return this.parseChestEvent(params);

      default:
        return null;
    }
  }

  /**
   * Parse mob event
   */
  private static parseMobEvent(params: Map<number, any>): Entity | null {
    try {
      const id = params.get(0) as number;
      const x = params.get(1) as number;
      const y = params.get(2) as number;
      const z = params.get(3) as number;
      const typeId = params.get(4) as number;
      const health = params.get(5) as number;
      const maxHealth = params.get(6) as number;
      const tier = params.get(7) as number;
      const enchantment = params.get(8) as number;

      if (!id || x === undefined || y === undefined) return null;

      return {
        id,
        type: 'mob',
        x,
        y,
        z: z || 0,
        health,
        maxHealth,
        tier: tier || 1,
        enchantment: enchantment || 0,
        threat: this.calculateThreat(tier, enchantment, health, maxHealth),
      };
    } catch (error) {
      console.error('Error parsing mob event:', error);
      return null;
    }
  }

  /**
   * Parse resource event
   */
  private static parseResourceEvent(params: Map<number, any>): Entity | null {
    try {
      const id = params.get(0) as number;
      const x = params.get(1) as number;
      const y = params.get(2) as number;
      const z = params.get(3) as number;
      const typeId = params.get(4) as number;
      const tier = params.get(5) as number;
      const enchantment = params.get(6) as number;
      const charges = params.get(7) as number;

      if (!id || x === undefined || y === undefined) return null;

      return {
        id,
        type: 'resource',
        x,
        y,
        z: z || 0,
        tier: tier || 1,
        enchantment: enchantment || 0,
        charges: charges || 0,
        rarity: this.calculateRarity(charges),
      };
    } catch (error) {
      console.error('Error parsing resource event:', error);
      return null;
    }
  }

  /**
   * Parse player event
   */
  private static parsePlayerEvent(params: Map<number, any>): Entity | null {
    try {
      const id = params.get(0) as number;
      const x = params.get(1) as number;
      const y = params.get(2) as number;
      const z = params.get(3) as number;
      const name = params.get(4) as string;
      const faction = params.get(5) as string;
      const guild = params.get(6) as string;

      if (!id || x === undefined || y === undefined) return null;

      return {
        id,
        type: 'player',
        x,
        y,
        z: z || 0,
        name,
        faction,
        guild,
      };
    } catch (error) {
      console.error('Error parsing player event:', error);
      return null;
    }
  }

  /**
   * Parse chest event
   */
  private static parseChestEvent(params: Map<number, any>): Entity | null {
    try {
      const id = params.get(0) as number;
      const x = params.get(1) as number;
      const y = params.get(2) as number;
      const z = params.get(3) as number;
      const rarity = params.get(4) as string;

      if (!id || x === undefined || y === undefined) return null;

      return {
        id,
        type: 'chest',
        x,
        y,
        z: z || 0,
        rarity,
      };
    } catch (error) {
      console.error('Error parsing chest event:', error);
      return null;
    }
  }

  /**
   * Calculate threat level
   */
  private static calculateThreat(
    tier?: number,
    enchantment?: number,
    health?: number,
    maxHealth?: number
  ): 'safe' | 'caution' | 'danger' | 'extreme' {
    const t = tier || 1;
    const e = enchantment || 0;
    const threatScore = t * 10 + e * 5;

    if (threatScore <= 15) return 'safe';
    if (threatScore <= 30) return 'caution';
    if (threatScore <= 50) return 'danger';
    return 'extreme';
  }

  /**
   * Calculate rarity based on charges
   */
  private static calculateRarity(charges?: number): string {
    const c = charges || 0;

    if (c === 0) return 'common';
    if (c <= 25) return 'uncommon';
    if (c <= 50) return 'rare';
    if (c <= 75) return 'epic';
    return 'legendary';
  }
}

export default PhotonParser;
