/**
 * Simple EventEmitter implementation for React Native compatibility
 * Avoids issues with Node.js 'events' module in React Native
 */
export class SimpleEventEmitter {
  private listeners: Map<string, Set<Function>> = new Map();

  on(event: string, listener: (...args: any[]) => void): this {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, new Set());
    }
    this.listeners.get(event)!.add(listener);
    return this;
  }

  once(event: string, listener: (...args: any[]) => void): this {
    const onceWrapper = (...args: any[]) => {
      listener(...args);
      this.off(event, onceWrapper);
    };
    return this.on(event, onceWrapper);
  }

  off(event: string, listener: (...args: any[]) => void): this {
    if (this.listeners.has(event)) {
      this.listeners.get(event)!.delete(listener);
    }
    return this;
  }

  emit(event: string, ...args: any[]): boolean {
    if (!this.listeners.has(event)) {
      return false;
    }

    const listeners = this.listeners.get(event)!;
    for (const listener of listeners) {
      try {
        listener(...args);
      } catch (error) {
        console.error(`Error in listener for event "${event}":`, error);
      }
    }
    return listeners.size > 0;
  }

  removeAllListeners(event?: string): this {
    if (event) {
      this.listeners.delete(event);
    } else {
      this.listeners.clear();
    }
    return this;
  }

  listenerCount(event: string): number {
    return this.listeners.has(event) ? this.listeners.get(event)!.size : 0;
  }

  eventNames(): string[] {
    return Array.from(this.listeners.keys());
  }
}
