import { SimpleEventEmitter } from '../utils/simple-emitter';
import { PhotonParser, PhotonEvent, Entity } from '../photon/photon-parser';
import { vpnService } from '../native/vpn-bridge';
import { mobDataLoader } from '../data/mob-data-loader';
import { resourceDataLoader } from '../data/resource-data-loader';

/**
 * Radar Engine - Integrates VPN, Photon parser, and entity detection
 */
export class RadarEngine extends SimpleEventEmitter {
  private isRunning = false;
  private entities = new Map<number, Entity>();
  private playerPosition = { x: 0, y: 0, z: 0 };
  private packetCount = 0;
  private entityCount = 0;

  constructor() {
    super();
    this.setupVpnListeners();
  }

  private setupVpnListeners() {
    vpnService.on('packet', (packet: any) => {
      this.processPacket(packet);
    });

    vpnService.on('connected', () => {
      this.emit('vpn-connected');
    });

    vpnService.on('disconnected', () => {
      this.emit('vpn-disconnected');
    });

    vpnService.on('error', (error: Error) => {
      this.emit('error', error);
    });
  }

  /**
   * Start the radar engine
   */
  async start(): Promise<void> {
    if (this.isRunning) {
      console.warn('Radar engine already running');
      return;
    }

    try {
      // Start VPN service
      await vpnService.start({ port: 5056 });

      this.isRunning = true;
      this.emit('started');
      console.log('Radar engine started');
    } catch (error) {
      console.error('Error starting radar engine:', error);
      throw error;
    }
  }

  /**
   * Stop the radar engine
   */
  async stop(): Promise<void> {
    if (!this.isRunning) {
      console.warn('Radar engine not running');
      return;
    }

    try {
      await vpnService.stop();
      this.isRunning = false;
      this.entities.clear();
      this.emit('stopped');
      console.log('Radar engine stopped');
    } catch (error) {
      console.error('Error stopping radar engine:', error);
      throw error;
    }
  }

  /**
   * Process captured packet
   */
  private processPacket(packet: any) {
    try {
      const data = Buffer.from(packet.data, 'base64');
      const event = PhotonParser.parseEvent(new Uint8Array(data));

      if (!event) return;

      this.packetCount++;

      // Extract entity from event
      const entity = PhotonParser.extractEntity(event);
      if (entity) {
        this.updateEntity(entity);
      }

      // Handle specific event types
      this.handleEvent(event);

      // Emit stats periodically
      if (this.packetCount % 100 === 0) {
        this.emit('stats', {
          packetsProcessed: this.packetCount,
          entitiesTracked: this.entities.size,
          timestamp: Date.now(),
        });
      }
    } catch (error) {
      console.error('Error processing packet:', error);
    }
  }

  /**
   * Update entity in tracking system
   */
  private updateEntity(entity: Entity) {
    this.entities.set(entity.id, entity);
    this.entityCount++;

    // Emit entity update
    this.emit('entity-update', entity);

    // Cleanup old entities (older than 2 minutes)
    this.cleanupStaleEntities();
  }

  /**
   * Handle specific Photon events
   */
  private handleEvent(event: PhotonEvent) {
    const params = event.parameters;

    // Handle player position updates
    if (event.eventCode === 6) { // PLAYER_CHANGE_STATE
      const x = params.get(1) as number;
      const y = params.get(2) as number;
      const z = params.get(3) as number;

      if (x !== undefined && y !== undefined) {
        this.playerPosition = { x, y, z: z || 0 };
        this.emit('player-position', this.playerPosition);
      }
    }

    // Handle object removal
    if (event.eventCode === 9) { // REMOVE_OBJECT
      const objectId = params.get(0) as number;
      if (objectId) {
        this.entities.delete(objectId);
        this.emit('entity-removed', objectId);
      }
    }
  }

  /**
   * Clean up stale entities
   */
  private cleanupStaleEntities() {
    const now = Date.now();
    const maxAge = 2 * 60 * 1000; // 2 minutes

    for (const [id, entity] of this.entities.entries()) {
      // Simple cleanup based on entity type
      // In a real implementation, we'd track timestamps
      if (entity.type === 'mob' && Math.random() > 0.99) {
        this.entities.delete(id);
      }
    }
  }

  /**
   * Get all entities of a specific type
   */
  getEntities(type?: 'resource' | 'mob' | 'player' | 'chest' | 'npc'): Entity[] {
    if (!type) {
      return Array.from(this.entities.values());
    }
    return Array.from(this.entities.values()).filter(e => e.type === type);
  }

  /**
   * Get entities near player
   */
  getEntitiesNearPlayer(radius: number = 100): Entity[] {
    const nearby: Entity[] = [];
    const radiusSq = radius * radius;

    for (const entity of this.entities.values()) {
      const dx = entity.x - this.playerPosition.x;
      const dy = entity.y - this.playerPosition.y;
      const distSq = dx * dx + dy * dy;

      if (distSq <= radiusSq) {
        nearby.push(entity);
      }
    }

    return nearby.sort((a, b) => {
      const distA = Math.hypot(a.x - this.playerPosition.x, a.y - this.playerPosition.y);
      const distB = Math.hypot(b.x - this.playerPosition.x, b.y - this.playerPosition.y);
      return distA - distB;
    });
  }

  /**
   * Get player position
   */
  getPlayerPosition() {
    return this.playerPosition;
  }

  /**
   * Get engine stats
   */
  getStats() {
    return {
      isRunning: this.isRunning,
      packetsProcessed: this.packetCount,
      entitiesTracked: this.entities.size,
      resources: this.getEntities('resource').length,
      mobs: this.getEntities('mob').length,
      players: this.getEntities('player').length,
      chests: this.getEntities('chest').length,
      playerPosition: this.playerPosition,
      timestamp: Date.now(),
    };
  }

  /**
   * Check if engine is running
   */
  isActive(): boolean {
    return this.isRunning;
  }

  /**
   * Reset engine state
   */
  reset() {
    this.entities.clear();
    this.packetCount = 0;
    this.entityCount = 0;
    this.playerPosition = { x: 0, y: 0, z: 0 };
    this.emit('reset');
  }
}

export default RadarEngine;
