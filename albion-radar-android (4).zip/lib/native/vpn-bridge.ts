import { NativeModules, NativeEventEmitter, Platform } from 'react-native';
import { SimpleEventEmitter } from '../utils/simple-emitter';

const { AlbionVpnService, OverlayModule } = NativeModules;

if (!AlbionVpnService) {
  console.warn('AlbionVpnService native module not available');
}

if (!OverlayModule) {
  console.warn('OverlayModule native module not available');
}

/**
 * VPN Service Bridge - Communicates with native Android VPN service
 */
export class VpnServiceBridge {
  private emitter = new SimpleEventEmitter();
  private isConnected = false;
  private eventEmitter: NativeEventEmitter | null = null;

  constructor() {
    if (Platform.OS === 'android' && AlbionVpnService) {
      this.eventEmitter = new NativeEventEmitter(AlbionVpnService);
      this.setupListeners();
    }
  }

  on(event: string, listener: (...args: any[]) => void) {
    this.emitter.on(event, listener);
  }

  emit(event: string, ...args: any[]) {
    this.emitter.emit(event, ...args);
  }

  removeAllListeners() {
    this.emitter.removeAllListeners();
  }

  private setupListeners() {
    if (!this.eventEmitter) return;

    if (!this.eventEmitter) return;
    
    this.eventEmitter.addListener('VpnConnected', () => {
      this.isConnected = true;
      this.emitter.emit('connected');
    });

    this.eventEmitter.addListener('VpnDisconnected', () => {
      this.isConnected = false;
      this.emitter.emit('disconnected');
    });

    this.eventEmitter.addListener('PacketCaptured', (packet: any) => {
      this.emitter.emit('packet', packet);
    });

    this.eventEmitter.addListener('VpnError', (error: string) => {
      this.emitter.emit('error', new Error(error));
    });
  }

  async requestPermission(): Promise<boolean> {
    if (!AlbionVpnService) {
      console.warn('VPN service not available');
      return false;
    }

    try {
      const hasPermission = await AlbionVpnService.requestVpnPermission();
      return hasPermission;
    } catch (error) {
      console.error('Error requesting VPN permission:', error);
      return false;
    }
  }

  async start(config: { port?: number } = {}): Promise<void> {
    if (!AlbionVpnService) {
      throw new Error('VPN service not available');
    }

    try {
      await AlbionVpnService.startVpnService({
        port: config.port || 5056,
      });
      this.isConnected = true;
      this.emitter.emit('started');
    } catch (error) {
      console.error('Error starting VPN service:', error);
      throw error;
    }
  }

  async stop(): Promise<void> {
    if (!AlbionVpnService) {
      throw new Error('VPN service not available');
    }

    try {
      await AlbionVpnService.stopVpnService();
      this.isConnected = false;
      this.emitter.emit('stopped');
    } catch (error) {
      console.error('Error stopping VPN service:', error);
      throw error;
    }
  }

  async getStats(): Promise<any> {
    if (!AlbionVpnService) {
      return { isRunning: false };
    }

    try {
      return await AlbionVpnService.getVpnStats();
    } catch (error) {
      console.error('Error getting VPN stats:', error);
      return { isRunning: false };
    }
  }

  isActive(): boolean {
    return this.isConnected;
  }
}

/**
 * Overlay Service Bridge - Communicates with native overlay service
 */
export class OverlayServiceBridge {
  private emitter = new SimpleEventEmitter();
  private isVisible = false;

  constructor() {}

  on(event: string, listener: (...args: any[]) => void) {
    this.emitter.on(event, listener);
  }

  emit(event: string, ...args: any[]) {
    this.emitter.emit(event, ...args);
  }

  removeAllListeners() {
    this.emitter.removeAllListeners();
  }

  async requestPermission(): Promise<boolean> {
    if (!OverlayModule) {
      console.warn('OverlayModule not available');
      return false;
    }

    try {
      const result = await OverlayModule.requestOverlayPermission();
      return result === true;
    } catch (error) {
      console.error('Error requesting overlay permission:', error);
      return false;
    }
  }

  async show(): Promise<void> {
    if (!OverlayModule) {
      throw new Error('Overlay module not available');
    }

    try {
      await OverlayModule.showOverlay();
      this.isVisible = true;
      this.emitter.emit('shown');
    } catch (error) {
      console.error('Error showing overlay:', error);
      throw error;
    }
  }

  async hide(): Promise<void> {
    if (!OverlayModule) {
      throw new Error('Overlay module not available');
    }

    try {
      await OverlayModule.hideOverlay();
      this.isVisible = false;
      this.emitter.emit('hidden');
    } catch (error) {
      console.error('Error hiding overlay:', error);
      throw error;
    }
  }

  async update(entities: any[], playerX: number, playerY: number): Promise<void> {
    if (!OverlayModule) {
      return;
    }

    try {
      await OverlayModule.updateOverlay(entities, playerX, playerY);
      this.emitter.emit('updated');
    } catch (error) {
      console.error('Error updating overlay:', error);
    }
  }

  isActive(): boolean {
    return this.isVisible;
  }
}

// Export singleton instances
export const vpnService = new VpnServiceBridge();
export const overlayService = new OverlayServiceBridge();
