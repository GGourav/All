/**
 * VPN Service Native Module Interface
 * Bridges TypeScript with native Android VPN service implementation
 * Handles packet capture on port 5056 (Albion game server)
 */

import { NativeModules, NativeEventEmitter, Platform } from 'react-native';

const { AlbionVpnService } = NativeModules;

export interface VpnServiceConfig {
  port?: number; // Default: 5056 (Albion)
  bufferSize?: number; // Packet buffer size
  enableLogging?: boolean;
}

export interface PacketData {
  timestamp: number;
  sourceIp: string;
  destIp: string;
  port: number;
  data: string; // Base64 encoded
  length: number;
}

export enum VpnServiceStatus {
  Stopped = 'stopped',
  Starting = 'starting',
  Running = 'running',
  Stopping = 'stopping',
  Error = 'error',
}

export interface VpnServiceEvent {
  type: 'status' | 'packet' | 'error' | 'stats';
  data: any;
}

class VpnServiceManager {
  private eventEmitter: NativeEventEmitter | null = null;
  private status: VpnServiceStatus = VpnServiceStatus.Stopped;
  private listeners: Map<string, Set<Function>> = new Map();
  private packetBuffer: PacketData[] = [];
  private maxBufferSize: number = 1000;

  constructor() {
    if (Platform.OS === 'android' && AlbionVpnService) {
      this.eventEmitter = new NativeEventEmitter(AlbionVpnService);
      this.setupEventListeners();
    }
  }

  /**
   * Setup native event listeners
   */
  private setupEventListeners(): void {
    if (!this.eventEmitter) return;

    // Listen for status changes
    this.eventEmitter.addListener('vpnStatusChanged', (event: VpnServiceEvent) => {
      this.status = event.data.status;
      this.emit('statusChanged', event.data);
    });

    // Listen for packets
    this.eventEmitter.addListener('packetReceived', (event: VpnServiceEvent) => {
      const packet = event.data as PacketData;
      this.handlePacket(packet);
      this.emit('packetReceived', packet);
    });

    // Listen for errors
    this.eventEmitter.addListener('vpnError', (event: VpnServiceEvent) => {
      this.status = VpnServiceStatus.Error;
      this.emit('error', event.data);
    });

    // Listen for statistics
    this.eventEmitter.addListener('vpnStats', (event: VpnServiceEvent) => {
      this.emit('stats', event.data);
    });
  }

  /**
   * Start VPN service
   */
  async start(config: VpnServiceConfig = {}): Promise<void> {
    if (!AlbionVpnService) {
      throw new Error('VPN Service not available on this platform');
    }

    if (this.status === VpnServiceStatus.Running) {
      console.warn('VPN Service already running');
      return;
    }

    this.status = VpnServiceStatus.Starting;

    try {
      await AlbionVpnService.startVpnService({
        port: config.port || 5056,
        bufferSize: config.bufferSize || 65536,
        enableLogging: config.enableLogging || false,
      });

      this.emit('started', { timestamp: Date.now() });
    } catch (error) {
      this.status = VpnServiceStatus.Error;
      this.emit('error', { message: 'Failed to start VPN service', error });
      throw error;
    }
  }

  /**
   * Stop VPN service
   */
  async stop(): Promise<void> {
    if (!AlbionVpnService) {
      return;
    }

    if (this.status === VpnServiceStatus.Stopped) {
      console.warn('VPN Service already stopped');
      return;
    }

    this.status = VpnServiceStatus.Stopping;

    try {
      await AlbionVpnService.stopVpnService();
      this.status = VpnServiceStatus.Stopped;
      this.emit('stopped', { timestamp: Date.now() });
    } catch (error) {
      this.status = VpnServiceStatus.Error;
      this.emit('error', { message: 'Failed to stop VPN service', error });
      throw error;
    }
  }

  /**
   * Handle incoming packet
   */
  private handlePacket(packet: PacketData): void {
    // Add to buffer
    this.packetBuffer.push(packet);

    // Maintain buffer size
    if (this.packetBuffer.length > this.maxBufferSize) {
      this.packetBuffer.shift();
    }
  }

  /**
   * Get current status
   */
  getStatus(): VpnServiceStatus {
    return this.status;
  }

  /**
   * Check if service is running
   */
  isRunning(): boolean {
    return this.status === VpnServiceStatus.Running;
  }

  /**
   * Get buffered packets
   */
  getPackets(limit?: number): PacketData[] {
    if (!limit) {
      return [...this.packetBuffer];
    }
    return this.packetBuffer.slice(-limit);
  }

  /**
   * Clear packet buffer
   */
  clearPackets(): void {
    this.packetBuffer = [];
  }

  /**
   * Get service statistics
   */
  async getStats(): Promise<any> {
    if (!AlbionVpnService) {
      return null;
    }

    try {
      return await AlbionVpnService.getVpnStats();
    } catch (error) {
      console.error('Failed to get VPN stats:', error);
      return null;
    }
  }

  /**
   * Request VPN permission
   */
  async requestPermission(): Promise<boolean> {
    if (!AlbionVpnService) {
      return false;
    }

    try {
      const result = await AlbionVpnService.requestVpnPermission();
      return result === true;
    } catch (error) {
      console.error('Failed to request VPN permission:', error);
      return false;
    }
  }

  /**
   * Register event listener
   */
  on(event: string, callback: Function): void {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, new Set());
    }
    this.listeners.get(event)!.add(callback);
  }

  /**
   * Unregister event listener
   */
  off(event: string, callback: Function): void {
    if (this.listeners.has(event)) {
      this.listeners.get(event)!.delete(callback);
    }
  }

  /**
   * Emit event to listeners
   */
  private emit(event: string, data: any): void {
    if (this.listeners.has(event)) {
      this.listeners.get(event)!.forEach((callback) => {
        try {
          callback(data);
        } catch (error) {
          console.error(`Error in ${event} listener:`, error);
        }
      });
    }
  }

  /**
   * Cleanup resources
   */
  destroy(): void {
    if (this.eventEmitter) {
      this.eventEmitter.removeAllListeners('vpnStatusChanged');
      this.eventEmitter.removeAllListeners('packetReceived');
      this.eventEmitter.removeAllListeners('vpnError');
      this.eventEmitter.removeAllListeners('vpnStats');
    }
    this.listeners.clear();
    this.packetBuffer = [];
  }
}

// Create singleton instance
export const vpnServiceManager = new VpnServiceManager();

// Export for use in components
export function startVpnService(config?: VpnServiceConfig): Promise<void> {
  return vpnServiceManager.start(config);
}

export function stopVpnService(): Promise<void> {
  return vpnServiceManager.stop();
}

export function getVpnStatus(): VpnServiceStatus {
  return vpnServiceManager.getStatus();
}

export function isVpnRunning(): boolean {
  return vpnServiceManager.isRunning();
}

export function getVpnPackets(limit?: number): PacketData[] {
  return vpnServiceManager.getPackets(limit);
}

export function onVpnPacket(callback: (packet: PacketData) => void): void {
  vpnServiceManager.on('packetReceived', callback);
}

export function offVpnPacket(callback: (packet: PacketData) => void): void {
  vpnServiceManager.off('packetReceived', callback);
}

export function onVpnStatusChange(callback: (status: VpnServiceStatus) => void): void {
  vpnServiceManager.on('statusChanged', callback);
}

export function offVpnStatusChange(callback: (status: VpnServiceStatus) => void): void {
  vpnServiceManager.off('statusChanged', callback);
}

export function onVpnError(callback: (error: any) => void): void {
  vpnServiceManager.on('error', callback);
}

export function offVpnError(callback: (error: any) => void): void {
  vpnServiceManager.off('error', callback);
}
