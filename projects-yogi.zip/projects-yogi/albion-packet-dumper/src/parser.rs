use nom::{
    bytes::complete::take,
    number::complete::{be_u16, be_u32, le_f32, u8 as nom_u8},
    IResult,
};

use crate::{PlayerData, Position};

// Photon Protocol Constants
const PHOTON_SIGNATURE: u8 = 0xF3;
const MESSAGE_TYPE_EVENT: u8 = 4;
const MESSAGE_TYPE_OPERATION_REQUEST: u8 = 6;
const MESSAGE_TYPE_OPERATION_RESPONSE: u8 = 7;

// Photon Command Types
const COMMAND_TYPE_RELIABLE: u8 = 6;
const COMMAND_TYPE_UNRELIABLE: u8 = 7;

// Albion Event Codes
const EVENT_LEAVE: u8 = 1;
const EVENT_MOVE: u8 = 3;
const EVENT_NEW_CHARACTER: u8 = 29;
const EVENT_HEALTH_UPDATE: u8 = 6;
const EVENT_REGENERATION_HEALTH_CHANGED: u8 = 91;

// Protocol16 Type Codes
const TYPE_BYTE: u8 = 0x62; // 'b'
const TYPE_INT: u8 = 0x69; // 'i'
const TYPE_STRING: u8 = 0x73; // 's'
const TYPE_ARRAY: u8 = 0x79; // 'y'
const TYPE_HASHTABLE: u8 = 0x68; // 'h'
const TYPE_FLOAT: u8 = 0x66; // 'f'
const TYPE_LONG: u8 = 0x6C; // 'l'

// NewCharacter Event Parameters (Event Code 29)
const PARAM_ENTITY_ID: u8 = 0;
const PARAM_NICKNAME: u8 = 1;
const PARAM_GUILD_NAME: u8 = 8;
const PARAM_EQUIPMENT: u8 = 40;
const PARAM_SPELLS: u8 = 43;
const PARAM_ALLIANCE_NAME: u8 = 51;
const PARAM_FACTION: u8 = 53;

// Move Event Parameters (Event Code 3)
const PARAM_POSITION_X: u8 = 4;
const PARAM_POSITION_Y: u8 = 5;

#[derive(Debug, Clone)]
pub struct PhotonPacket {
    pub peer_id: u16,
    pub commands: Vec<PhotonCommand>,
}

#[derive(Debug, Clone)]
pub struct PhotonCommand {
    pub command_type: u8,
    pub channel_id: u8,
    pub message_type: u8,
    pub event_code: u8,
    pub parameters: Vec<(u8, ParameterValue)>,
}

#[derive(Debug, Clone)]
pub enum ParameterValue {
    Byte(u8),
    Int(i32),
    Long(i64),
    Float(f32),
    String(String),
    Array(Vec<ParameterValue>),
    Hashtable(Vec<(ParameterValue, ParameterValue)>),
    Unknown,
}

/// Parse an Albion Online packet and extract player data
pub fn parse_albion_packet(data: &[u8]) -> (Option<String>, Option<PlayerData>) {
    match parse_photon_packet(data) {
        Ok((_, packet)) => {
            for command in &packet.commands {
                // Debug: Print message type and event code for first 10 packets
                static DEBUG_COUNT: std::sync::atomic::AtomicUsize =
                    std::sync::atomic::AtomicUsize::new(0);
                let count = DEBUG_COUNT.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
                if count < 10 {
                    eprintln!(
                        "[DEBUG] Packet #{}: msg_type={}, event_code={}, params={}",
                        count,
                        command.message_type,
                        command.event_code,
                        command.parameters.len()
                    );
                }

                // Only process event messages
                if command.message_type != MESSAGE_TYPE_EVENT {
                    continue;
                }

                let packet_type = match command.event_code {
                    EVENT_NEW_CHARACTER => "NewCharacter",
                    EVENT_MOVE => "Move",
                    EVENT_LEAVE => "Leave",
                    EVENT_HEALTH_UPDATE => "HealthUpdate",
                    EVENT_REGENERATION_HEALTH_CHANGED => "RegenHealthChanged",
                    _ => "Unknown",
                };

                let player_data = match command.event_code {
                    EVENT_NEW_CHARACTER => parse_new_character_event(&command.parameters),
                    EVENT_MOVE => parse_move_event(&command.parameters),
                    _ => None,
                };

                if player_data.is_some() {
                    return (Some(packet_type.to_string()), player_data);
                }
            }
            (None, None)
        }
        Err(e) => {
            // Debug: Print parse errors for first 5 packets
            static ERROR_COUNT: std::sync::atomic::AtomicUsize =
                std::sync::atomic::AtomicUsize::new(0);
            let count = ERROR_COUNT.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
            if count < 5 {
                eprintln!("[DEBUG] Parse error #{}: {:?}", count, e);
            }
            (None, None)
        }
    }
}

/// Parse Photon packet header and commands
fn parse_photon_packet(input: &[u8]) -> IResult<&[u8], PhotonPacket> {
    // Photon packet header (12 bytes)
    let (input, peer_id) = be_u16(input)?;
    let (input, _flags) = nom_u8(input)?;
    let (input, command_count) = nom_u8(input)?;
    let (input, _timestamp) = be_u32(input)?;
    let (input, _challenge) = be_u32(input)?;

    // Parse commands
    let mut remaining = input;
    let mut commands = Vec::new();

    for _ in 0..command_count {
        match parse_photon_command(remaining) {
            Ok((rest, command)) => {
                remaining = rest;
                commands.push(command);
            }
            Err(_) => break,
        }
    }

    Ok((remaining, PhotonPacket { peer_id, commands }))
}

/// Parse a single Photon command
fn parse_photon_command(input: &[u8]) -> IResult<&[u8], PhotonCommand> {
    // Command header (12 bytes)
    let (input, command_type) = nom_u8(input)?;
    let (input, channel_id) = nom_u8(input)?;
    let (input, _command_flags) = nom_u8(input)?;
    let (input, _reserved) = nom_u8(input)?;
    let (input, command_length) = be_u32(input)?;
    let (input, _sequence_number) = be_u32(input)?;

    // Calculate payload length (command_length includes header)
    let payload_length = command_length.saturating_sub(12) as usize;

    if input.len() < payload_length {
        return Err(nom::Err::Error(nom::error::Error::new(
            input,
            nom::error::ErrorKind::Eof,
        )));
    }

    let (input, payload) = take(payload_length)(input)?;

    // Parse payload
    let mut payload_input = payload;

    // Skip 4 bytes for unreliable commands
    if command_type == COMMAND_TYPE_UNRELIABLE {
        if payload_input.len() < 4 {
            return Ok((
                input,
                PhotonCommand {
                    command_type,
                    channel_id,
                    message_type: 0,
                    event_code: 0,
                    parameters: Vec::new(),
                },
            ));
        }
        payload_input = &payload_input[4..];
    }

    // Check signature
    if payload_input.is_empty() || payload_input[0] != PHOTON_SIGNATURE {
        return Ok((
            input,
            PhotonCommand {
                command_type,
                channel_id,
                message_type: 0,
                event_code: 0,
                parameters: Vec::new(),
            },
        ));
    }

    payload_input = &payload_input[1..]; // Skip signature

    // Read message type
    if payload_input.is_empty() {
        return Ok((
            input,
            PhotonCommand {
                command_type,
                channel_id,
                message_type: 0,
                event_code: 0,
                parameters: Vec::new(),
            },
        ));
    }

    let message_type = payload_input[0];
    payload_input = &payload_input[1..];

    // Parse event data if this is an event message
    let (event_code, parameters) = if message_type == MESSAGE_TYPE_EVENT {
        parse_event_data(payload_input).unwrap_or((0, Vec::new()))
    } else {
        (0, Vec::new())
    };

    Ok((
        input,
        PhotonCommand {
            command_type,
            channel_id,
            message_type,
            event_code,
            parameters,
        },
    ))
}

/// Parse Protocol16 event data
fn parse_event_data(input: &[u8]) -> Option<(u8, Vec<(u8, ParameterValue)>)> {
    if input.is_empty() {
        return None;
    }

    let event_code = input[0];
    let input = &input[1..];

    // Parse parameter table
    let parameters = parse_parameter_table(input)?;

    Some((event_code, parameters))
}

/// Parse Protocol16 parameter table
fn parse_parameter_table(input: &[u8]) -> Option<Vec<(u8, ParameterValue)>> {
    if input.len() < 2 {
        return None;
    }

    // Read parameter count (big-endian u16)
    let param_count = ((input[0] as u16) << 8) | (input[1] as u16);
    let mut input = &input[2..];

    let mut parameters = Vec::new();

    for _ in 0..param_count {
        if input.len() < 2 {
            break;
        }

        let key = input[0];
        let type_code = input[1];
        input = &input[2..];

        match parse_parameter_value(type_code, input) {
            Some((rest, value)) => {
                parameters.push((key, value));
                input = rest;
            }
            None => break,
        }
    }

    Some(parameters)
}

/// Parse a single parameter value based on type code
fn parse_parameter_value(type_code: u8, input: &[u8]) -> Option<(&[u8], ParameterValue)> {
    match type_code {
        TYPE_BYTE => {
            if input.is_empty() {
                return None;
            }
            Some((&input[1..], ParameterValue::Byte(input[0])))
        }
        TYPE_INT => {
            if input.len() < 4 {
                return None;
            }
            let value = i32::from_be_bytes([input[0], input[1], input[2], input[3]]);
            Some((&input[4..], ParameterValue::Int(value)))
        }
        TYPE_LONG => {
            if input.len() < 8 {
                return None;
            }
            let value = i64::from_be_bytes([
                input[0], input[1], input[2], input[3], input[4], input[5], input[6], input[7],
            ]);
            Some((&input[8..], ParameterValue::Long(value)))
        }
        TYPE_FLOAT => {
            if input.len() < 4 {
                return None;
            }
            let value = f32::from_be_bytes([input[0], input[1], input[2], input[3]]);
            Some((&input[4..], ParameterValue::Float(value)))
        }
        TYPE_STRING => {
            if input.len() < 2 {
                return None;
            }
            let len = ((input[0] as u16) << 8) | (input[1] as u16);
            let input = &input[2..];

            if input.len() < len as usize {
                return None;
            }

            match std::str::from_utf8(&input[..len as usize]) {
                Ok(s) => Some((
                    &input[len as usize..],
                    ParameterValue::String(s.to_string()),
                )),
                Err(_) => Some((&input[len as usize..], ParameterValue::Unknown)),
            }
        }
        TYPE_ARRAY => {
            // Arrays have: u16 length, type code, then elements
            if input.len() < 3 {
                return None;
            }
            let len = ((input[0] as u16) << 8) | (input[1] as u16);
            let element_type = input[2];
            let mut input = &input[3..];

            let mut elements = Vec::new();
            for _ in 0..len {
                match parse_parameter_value(element_type, input) {
                    Some((rest, value)) => {
                        elements.push(value);
                        input = rest;
                    }
                    None => break,
                }
            }

            Some((input, ParameterValue::Array(elements)))
        }
        _ => Some((input, ParameterValue::Unknown)),
    }
}

/// Parse NewCharacter event (Event Code 29) to extract player data
fn parse_new_character_event(parameters: &[(u8, ParameterValue)]) -> Option<PlayerData> {
    let mut player_id = None;
    let mut player_name = None;
    let mut guild_name = None;
    let mut alliance_name = None;

    for (key, value) in parameters {
        match *key {
            PARAM_ENTITY_ID => {
                if let ParameterValue::Int(id) = value {
                    player_id = Some(id.to_string());
                }
            }
            PARAM_NICKNAME => {
                if let ParameterValue::String(name) = value {
                    player_name = Some(name.clone());
                }
            }
            PARAM_GUILD_NAME => {
                if let ParameterValue::String(guild) = value {
                    if !guild.is_empty() {
                        guild_name = Some(guild.clone());
                    }
                }
            }
            PARAM_ALLIANCE_NAME => {
                if let ParameterValue::String(alliance) = value {
                    if !alliance.is_empty() {
                        alliance_name = Some(alliance.clone());
                    }
                }
            }
            _ => {}
        }
    }

    if player_name.is_some() || guild_name.is_some() {
        Some(PlayerData {
            player_id,
            player_name,
            guild_name,
            alliance_name,
            position: None,
        })
    } else {
        None
    }
}

/// Parse Move event (Event Code 3) to extract position data
fn parse_move_event(parameters: &[(u8, ParameterValue)]) -> Option<PlayerData> {
    let mut entity_id = None;
    let mut x = None;
    let mut y = None;

    for (key, value) in parameters {
        match *key {
            PARAM_ENTITY_ID => {
                if let ParameterValue::Int(id) = value {
                    entity_id = Some(id.to_string());
                }
            }
            PARAM_POSITION_X => {
                if let ParameterValue::Float(pos_x) = value {
                    x = Some(*pos_x);
                }
            }
            PARAM_POSITION_Y => {
                if let ParameterValue::Float(pos_y) = value {
                    y = Some(*pos_y);
                }
            }
            _ => {}
        }
    }

    if let (Some(x_val), Some(y_val)) = (x, y) {
        Some(PlayerData {
            player_id: entity_id,
            player_name: None,
            guild_name: None,
            alliance_name: None,
            position: Some(Position {
                x: x_val,
                y: y_val,
                z: 0.0, // Z not used in move events
            }),
        })
    } else {
        None
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_parse_parameter_value_byte() {
        let data = [0x42];
        let result = parse_parameter_value(TYPE_BYTE, &data);
        assert!(result.is_some());
        if let Some((_, ParameterValue::Byte(val))) = result {
            assert_eq!(val, 0x42);
        }
    }

    #[test]
    fn test_parse_parameter_value_int() {
        let data = [0x00, 0x00, 0x00, 0x2A]; // 42 in big-endian
        let result = parse_parameter_value(TYPE_INT, &data);
        assert!(result.is_some());
        if let Some((_, ParameterValue::Int(val))) = result {
            assert_eq!(val, 42);
        }
    }

    #[test]
    fn test_parse_parameter_value_string() {
        let data = [0x00, 0x05, b'H', b'e', b'l', b'l', b'o']; // Length 5 + "Hello"
        let result = parse_parameter_value(TYPE_STRING, &data);
        assert!(result.is_some());
        if let Some((_, ParameterValue::String(val))) = result {
            assert_eq!(val, "Hello");
        }
    }
}
