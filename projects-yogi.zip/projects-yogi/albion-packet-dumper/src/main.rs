use anyhow::{Context, Result};
use chrono::{DateTime, Utc};
use clap::Parser;
use log::{debug, info, warn};
use pcap::{Capture, Device};
use pnet::packet::{
    ethernet::{EtherTypes, EthernetPacket},
    ip::IpNextHeaderProtocols,
    ipv4::Ipv4Packet,
    tcp::TcpPacket,
    udp::UdpPacket,
    Packet,
};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::fs::File;
use std::io::Write;
use std::path::PathBuf;
use std::sync::{Arc, Mutex};

mod parser;
mod ui;
use parser::*;
use ui::PlayerTracker;

/// Albion Online Packet Dumper - Network packet capture and player detection
#[derive(Parser, Debug)]
#[command(author, version, about, long_about = None)]
struct Args {
    /// Network interface to capture from
    #[arg(short, long)]
    interface: Option<String>,

    /// Output directory for logs
    #[arg(short, long, default_value = "albion_logs")]
    output: PathBuf,

    /// Capture filter (BPF syntax)
    #[arg(short, long)]
    filter: Option<String>,

    /// Albion Online server ports (comma-separated)
    #[arg(short, long, default_value = "5056,5057")]
    ports: String,

    /// Enable verbose logging
    #[arg(short, long)]
    verbose: bool,

    /// Enable terminal UI mode (shows live player positions)
    #[arg(long)]
    ui: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct Player {
    id: String,
    name: String,
    guild: Option<String>,
    alliance: Option<String>,
    position: Option<Position>,
    first_seen: DateTime<Utc>,
    last_seen: DateTime<Utc>,
    ip_address: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct Position {
    x: f32,
    y: f32,
    z: f32,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct PacketInfo {
    packet_id: u64,
    timestamp: DateTime<Utc>,
    src_ip: String,
    src_port: u16,
    dst_ip: String,
    dst_port: u16,
    protocol: String,
    payload_length: usize,
    packet_type: Option<String>,
    player_data: Option<PlayerData>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct PlayerData {
    player_id: Option<String>,
    player_name: Option<String>,
    guild_name: Option<String>,
    alliance_name: Option<String>,
    position: Option<Position>,
}

struct PacketDumper {
    output_dir: PathBuf,
    packet_count: Arc<Mutex<u64>>,
    players: Arc<Mutex<HashMap<String, Player>>>,
    log_file: Arc<Mutex<File>>,
    json_file: Arc<Mutex<File>>,
    ports: Vec<u16>,
    ui_tracker: Option<Arc<PlayerTracker>>,
    my_ip: Arc<Mutex<Option<String>>>,
}

impl PacketDumper {
    fn new(output_dir: PathBuf, ports: Vec<u16>, enable_ui: bool) -> Result<Self> {
        std::fs::create_dir_all(&output_dir)?;

        let timestamp = Utc::now().format("%Y%m%d_%H%M%S");
        let log_path = output_dir.join(format!("albion_packets_{}.log", timestamp));
        let json_path = output_dir.join(format!("albion_packets_{}.json", timestamp));
        let players_path = output_dir.join(format!("players_{}.json", timestamp));

        let mut log_file = File::create(&log_path)?;
        writeln!(log_file, "{}", "=".repeat(80))?;
        writeln!(log_file, "Albion Online Packet Dumper")?;
        writeln!(log_file, "Session started: {}", Utc::now())?;
        writeln!(log_file, "Monitoring ports: {:?}", ports)?;
        writeln!(log_file, "{}", "=".repeat(80))?;

        let json_file = File::create(&json_path)?;

        info!("Logging to: {:?}", log_path);
        info!("JSON log: {:?}", json_path);
        info!("Players log: {:?}", players_path);

        let ui_tracker = if enable_ui {
            Some(Arc::new(PlayerTracker::new()))
        } else {
            None
        };

        Ok(Self {
            output_dir,
            packet_count: Arc::new(Mutex::new(0)),
            players: Arc::new(Mutex::new(HashMap::new())),
            log_file: Arc::new(Mutex::new(log_file)),
            json_file: Arc::new(Mutex::new(json_file)),
            ports,
            ui_tracker,
            my_ip: Arc::new(Mutex::new(None)),
        })
    }

    fn is_albion_port(&self, port: u16) -> bool {
        self.ports.contains(&port)
    }

    fn handle_packet(&self, packet_data: &[u8]) -> Result<()> {
        let ethernet =
            EthernetPacket::new(packet_data).context("Failed to parse Ethernet packet")?;

        match ethernet.get_ethertype() {
            EtherTypes::Ipv4 => {
                if let Some(ipv4) = Ipv4Packet::new(ethernet.payload()) {
                    self.handle_ipv4_packet(&ipv4)?;
                }
            }
            _ => {}
        }

        Ok(())
    }

    fn handle_ipv4_packet(&self, ipv4: &Ipv4Packet) -> Result<()> {
        let src_ip = ipv4.get_source().to_string();
        let dst_ip = ipv4.get_destination().to_string();

        match ipv4.get_next_level_protocol() {
            IpNextHeaderProtocols::Tcp => {
                if let Some(tcp) = TcpPacket::new(ipv4.payload()) {
                    self.handle_tcp_packet(&src_ip, &dst_ip, &tcp)?;
                }
            }
            IpNextHeaderProtocols::Udp => {
                if let Some(udp) = UdpPacket::new(ipv4.payload()) {
                    self.handle_udp_packet(&src_ip, &dst_ip, &udp)?;
                }
            }
            _ => {}
        }

        Ok(())
    }

    fn handle_tcp_packet(&self, src_ip: &str, dst_ip: &str, tcp: &TcpPacket) -> Result<()> {
        let src_port = tcp.get_source();
        let dst_port = tcp.get_destination();

        if !self.is_albion_port(src_port) && !self.is_albion_port(dst_port) {
            return Ok(());
        }

        let payload = tcp.payload();
        self.process_packet(src_ip, src_port, dst_ip, dst_port, "TCP", payload)?;

        Ok(())
    }

    fn handle_udp_packet(&self, src_ip: &str, dst_ip: &str, udp: &UdpPacket) -> Result<()> {
        let src_port = udp.get_source();
        let dst_port = udp.get_destination();

        if !self.is_albion_port(src_port) && !self.is_albion_port(dst_port) {
            return Ok(());
        }

        let payload = udp.payload();
        self.process_packet(src_ip, src_port, dst_ip, dst_port, "UDP", payload)?;

        Ok(())
    }

    fn process_packet(
        &self,
        src_ip: &str,
        src_port: u16,
        dst_ip: &str,
        dst_port: u16,
        protocol: &str,
        payload: &[u8],
    ) -> Result<()> {
        let mut count = self.packet_count.lock().unwrap();
        *count += 1;
        let packet_id = *count;

        let timestamp = Utc::now();

        // Detect if this is my IP (outgoing packets)
        if self.is_albion_port(dst_port) {
            let mut my_ip = self.my_ip.lock().unwrap();
            *my_ip = Some(src_ip.to_string());
        }

        // Try to parse Albion packet
        let (packet_type, player_data) = parse_albion_packet(payload);

        // Update player database if we found player data
        if let Some(ref pd) = player_data {
            self.update_player_database(pd, src_ip, timestamp)?;

            // Update UI tracker if enabled
            if let Some(ref tracker) = self.ui_tracker {
                // Check if this packet is about me (from server to my IP)
                let my_ip_lock = self.my_ip.lock().unwrap();
                let is_my_data = if let Some(ref my_ip) = *my_ip_lock {
                    dst_ip == my_ip && self.is_albion_port(src_port)
                } else {
                    false
                };
                drop(my_ip_lock);

                // Update tracker
                if let Some(ref pos) = pd.position {
                    let ui_pos = ui::Position {
                        x: pos.x,
                        y: pos.y,
                        z: pos.z,
                    };

                    if is_my_data {
                        // This is my position
                        tracker.set_my_position(ui_pos);
                    } else if let Some(ref name) = pd.player_name {
                        // This is another player
                        tracker.update_player(name.clone(), pd.guild_name.clone(), ui_pos);
                    }
                }
            }
        }

        // Create packet info
        let packet_info = PacketInfo {
            packet_id,
            timestamp,
            src_ip: src_ip.to_string(),
            src_port,
            dst_ip: dst_ip.to_string(),
            dst_port,
            protocol: protocol.to_string(),
            payload_length: payload.len(),
            packet_type,
            player_data,
        };

        // Log to text file
        self.log_packet_text(&packet_info, payload)?;

        // Log to JSON file
        self.log_packet_json(&packet_info)?;

        if packet_id % 10 == 0 && self.ui_tracker.is_none() {
            print!("\rCaptured {} packets...", packet_id);
            std::io::stdout().flush()?;
        }

        Ok(())
    }

    fn update_player_database(
        &self,
        player_data: &PlayerData,
        ip: &str,
        timestamp: DateTime<Utc>,
    ) -> Result<()> {
        let mut players = self.players.lock().unwrap();

        if let Some(ref player_id) = player_data.player_id {
            let player = players.entry(player_id.clone()).or_insert_with(|| {
                info!(
                    "New player detected: {} (ID: {})",
                    player_data.player_name.as_deref().unwrap_or("Unknown"),
                    player_id
                );
                Player {
                    id: player_id.clone(),
                    name: player_data.player_name.clone().unwrap_or_default(),
                    guild: None,
                    alliance: None,
                    position: None,
                    first_seen: timestamp,
                    last_seen: timestamp,
                    ip_address: Some(ip.to_string()),
                }
            });

            // Update player info
            player.last_seen = timestamp;
            if let Some(ref name) = player_data.player_name {
                player.name = name.clone();
            }
            if let Some(ref guild) = player_data.guild_name {
                player.guild = Some(guild.clone());
            }
            if let Some(ref alliance) = player_data.alliance_name {
                player.alliance = Some(alliance.clone());
            }
            if let Some(ref pos) = player_data.position {
                player.position = Some(pos.clone());
            }
        }

        Ok(())
    }

    fn log_packet_text(&self, info: &PacketInfo, payload: &[u8]) -> Result<()> {
        let mut log_file = self.log_file.lock().unwrap();

        let marker = if info.player_data.is_some() {
            "[PLAYER DATA]"
        } else {
            ""
        };

        writeln!(log_file)?;
        writeln!(log_file, "{}", "=".repeat(80))?;
        writeln!(
            log_file,
            "{} Packet #{} - {}",
            marker, info.packet_id, info.timestamp
        )?;
        writeln!(
            log_file,
            "{}: {}:{} -> {}:{}",
            info.protocol, info.src_ip, info.src_port, info.dst_ip, info.dst_port
        )?;
        writeln!(log_file, "Payload Length: {} bytes", info.payload_length)?;

        if let Some(ref ptype) = info.packet_type {
            writeln!(log_file, "Packet Type: {}", ptype)?;
        }

        if let Some(ref pd) = info.player_data {
            writeln!(log_file, "\n--- Player Data ---")?;
            if let Some(ref id) = pd.player_id {
                writeln!(log_file, "Player ID: {}", id)?;
            }
            if let Some(ref name) = pd.player_name {
                writeln!(log_file, "Player Name: {}", name)?;
            }
            if let Some(ref guild) = pd.guild_name {
                writeln!(log_file, "Guild: {}", guild)?;
            }
            if let Some(ref alliance) = pd.alliance_name {
                writeln!(log_file, "Alliance: {}", alliance)?;
            }
            if let Some(ref pos) = pd.position {
                writeln!(
                    log_file,
                    "Position: ({:.2}, {:.2}, {:.2})",
                    pos.x, pos.y, pos.z
                )?;
            }
        }

        if !payload.is_empty() {
            writeln!(log_file, "\nHex Dump:")?;
            writeln!(log_file, "{}", format_hex_dump(payload))?;
        }

        log_file.flush()?;
        Ok(())
    }

    fn log_packet_json(&self, info: &PacketInfo) -> Result<()> {
        let mut json_file = self.json_file.lock().unwrap();
        let json_str = serde_json::to_string(info)?;
        writeln!(json_file, "{}", json_str)?;
        json_file.flush()?;
        Ok(())
    }

    fn save_players(&self) -> Result<()> {
        let timestamp = Utc::now().format("%Y%m%d_%H%M%S");
        let players_path = self.output_dir.join(format!("players_{}.json", timestamp));

        let players = self.players.lock().unwrap();
        let mut file = File::create(&players_path)?;
        let json = serde_json::to_string_pretty(&*players)?;
        file.write_all(json.as_bytes())?;

        info!("Saved {} players to {:?}", players.len(), players_path);
        Ok(())
    }

    fn print_summary(&self) -> Result<()> {
        let count = self.packet_count.lock().unwrap();
        let players = self.players.lock().unwrap();

        println!("\n\n{}", "=".repeat(80));
        println!("Capture Summary");
        println!("{}", "=".repeat(80));
        println!("Total packets captured: {}", *count);
        println!("Total players detected: {}", players.len());
        println!("\nPlayers:");
        println!("{}", "-".repeat(80));

        for player in players.values() {
            println!("  {} (ID: {})", player.name, player.id);
            if let Some(ref guild) = player.guild {
                println!("    Guild: {}", guild);
            }
            if let Some(ref alliance) = player.alliance {
                println!("    Alliance: {}", alliance);
            }
            if let Some(ref pos) = player.position {
                println!("    Position: ({:.2}, {:.2}, {:.2})", pos.x, pos.y, pos.z);
            }
            println!("    First seen: {}", player.first_seen);
            println!("    Last seen: {}", player.last_seen);
            if let Some(ref ip) = player.ip_address {
                println!("    IP: {}", ip);
            }
            println!();
        }

        println!("{}", "=".repeat(80));
        Ok(())
    }
}

fn format_hex_dump(data: &[u8]) -> String {
    let bytes_per_line = 16;
    let mut result = String::new();

    for (i, chunk) in data.chunks(bytes_per_line).enumerate() {
        let offset = i * bytes_per_line;
        let hex_part: String = chunk
            .iter()
            .map(|b| format!("{:02x}", b))
            .collect::<Vec<_>>()
            .join(" ");

        let ascii_part: String = chunk
            .iter()
            .map(|&b| {
                if (32..127).contains(&b) {
                    b as char
                } else {
                    '.'
                }
            })
            .collect();

        result.push_str(&format!(
            "{:08x}  {:<48}  {}\n",
            offset, hex_part, ascii_part
        ));
    }

    result
}

fn main() -> Result<()> {
    let args = Args::parse();

    // Initialize logger
    env_logger::Builder::from_default_env()
        .filter_level(if args.verbose {
            log::LevelFilter::Debug
        } else {
            log::LevelFilter::Info
        })
        .init();

    // Parse ports
    let ports: Vec<u16> = args
        .ports
        .split(',')
        .filter_map(|s| s.trim().parse().ok())
        .collect();

    info!("Albion Online Packet Dumper");
    info!("Monitoring ports: {:?}", ports);

    // Get network device
    let device = if let Some(ref iface) = args.interface {
        Device::list()?
            .into_iter()
            .find(|d| d.name == *iface)
            .context(format!("Interface {} not found", iface))?
    } else {
        Device::lookup()?.context("No default device found")?
    };

    info!("Capturing on interface: {}", device.name);

    // Create capture
    let mut cap = Capture::from_device(device)?
        .promisc(true)
        .snaplen(65535)
        .timeout(1000)
        .open()?;

    // Apply filter if provided, otherwise filter by ports
    let filter = if let Some(f) = args.filter {
        f
    } else {
        format!(
            "{}",
            ports
                .iter()
                .map(|p| format!("port {}", p))
                .collect::<Vec<_>>()
                .join(" or ")
        )
    };

    cap.filter(&filter, true)?;
    info!("Applied filter: {}", filter);

    let dumper = PacketDumper::new(args.output, ports, args.ui)?;

    info!("Starting packet capture... Press Ctrl+C to stop");

    // Start UI thread if enabled
    let ui_handle = if args.ui {
        if let Some(ref tracker) = dumper.ui_tracker {
            let tracker_clone = tracker.clone();
            Some(std::thread::spawn(move || {
                if let Err(e) = ui::run_ui(tracker_clone) {
                    eprintln!("UI error: {}", e);
                }
            }))
        } else {
            None
        }
    } else {
        None
    };

    // Handle Ctrl+C
    let dumper_clone = Arc::new(dumper);
    let dumper_handler = dumper_clone.clone();
    ctrlc::set_handler(move || {
        println!("\n\nStopping capture...");
        if let Err(e) = dumper_handler.save_players() {
            warn!("Error saving players: {}", e);
        }
        if dumper_handler.ui_tracker.is_none() {
            if let Err(e) = dumper_handler.print_summary() {
                warn!("Error printing summary: {}", e);
            }
        }
        std::process::exit(0);
    })?;

    // Capture loop
    loop {
        match cap.next_packet() {
            Ok(packet) => {
                if let Err(e) = dumper_clone.handle_packet(packet.data) {
                    debug!("Error handling packet: {}", e);
                }
            }
            Err(pcap::Error::TimeoutExpired) => continue,
            Err(e) => {
                warn!("Capture error: {}", e);
                break;
            }
        }
    }

    if let Some(handle) = ui_handle {
        let _ = handle.join();
    }

    dumper_clone.save_players()?;
    if dumper_clone.ui_tracker.is_none() {
        dumper_clone.print_summary()?;
    }

    Ok(())
}
