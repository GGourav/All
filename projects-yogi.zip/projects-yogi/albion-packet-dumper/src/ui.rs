use anyhow::Result;
use chrono::{DateTime, Utc};
use crossterm::{
    event::{self, DisableMouseCapture, EnableMouseCapture, Event, KeyCode},
    execute,
    terminal::{disable_raw_mode, enable_raw_mode, EnterAlternateScreen, LeaveAlternateScreen},
};
use ratatui::{
    backend::CrosstermBackend,
    layout::{Alignment, Constraint, Direction, Layout},
    style::{Color, Modifier, Style},
    text::{Line, Span},
    widgets::{Block, Borders, Paragraph, Row, Table},
    Terminal,
};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::io;
use std::sync::{Arc, Mutex};
use std::time::Duration;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Position {
    pub x: f32,
    pub y: f32,
    pub z: f32,
}

impl Position {
    pub fn distance_to(&self, other: &Position) -> f32 {
        let dx = self.x - other.x;
        let dy = self.y - other.y;
        let dz = self.z - other.z;
        (dx * dx + dy * dy + dz * dz).sqrt()
    }

    pub fn direction_to(&self, other: &Position) -> String {
        let dx = other.x - self.x;
        let dz = other.z - self.z;

        let angle = dz.atan2(dx).to_degrees();
        let angle = (angle + 360.0) % 360.0;

        match angle {
            a if a >= 337.5 || a < 22.5 => "E",
            a if a >= 22.5 && a < 67.5 => "NE",
            a if a >= 67.5 && a < 112.5 => "N",
            a if a >= 112.5 && a < 157.5 => "NW",
            a if a >= 157.5 && a < 202.5 => "W",
            a if a >= 202.5 && a < 247.5 => "SW",
            a if a >= 247.5 && a < 292.5 => "S",
            a if a >= 292.5 && a < 337.5 => "SE",
            _ => "?",
        }
        .to_string()
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TrackedPlayer {
    pub name: String,
    pub guild: Option<String>,
    pub alliance: Option<String>,
    pub position: Position,
    pub last_seen: DateTime<Utc>,
    pub first_seen: DateTime<Utc>,
}

pub struct PlayerTracker {
    players: Arc<Mutex<HashMap<String, TrackedPlayer>>>,
    my_position: Arc<Mutex<Option<Position>>>,
}

impl PlayerTracker {
    pub fn new() -> Self {
        Self {
            players: Arc::new(Mutex::new(HashMap::new())),
            my_position: Arc::new(Mutex::new(None)),
        }
    }

    pub fn update_player(&self, name: String, guild: Option<String>, position: Position) {
        let mut players = self.players.lock().unwrap();
        let now = Utc::now();

        players
            .entry(name.clone())
            .and_modify(|p| {
                p.position = position.clone();
                p.last_seen = now;
                if guild.is_some() {
                    p.guild = guild.clone();
                }
            })
            .or_insert_with(|| TrackedPlayer {
                name,
                guild,
                alliance: None,
                position,
                last_seen: now,
                first_seen: now,
            });
    }

    pub fn set_my_position(&self, pos: Position) {
        let mut my_pos = self.my_position.lock().unwrap();
        *my_pos = Some(pos);
    }

    pub fn get_players_sorted_by_distance(&self) -> Vec<(TrackedPlayer, Option<f32>, String)> {
        let players = self.players.lock().unwrap();
        let my_pos = self.my_position.lock().unwrap();

        let mut player_list: Vec<_> = players
            .values()
            .map(|p| {
                let (distance, direction) = if let Some(ref my_pos) = *my_pos {
                    (
                        Some(my_pos.distance_to(&p.position)),
                        my_pos.direction_to(&p.position),
                    )
                } else {
                    (None, "?".to_string())
                };
                (p.clone(), distance, direction)
            })
            .collect();

        // Sort by distance (closest first)
        player_list.sort_by(|a, b| match (a.1, b.1) {
            (Some(d1), Some(d2)) => d1.partial_cmp(&d2).unwrap(),
            (Some(_), None) => std::cmp::Ordering::Less,
            (None, Some(_)) => std::cmp::Ordering::Greater,
            (None, None) => a.0.name.cmp(&b.0.name),
        });

        player_list
    }

    pub fn get_stats(&self) -> (usize, Option<Position>) {
        let players = self.players.lock().unwrap();
        let my_pos = self.my_position.lock().unwrap();
        (players.len(), my_pos.clone())
    }

    pub fn cleanup_old_players(&self, max_age_secs: i64) {
        let mut players = self.players.lock().unwrap();
        let now = Utc::now();
        players.retain(|_, p| (now - p.last_seen).num_seconds() < max_age_secs);
    }
}

pub fn run_ui(tracker: Arc<PlayerTracker>) -> Result<()> {
    // Setup terminal
    enable_raw_mode()?;
    let mut stdout = io::stdout();
    execute!(stdout, EnterAlternateScreen, EnableMouseCapture)?;
    let backend = CrosstermBackend::new(stdout);
    let mut terminal = Terminal::new(backend)?;

    // Run app
    let res = run_app(&mut terminal, tracker);

    // Restore terminal
    disable_raw_mode()?;
    execute!(
        terminal.backend_mut(),
        LeaveAlternateScreen,
        DisableMouseCapture
    )?;
    terminal.show_cursor()?;

    if let Err(err) = res {
        println!("Error: {:?}", err);
    }

    Ok(())
}

fn run_app(
    terminal: &mut Terminal<CrosstermBackend<io::Stdout>>,
    tracker: Arc<PlayerTracker>,
) -> Result<()> {
    loop {
        terminal.draw(|f| {
            let size = f.area();

            // Create layout
            let chunks = Layout::default()
                .direction(Direction::Vertical)
                .constraints([
                    Constraint::Length(3), // Header
                    Constraint::Min(10),   // Player table
                    Constraint::Length(3), // Footer
                ])
                .split(size);

            // Header
            let (player_count, my_pos) = tracker.get_stats();
            let my_pos_str = if let Some(pos) = my_pos {
                format!("Your Position: ({:.1}, {:.1}, {:.1})", pos.x, pos.y, pos.z)
            } else {
                "Your Position: Unknown (waiting for data...)".to_string()
            };

            let header = Paragraph::new(vec![
                Line::from(vec![
                    Span::styled(
                        "Albion Online ",
                        Style::default()
                            .fg(Color::Yellow)
                            .add_modifier(Modifier::BOLD),
                    ),
                    Span::styled(
                        "Player Tracker",
                        Style::default()
                            .fg(Color::Green)
                            .add_modifier(Modifier::BOLD),
                    ),
                ]),
                Line::from(vec![
                    Span::styled(
                        format!("Tracking {} players | ", player_count),
                        Style::default().fg(Color::Cyan),
                    ),
                    Span::styled(my_pos_str, Style::default().fg(Color::Magenta)),
                ]),
            ])
            .block(Block::default().borders(Borders::ALL).title("Status"))
            .alignment(Alignment::Left);
            f.render_widget(header, chunks[0]);

            // Player table
            let players = tracker.get_players_sorted_by_distance();

            let rows: Vec<Row> = players
                .iter()
                .enumerate()
                .map(|(idx, (player, distance, direction))| {
                    let dist_str = if let Some(d) = distance {
                        format!("{:.1}m", d)
                    } else {
                        "?".to_string()
                    };

                    let guild_str = player.guild.as_deref().unwrap_or("-");
                    let pos_str = format!(
                        "({:.0}, {:.0}, {:.0})",
                        player.position.x, player.position.y, player.position.z
                    );

                    // Color by distance
                    let style = if let Some(d) = distance {
                        if *d < 50.0 {
                            Style::default().fg(Color::Red).add_modifier(Modifier::BOLD)
                        // Very close!
                        } else if *d < 100.0 {
                            Style::default().fg(Color::Yellow) // Close
                        } else if *d < 200.0 {
                            Style::default().fg(Color::Green) // Medium
                        } else {
                            Style::default().fg(Color::Blue) // Far
                        }
                    } else {
                        Style::default().fg(Color::Gray)
                    };

                    Row::new(vec![
                        format!("{}", idx + 1),
                        player.name.clone(),
                        guild_str.to_string(),
                        dist_str,
                        direction.clone(),
                        pos_str,
                    ])
                    .style(style)
                })
                .collect();

            let table = Table::new(
                rows,
                [
                    Constraint::Length(4),  // #
                    Constraint::Length(20), // Name
                    Constraint::Length(10), // Guild
                    Constraint::Length(10), // Distance
                    Constraint::Length(6),  // Direction
                    Constraint::Min(20),    // Position
                ],
            )
            .header(
                Row::new(vec![
                    "#",
                    "Player Name",
                    "Guild",
                    "Distance",
                    "Dir",
                    "Position",
                ])
                .style(
                    Style::default()
                        .fg(Color::Yellow)
                        .add_modifier(Modifier::BOLD),
                )
                .bottom_margin(1),
            )
            .block(
                Block::default()
                    .borders(Borders::ALL)
                    .title("Nearby Players"),
            )
            .column_spacing(1);

            f.render_widget(table, chunks[1]);

            // Footer
            let footer = Paragraph::new(vec![Line::from(vec![
                Span::styled("Controls: ", Style::default().fg(Color::Yellow)),
                Span::raw("Press "),
                Span::styled(
                    "'q'",
                    Style::default().fg(Color::Red).add_modifier(Modifier::BOLD),
                ),
                Span::raw(" to quit | "),
                Span::styled("Color Legend: ", Style::default().fg(Color::Yellow)),
                Span::styled("Red", Style::default().fg(Color::Red)),
                Span::raw(" <50m | "),
                Span::styled("Yellow", Style::default().fg(Color::Yellow)),
                Span::raw(" <100m | "),
                Span::styled("Green", Style::default().fg(Color::Green)),
                Span::raw(" <200m | "),
                Span::styled("Blue", Style::default().fg(Color::Blue)),
                Span::raw(" >200m"),
            ])])
            .block(Block::default().borders(Borders::ALL))
            .alignment(Alignment::Center);
            f.render_widget(footer, chunks[2]);
        })?;

        // Handle input
        if event::poll(Duration::from_millis(100))? {
            if let Event::Key(key) = event::read()? {
                if key.code == KeyCode::Char('q') {
                    return Ok(());
                }
            }
        }

        // Cleanup old players (remove after 30 seconds of inactivity)
        tracker.cleanup_old_players(30);
    }
}
