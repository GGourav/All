#!/bin/bash

# Example: Quick Start Guide for Albion Packet Dumper

echo "Albion Online Packet Dumper - Quick Start Examples"
echo "===================================================="
echo

# Check if running as root
if [ "$EUID" -ne 0 ]; then 
    echo "⚠️  This tool requires root privileges to capture packets"
    echo "Please run with sudo or as root user"
    echo
    SUDO="sudo"
else
    SUDO=""
fi

# Build first if not already built
if [ ! -f "target/release/albion-packet-dumper" ]; then
    echo "Building project..."
    cargo build --release
    echo
fi

echo "Choose an example:"
echo
echo "1) Basic capture (default settings)"
echo "2) Capture with verbose logging"
echo "3) Capture to custom directory"
echo "4) List available network interfaces"
echo "5) Capture on specific interface"
echo "6) Exit"
echo

read -p "Enter choice [1-6]: " choice

case $choice in
    1)
        echo "Starting basic capture on default interface..."
        echo "Press Ctrl+C to stop and view results"
        echo
        $SUDO ./target/release/albion-packet-dumper
        ;;
    2)
        echo "Starting verbose capture..."
        echo "Press Ctrl+C to stop and view results"
        echo
        $SUDO ./target/release/albion-packet-dumper -v
        ;;
    3)
        read -p "Enter output directory name: " outdir
        echo "Saving logs to: $outdir"
        echo "Press Ctrl+C to stop and view results"
        echo
        $SUDO ./target/release/albion-packet-dumper -o "$outdir"
        ;;
    4)
        echo "Available network interfaces:"
        echo
        if command -v ip &> /dev/null; then
            ip link show | grep -E "^[0-9]+" | awk '{print $2}' | sed 's/://'
        else
            ifconfig | grep -E "^[a-z]" | awk '{print $1}' | sed 's/://'
        fi
        echo
        ;;
    5)
        echo "Available interfaces:"
        if command -v ip &> /dev/null; then
            ip link show | grep -E "^[0-9]+" | awk '{print $2}' | sed 's/://'
        else
            ifconfig | grep -E "^[a-z]" | awk '{print $1}' | sed 's/://'
        fi
        echo
        read -p "Enter interface name (e.g., eth0, wlan0): " iface
        echo "Capturing on interface: $iface"
        echo "Press Ctrl+C to stop and view results"
        echo
        $SUDO ./target/release/albion-packet-dumper -i "$iface"
        ;;
    6)
        echo "Exiting..."
        exit 0
        ;;
    *)
        echo "Invalid choice"
        exit 1
        ;;
esac
