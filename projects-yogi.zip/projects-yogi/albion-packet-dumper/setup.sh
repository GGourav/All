#!/bin/bash

# Albion Online Packet Dumper - Quick Start Script

set -e

echo "=================================="
echo "Albion Online Packet Dumper Setup"
echo "=================================="
echo

# Check if Rust is installed
if ! command -v cargo &> /dev/null; then
    echo "Error: Rust is not installed"
    echo "Please install Rust from https://rustup.rs"
    exit 1
fi

echo "[1/4] Checking dependencies..."

# Check for libpcap
if [ -f /etc/debian_version ]; then
    # Debian/Ubuntu
    if ! dpkg -l | grep -q libpcap-dev; then
        echo "Installing libpcap-dev..."
        sudo apt-get update
        sudo apt-get install -y libpcap-dev
    fi
elif [ -f /etc/redhat-release ]; then
    # RedHat/CentOS/Fedora
    if ! rpm -q libpcap-devel &> /dev/null; then
        echo "Installing libpcap-devel..."
        sudo yum install -y libpcap-devel
    fi
elif [ "$(uname)" == "Darwin" ]; then
    # macOS
    if ! brew list libpcap &> /dev/null; then
        echo "Installing libpcap..."
        brew install libpcap
    fi
fi

echo "[2/4] Building project..."
cargo build --release

echo "[3/4] Setting up permissions..."
echo "This tool requires network capture permissions."
echo "Choose an option:"
echo "  1) Set capabilities (recommended, Linux only)"
echo "  2) Run with sudo each time"
read -p "Enter choice [1/2]: " choice

if [ "$choice" == "1" ]; then
    if [ "$(uname)" == "Linux" ]; then
        sudo setcap cap_net_raw,cap_net_admin=eip target/release/albion-packet-dumper
        echo "Capabilities set! You can now run without sudo."
    else
        echo "Capabilities are only available on Linux. You'll need to use sudo."
    fi
fi

echo
echo "[4/4] Setup complete!"
echo
echo "=================================="
echo "Usage Examples:"
echo "=================================="
echo
echo "# Start capturing (may need sudo)"
echo "./target/release/albion-packet-dumper"
echo
echo "# Specify network interface"
echo "./target/release/albion-packet-dumper -i eth0"
echo
echo "# Verbose mode"
echo "./target/release/albion-packet-dumper -v"
echo
echo "# Custom output directory"
echo "./target/release/albion-packet-dumper -o my_capture_logs"
echo
echo "=================================="
echo "Logs will be saved in the 'albion_logs' directory"
echo "Press Ctrl+C to stop capturing and save results"
echo "=================================="
