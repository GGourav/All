# Albion Online Packet Dumper

A high-performance network packet capture tool written in Rust for monitoring and analyzing Albion Online network traffic with automatic player detection.

## Features

- **Real-time packet capture** on Albion Online ports (default: 5056, 5057)
- **Player detection** - Automatically detects and tracks players
- **Player information extraction**:
  - Player ID and Name
  - Guild and Alliance information
  - Player positions (X, Y, Z coordinates)
  - IP addresses
  - First seen / Last seen timestamps
- **Dual logging**: Human-readable `.log` files and structured `.json` files
- **Packet parsing** with heuristic analysis for unknown packet types
- **Session summaries** with player statistics
- **BPF filtering** support for efficient packet capture

## Installation

### Prerequisites

- Rust (install from https://rustup.rs)
- libpcap (Linux/macOS) or WinPcap/Npcap (Windows)

#### Linux
```bash
sudo apt-get install libpcap-dev
```

#### macOS
```bash
brew install libpcap
```

#### Windows
Install [Npcap](https://npcap.com/#download) or WinPcap

### Build

```bash
cd albion-packet-dumper
cargo build --release
```

The compiled binary will be in `target/release/albion-packet-dumper`

## Usage

**Note:** Packet capture requires root/administrator privileges.

### Basic Usage

```bash
# Capture on default interface
sudo ./target/release/albion-packet-dumper

# Specify network interface
sudo ./target/release/albion-packet-dumper -i eth0

# Custom output directory
sudo ./target/release/albion-packet-dumper -o my_logs

# Verbose logging
sudo ./target/release/albion-packet-dumper -v
```

### Advanced Options

```bash
# Monitor custom ports
sudo ./target/release/albion-packet-dumper -p 5056,5057,5058

# Apply custom BPF filter
sudo ./target/release/albion-packet-dumper -f "tcp port 5056 and host 1.2.3.4"
```

### Command Line Options

```
Options:
  -i, --interface <INTERFACE>  Network interface to capture from
  -o, --output <OUTPUT>        Output directory for logs [default: albion_logs]
  -f, --filter <FILTER>        Capture filter (BPF syntax)
  -p, --ports <PORTS>          Albion Online server ports [default: 5056,5057]
  -v, --verbose                Enable verbose logging
  -h, --help                   Print help
  -V, --version                Print version
```

## Output Files

The tool generates three types of output files:

1. **`albion_packets_TIMESTAMP.log`** - Human-readable packet logs with hex dumps
2. **`albion_packets_TIMESTAMP.json`** - Structured JSON logs for programmatic analysis
3. **`players_TIMESTAMP.json`** - Player database with all detected players

### Example Player Data

```json
{
  "player123": {
    "id": "player123",
    "name": "PlayerName",
    "guild": "MyGuild",
    "alliance": "MyAlliance",
    "position": {
      "x": 1234.5,
      "y": 567.8,
      "z": 0.0
    },
    "first_seen": "2026-03-29T12:00:00Z",
    "last_seen": "2026-03-29T12:05:00Z",
    "ip_address": "192.168.1.100"
  }
}
```

## How It Works

1. **Packet Capture**: Uses libpcap to capture network packets on specified ports
2. **Protocol Analysis**: Parses TCP/UDP packets and extracts payloads
3. **Packet Parsing**: 
   - Attempts to parse known Albion packet structures
   - Falls back to heuristic analysis for unknown packets
   - Extracts player names, IDs, guilds, and positions
4. **Player Tracking**: Maintains a database of detected players with their information
5. **Logging**: Records all packets and player data to disk

## Packet Types Detected

- **Movement** - Player position updates
- **PlayerInfo** - Player information packets
- **Chat** - Chat messages
- **Join/Leave** - Player join/leave events
- **GuildInfo** - Guild information
- **AllianceInfo** - Alliance information
- **UpdatePlayer** - Player state updates

## Security & Privacy

- This tool is for **educational and network analysis purposes only**
- Only captures packets on your local network
- Requires appropriate permissions (root/admin)
- Use responsibly and in compliance with Albion Online's Terms of Service

## Troubleshooting

### Permission Denied
```bash
# Linux/macOS: Run with sudo
sudo ./target/release/albion-packet-dumper

# Or grant capabilities (Linux only)
sudo setcap cap_net_raw,cap_net_admin=eip ./target/release/albion-packet-dumper
```

### No Packets Captured
- Verify you're connected to Albion Online
- Check if the correct ports are being monitored
- Ensure you're capturing on the correct network interface
- Try running with `-v` for verbose logging

### Interface Not Found
```bash
# List available interfaces
ip link show  # Linux
ifconfig      # macOS

# Specify the correct interface
sudo ./target/release/albion-packet-dumper -i wlan0
```

## Development

### Project Structure

```
albion-packet-dumper/
├── src/
│   ├── main.rs      # Main application logic
│   └── parser.rs    # Packet parsing and player detection
├── Cargo.toml       # Dependencies and project metadata
└── README.md        # This file
```

### Testing

```bash
cargo test
```

### Contributing

Contributions are welcome! Areas for improvement:
- Reverse engineering more Albion packet structures
- Adding support for encrypted packets
- Improving player detection heuristics
- Adding real-time visualization

## License

MIT License - See LICENSE file for details

## Disclaimer

This tool is provided as-is for educational purposes. The authors are not responsible for any misuse or violations of Albion Online's Terms of Service. Always ensure you have permission to capture network traffic on your network.
