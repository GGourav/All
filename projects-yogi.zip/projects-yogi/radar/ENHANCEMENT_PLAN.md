# OpenRadar Rust Enhancement Plan - Robust Player Tracking

**Goal**: Implement comprehensive player tracking that handles:
1. ✅ Stationary players (initial spawn position)
2. ✅ Dead players (health tracking)
3. ✅ Own character identification
4. ✅ Relative positioning (distance/bearing to other players)
5. ✅ Zone transitions (clear stale data)
6. ✅ Player removal (leave events)
7. ✅ Equipment/faction data

---

## 📊 Event Types Analysis (from heatsync reference)

### Already Implemented ✅
- **Event 29 (NEW_CHARACTER)** - Player joins zone
- **Event 3 (PLAYER_MOVED)** - Position update

### Missing - High Priority ⭐⭐⭐
- **Event 1 (CHARACTER_LEFT)** - Player leaves zone → REMOVE from tracking
- **Event 6 (HEALTH_UPDATE)** - Single damage/heal event → Track health + detect deaths
- **Event 7 (HEALTH_UPDATES)** - Batch health updates (multiple targets)
- **Event 273 (IN_COMBAT_STATE_UPDATE)** - Combat state change
- **Event 483 (POSITION_UPDATE)** - Alternative position format (array with [x,y])

### Critical - Self-Identification ⭐⭐⭐⭐⭐
- **OP_JOIN (opcode 2)** - Sent when entering a zone → Contains LOCAL PLAYER DATA
- **OP_CHANGE_CLUSTER (opcode 4)** - Zone change → Contains LOCAL PLAYER + sends ZoneChanged signal

---

## 🔍 Extended Event 29 (NewCharacter) Data

From albion-network/handlers.rs (lines 149-177):

```
param[0]  = character_id (player ID)
param[1]  = username (player name)
param[8]  = guild (guild name or null)
param[22] = max_health (initial health value)
param[40] = equipment_ids (array of item IDs: slots 0-8)
           [MainHand, OffHand, Head, Chest, Shoes, Cape, Mount, Bag, Food]
param[43] = spells (spell IDs - not critical but nice to have)
param[51] = alliance (alliance name or null)
param[53] = faction (0=passive, 1-6=faction city, 255=hostile!)
           ← THIS IS IMPORTANT FOR THREAT DETECTION!
```

---

## 🎯 Implementation Tasks

### Phase 1: Data Structure Enhancement

#### 1. Expand Entity struct (src/entities.rs)
```rust
pub struct Entity {
    // Existing
    pub id: u32,
    pub x: f32, pub y: f32, pub z: f32,
    pub name: String,
    pub guild: String,
    pub alliance: String,
    pub last_seen: Instant,

    // NEW: Player Details
    pub faction: i32,              // 0=passive, 1-6=faction, 255=hostile
    pub current_health: f32,       // Current HP (0 = dead)
    pub max_health: f32,           // Max HP
    pub equipment_ids: Vec<i32>,   // Item IDs for each equipment slot

    // NEW: Tracking State
    pub detected_at: Instant,      // When first seen
    pub is_dead: bool,             // current_health == 0
    pub in_combat: bool,           // Combat state from event 273
}
```

#### 2. Add LocalPlayer tracking
```rust
pub struct LocalPlayer {
    pub id: u32,
    pub name: String,
    pub zone_id: Option<u32>,      // Current zone
    pub x: f32, pub y: f32,        // Self position
}

pub struct EntityTracker {
    // Existing
    entities: Arc<Mutex<HashMap<u32, Entity>>>,
    stale_timeout: Duration,

    // NEW
    local_player: Arc<Mutex<Option<LocalPlayer>>>,
}
```

---

### Phase 2: Event Handlers

#### 2a. OP_JOIN / OP_CHANGE_CLUSTER Handler (Operations)

**File**: `src/main.rs`, lines ~200

```rust
// In packet handler, before event processing:
for cmd in &packet.commands {
    match cmd.opcode {
        2 => {  // OP_JOIN
            if let Some(payload) = &cmd.payload {
                if let Ok(response) = photon::deserialize_response(&payload.data) {
                    if let Some(local_player) = extract_local_player(&response.parameters) {
                        tracker_clone.set_local_player(
                            local_player.character_id,
                            local_player.username,
                        );
                        log_clone.info("OOP", &format!(
                            "🎮 LOCAL PLAYER: {} (ID: {})",
                            local_player.username, local_player.character_id
                        ), None);
                    }
                }
            }
        }
        4 => {  // OP_CHANGE_CLUSTER (Zone Change)
            tracker_clone.clear_zone();  // ← Clear all players
            log_clone.info("OOP", "🗺️ ZONE CHANGE - Cleared player list", None);

            if let Some(payload) = &cmd.payload {
                if let Ok(response) = photon::deserialize_response(&payload.data) {
                    if let Some(local_player) = extract_local_player(&response.parameters) {
                        tracker_clone.set_local_player(
                            local_player.character_id,
                            local_player.username,
                        );
                        log_clone.info("OOP", &format!(
                            "🎮 NEW ZONE - LOCAL PLAYER: {} (ID: {})",
                            local_player.username, local_player.character_id
                        ), None);
                    }
                }
            }
        }
        _ => {}
    }
}
```

#### 2b. Event 1 (CHARACTER_LEFT) Handler ⭐

**File**: `src/main.rs`, Event handler

```rust
1 => {  // CHARACTER_LEFT
    if let Some(id_val) = event.parameters.get(&0) {
        let entity_id = extract_u32(id_val);
        if entity_id > 0 {
            tracker_clone.remove_entity(entity_id);
            log_clone.info("PKT", &format!(
                "👋 CHARACTER_LEFT: ID={}",
                entity_id
            ), None);
        }
    }
}
```

#### 2c. Event 6 (HEALTH_UPDATE) Handler ⭐

**File**: `src/main.rs`, Event handler

```rust
6 => {  // HEALTH_UPDATE (single)
    // params[0] = target_id
    // params[2] = current_health OR value changed
    // params[3] = max_health
    if let Some(target_id_val) = event.parameters.get(&0) {
        let target_id = extract_u32(target_id_val);
        if target_id > 0 {
            let current_health = event.parameters.get(&2)
                .and_then(|v| extract_f32_safe(v));
            let max_health = event.parameters.get(&3)
                .and_then(|v| extract_f32_safe(v));

            tracker_clone.update_health(target_id, current_health, max_health);

            if let Some(ch) = current_health {
                if ch <= 0.0 {
                    log_clone.debug("PKT", &format!(
                        "💀 PLAYER DEAD: ID={}",
                        target_id
                    ), None);
                }
            }
        }
    }
}
```

#### 2d. Event 7 (HEALTH_UPDATES) Handler ⭐

```rust
7 => {  // HEALTH_UPDATES (batch)
    // params[0] = target_id (single target, multiple inflictors)
    // params[2] = [health values array]
    // params[3] = [max health array]

    if let Some(target_id_val) = event.parameters.get(&0) {
        let target_id = extract_u32(target_id_val);
        if target_id > 0 {
            // Try to get max health if available
            let max_health = event.parameters.get(&3)
                .and_then(|v| extract_f32_safe(v));

            // Get the last/current health value from the array
            if let Some(health_array) = event.parameters.get(&2) {
                if let Some(current_health) = extract_array_last_f32(health_array) {
                    tracker_clone.update_health(target_id, Some(current_health), max_health);

                    if current_health <= 0.0 {
                        log_clone.debug("PKT", &format!(
                            "💀 PLAYER DEAD (batch): ID={}",
                            target_id
                        ), None);
                    }
                }
            }
        }
    }
}
```

#### 2e. Event 273 (IN_COMBAT_STATE_UPDATE) Handler

```rust
273 => {  // IN_COMBAT_STATE_UPDATE
    if let Some(char_id_val) = event.parameters.get(&0) {
        let char_id = extract_u32(char_id_val);
        if char_id > 0 {
            let in_combat = event.parameters.contains_key(&1);  // presence = in_combat
            tracker_clone.update_combat_state(char_id, in_combat);
        }
    }
}
```

#### 2f. Event 483 (POSITION_UPDATE) Handler

```rust
483 => {  // POSITION_UPDATE
    // params[0] = entity_id
    // params[1] = array with [x, y]
    if let Some(entity_id_val) = event.parameters.get(&0) {
        let entity_id = extract_u32(entity_id_val);
        if entity_id == 0 { continue; }

        if let Some(pos_array) = event.parameters.get(&1) {
            if let Some((x, y)) = extract_position(pos_array) {
                tracker_clone.update_position(entity_id, x, y, 0.0);  // No Z available
                log_clone.debug("PKT", &format!(
                    "Move(483): ID={} X={:.2} Y={:.2}",
                    entity_id, x, y
                ), None);
            }
        }
    }
}
```

---

### Phase 3: Enhanced Event 29 Handler

**File**: `src/main.rs`, Event 29 handler (replace current ~lines 240-286)

```rust
29 => {  // NEW_CHARACTER (full replacement)
    if entity_id == 0 { continue; }

    // Extract basic info (required)
    let name = if let Some(photon::PhotonValue::String(n)) = event.parameters.get(&1) {
        n.clone()
    } else { continue; };

    if name.is_empty() { continue; }

    // Guild and Alliance
    let guild = event.parameters.get(&8)
        .and_then(|v| if let photon::PhotonValue::String(s) = v { Some(s.clone()) } else { None })
        .unwrap_or_default();

    let alliance = event.parameters.get(&51)
        .and_then(|v| if let photon::PhotonValue::String(s) = v { Some(s.clone()) } else { None })
        .filter(|s| !s.is_empty());

    // NEW: Faction (important for threat detection!)
    let faction: i32 = event.parameters.get(&53)
        .and_then(|v| extract_i32(v))
        .unwrap_or(0);

    // NEW: Max Health (initial)
    let max_health = event.parameters.get(&22)
        .and_then(|v| extract_f32_safe(v))
        .unwrap_or(0.0);

    // NEW: Equipment IDs
    let mut equipment_ids = Vec::new();
    if let Some(photon::PhotonValue::IntArray(arr)) = event.parameters.get(&40) {
        equipment_ids = arr.iter().map(|x| *x as i32).collect();
    }

    // Format display
    let display = match (guild.is_empty(), alliance.is_empty()) {
        (false, false) => format!("[{}] <{}> {}", guild, alliance, name),
        (false, true) => format!("[{}] {}", guild, name),
        (true, false) => format!("<{}> {}", alliance.unwrap_or_default(), name),
        (true, true) => name.clone(),
    };

    // Add threat indicator based on faction
    let threat_indicator = match faction {
        255 => "⚠️ HOSTILE",
        1..=6 => "⚠️ FACTION",
        _ => "✨",
    };

    // Update tracker with full data
    tracker_clone.update_entity(
        entity_id,
        0.0, 0.0, 0.0,  // Initial position unknown (wait for Event 3)
        name.clone(),
        guild.clone(),
        alliance,
        faction,
        max_health,
        equipment_ids,
    );

    print_success("PLY", &format!("{} NEW PLAYER: {} (ID: {})", threat_indicator, display, entity_id));
    log_clone.info("PKT", &format!(
        "NewCharacter(29): ID={} Name='{}' Guild='{}' Alliance='{}' Faction={}",
        entity_id, name, guild, guild.unwrap_or_default(), faction
    ), None);
}
```

---

### Phase 4: EntityTracker Methods

**File**: `src/entities.rs`, add these methods:

```rust
// Set/get local player
pub fn set_local_player(&self, id: u32, name: String) {
    self.local_player.lock().unwrap().replace(LocalPlayer {
        id,
        name,
        zone_id: None,
        x: 0.0, y: 0.0,
    });
}

pub fn get_local_player(&self) -> Option<LocalPlayer> {
    self.local_player.lock().unwrap().clone()
}

// Update entity with extended data
pub fn update_entity_full(
    &self,
    id: u32,
    x: f32, y: f32, z: f32,
    name: String,
    guild: String,
    alliance: Option<String>,
    faction: i32,
    max_health: f32,
    equipment_ids: Vec<i32>,
) {
    let mut entities = self.entities.lock().unwrap();
    entities.insert(id, Entity {
        id,
        x, y, z,
        name,
        guild,
        alliance,
        faction,
        current_health: max_health,  // Assume full health on spawn
        max_health,
        equipment_ids,
        last_seen: Instant::now(),
        detected_at: Instant::now(),
        is_dead: false,
        in_combat: false,
    });
}

// Update health
pub fn update_health(&self, id: u32, current_health: Option<f32>, max_health: Option<f32>) {
    let mut entities = self.entities.lock().unwrap();
    if let Some(entity) = entities.get_mut(&id) {
        if let Some(ch) = current_health {
            entity.current_health = ch;
            entity.is_dead = ch <= 0.0;
        }
        if let Some(mh) = max_health {
            entity.max_health = mh;
        }
        entity.last_seen = Instant::now();
    }
}

// Update combat state
pub fn update_combat_state(&self, id: u32, in_combat: bool) {
    let mut entities = self.entities.lock().unwrap();
    if let Some(entity) = entities.get_mut(&id) {
        entity.in_combat = in_combat;
        entity.last_seen = Instant::now();
    }
}

// Remove entity (Character Left event)
pub fn remove_entity(&self, id: u32) {
    let mut entities = self.entities.lock().unwrap();
    entities.remove(&id);
}

// Clear all entities (zone change)
pub fn clear_zone(&self) {
    let mut entities = self.entities.lock().unwrap();
    entities.clear();
}

// Get distance to player (relative positioning)
pub fn get_distance_to_entity(&self, entity_id: u32) -> Option<f32> {
    let local = self.local_player.lock().unwrap();
    let local_player = local.as_ref()?;

    let entities = self.entities.lock().unwrap();
    let entity = entities.get(&entity_id)?;

    let dx = entity.x - local_player.x;
    let dy = entity.y - local_player.y;
    Some((dx * dx + dy * dy).sqrt())
}

// Get bearing to entity (direction)
pub fn get_bearing_to_entity(&self, entity_id: u32) -> Option<f32> {
    let local = self.local_player.lock().unwrap();
    let local_player = local.as_ref()?;

    let entities = self.entities.lock().unwrap();
    let entity = entities.get(&entity_id)?;

    let dx = entity.x - local_player.x;
    let dy = entity.y - local_player.y;
    Some(dy.atan2(dx))  // Bearing in radians
}
```

---

### Phase 5: Utility Functions

Add to `src/main.rs`:

```rust
fn extract_u32(val: &photon::PhotonValue) -> u32 {
    match val {
        photon::PhotonValue::Int(i) => *i as u32,
        photon::PhotonValue::Short(s) => *s as u32,
        photon::PhotonValue::Byte(b) => *b as u32,
        photon::PhotonValue::Long(l) => *l as u32,
        _ => 0,
    }
}

fn extract_i32(val: &photon::PhotonValue) -> Option<i32> {
    match val {
        photon::PhotonValue::Int(i) => Some(*i),
        photon::PhotonValue::Short(s) => Some(*s as i32),
        photon::PhotonValue::Byte(b) => Some(*b as i32),
        photon::PhotonValue::Long(l) => Some(*l as i32),
        _ => None,
    }
}

fn extract_f32_safe(val: &photon::PhotonValue) -> Option<f32> {
    match val {
        photon::PhotonValue::Float(f) => Some(*f),
        photon::PhotonValue::Double(d) => Some(*d as f32),
        photon::PhotonValue::Int(i) => Some(*i as f32),
        photon::PhotonValue::Short(s) => Some(*s as f32),
        photon::PhotonValue::Byte(b) => Some(*b as f32),
        photon::PhotonValue::Long(l) => Some(*l as f32),
        _ => None,
    }
}

fn extract_position(val: &photon::PhotonValue) -> Option<(f32, f32)> {
    // Expects array with [x, y]
    match val {
        photon::PhotonValue::Array(arr) if arr.len() >= 2 => {
            let x = extract_f32_safe(&arr[0])?;
            let y = extract_f32_safe(&arr[1])?;
            Some((x, y))
        }
        _ => None,
    }
}

fn extract_array_last_f32(val: &photon::PhotonValue) -> Option<f32> {
    // Get last element from array of floats
    match val {
        photon::PhotonValue::Array(arr) if !arr.is_empty() => {
            extract_f32_safe(arr.last().unwrap())
        }
        _ => None,
    }
}

fn extract_local_player(params: &HashMap<u8, photon::PhotonValue>) -> Option<LocalPlayerData> {
    // Try multiple keys for username (matching Python: [1, 2, 5])
    let username = [1u8, 2, 5]
        .iter()
        .find_map(|k| {
            params.get(k).and_then(|v| {
                if let photon::PhotonValue::String(s) = v {
                    if s.len() >= 2 && s.len() <= 30 { Some(s.clone()) } else { None }
                } else { None }
            })
        })?;

    // Try multiple keys for char_id (matching Python: [0, 3])
    let character_id = [0u8, 3]
        .iter()
        .find_map(|k| params.get(k).and_then(|v| extract_i32(v)))?;

    Some(LocalPlayerData {
        character_id,
        username,
    })
}

#[derive(Debug, Clone)]
struct LocalPlayerData {
    character_id: i32,
    username: String,
}
```

---

### Phase 6: TUI Enhancement

**File**: `src/tui/mod.rs`, update player display:

```rust
// In entity display (around line 145-164):
let threat_icon = match e.faction {
    255 => "⚠️ ",  // Hostile
    1..=6 => "🚩 ", // Faction
    _ => "  ",      // Passive
};

let health_bar = if e.max_health > 0.0 {
    let hp_percent = (e.current_health / e.max_health * 100.0) as i32;
    format!("[{}%]", hp_percent)
} else {
    String::new()
};

let combat_indicator = if e.in_combat { "⚔️ " } else { "  " };

let distance = format!("{}m", (distance / 4.0).round() as i32);  // Albion uses ~4 units per meter

ListItem::new(format!(
    "{}{}{} {} {} {}\n    X: {:8.1} Y: {:8.1} Health: {}",
    threat_icon, combat_indicator, tags, e.name, health_bar, distance, e.x, e.y, e.current_health as i32
))
```

---

## 📝 Testing Checklist

- [ ] Event 1 (CHARACTER_LEFT) removes players
- [ ] Event 6 (HEALTH_UPDATE) updates health correctly
- [ ] Event 7 (HEALTH_UPDATES) batch updates work
- [ ] Event 273 (IN_COMBAT_STATE_UPDATE) toggles combat state
- [ ] Event 483 (POSITION_UPDATE) updates positions (alternative format)
- [ ] OP_JOIN identifies local player on zone enter
- [ ] OP_CHANGE_CLUSTER clears old players + identifies local player on zone change
- [ ] Stationary players visible (initial position from Event 29 + max health from param[22])
- [ ] Dead players marked (health = 0)
- [ ] Faction/enemy detection works (faction param extraction)
- [ ] Distance/bearing calculations accurate
- [ ] TUI displays threat indicators, health, combat state

---

## 🎯 Priority Order

1. **Critical**: Event 1, OP_JOIN, OP_CHANGE_CLUSTER, Event 6/7
2. **High**: Event 29 enhancement with faction/equipment, Event 483, Event 273
3. **Polish**: TUI display enhancements, health bar, threat icons
4. **Nice-to-have**: Distance calculations, bearing, equipment tracking

---

## Files to Modify

1. `src/entities.rs` - Add Entity fields + LocalPlayer struct + new methods
2. `src/main.rs` - Add operation handlers + event handlers + utility functions
3. `src/tui/mod.rs` - Display enhancements (optional, Phase 2)

