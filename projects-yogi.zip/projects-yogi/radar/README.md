# OpenRadar - Albion Online Network Radar 🎮

A high-performance **Rust port** of the Albion Online radar, featuring real-time player tracking with health monitoring, faction detection, party member identification, and combat state tracking.

[![Rust](https://img.shields.io/badge/Rust-1.70%2B-orange.svg)](https://www.rust-lang.org/)
[![License](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)
[![Status](https://img.shields.io/badge/status-Production%20Ready-brightgreen.svg)](#status)

---

## 🌟 Features

### Core Tracking
- ✅ **Real-time Player Detection** - Identify all players in zone via Event 29 (NewCharacter)
- ✅ **Position Updates** - Track player coordinates with Event 3 (Move) & Event 483 (PositionUpdate)
- ✅ **Self-Identification** - Auto-detect your own character via OP_JOIN/OP_CHANGE_CLUSTER
- ✅ **Party Member Tracking** - Identify squad members with Events 229-233
- ✅ **Health Monitoring** - Track current/max health via Events 6-7 (HealthUpdate)
- ✅ **Combat State** - Monitor active combat status via Event 273 (InCombatStateUpdate)
- ✅ **Death Detection** - Automatically mark players as dead (health = 0)

### Player Intelligence
- ✅ **Faction Detection** - Identify hostile (255), faction (1-6), or passive (0) players
- ✅ **Equipment Tracking** - Extract item IDs from all equipment slots
- ✅ **Guild/Alliance Info** - Capture guild and alliance affiliations
- ✅ **Distance Calculation** - Compute distance to any tracked player
- ✅ **Bearing Calculation** - Calculate directional bearing to entities

### Zone Management
- ✅ **Automatic Zone Clearing** - Clear stale entities on zone transitions
- ✅ **Player Removal** - Auto-remove players who leave via Event 1 (CharacterLeft)
- ✅ **Session Persistence** - Log all events to JSONL files for analysis

### User Interface
- ✅ **Terminal UI (TUI)** - Full-featured table view with threat indicators
- ✅ **Terminal Overlay** - Map visualization with player list
- ✅ **Window Overlay** - Floating window interface (egui-based)
- ✅ **Threat Indicators** - Visual symbols for hostile (⚠️), faction (🚩), and party (🤝) members
- ✅ **Combat Indicators** - Show active combat state (⚔️) and death state (💀)

---

## 🚀 Quick Start

### Prerequisites
- **Rust** 1.70+ ([install](https://rustup.rs/))
- **libpcap** (for network capture)
  - Ubuntu/Debian: `sudo apt-get install libpcap-dev`
  - macOS: `brew install libpcap`
  - Windows: [WinPcap](https://www.winpcap.org/) or [Npcap](https://npcap.org/)

### Installation
```bash
git clone https://github.com/yourusername/openradar.git
cd openradar/radar
cargo build --release
```

### Running
```bash
./target/release/openradar
# Select adapter (auto-detected)
# Choose UI mode: 1=TUI (default), 2=Overlay, 3=Window
# Watch the radar track players in real-time!
```

---

## 📊 Event Support

### Fully Implemented Events
| Event | Code | Purpose | Parameters |
|-------|------|---------|------------|
| **NewCharacter** | 29 | Player joins zone | ID, name, guild, alliance, faction, equipment |
| **Move** | 3 | Position update | ID, X, Y, Z, speed |
| **PositionUpdate** | 483 | Alternative position | ID, [X, Y] |
| **HealthUpdate** | 6 | Single damage/heal | Target ID, value, health |
| **HealthUpdates** | 7 | Batch health change | Target ID, [values], max health |
| **InCombatState** | 273 | Combat toggle | ID, state |
| **CharacterLeft** | 1 | Player exits zone | ID |
| **PartyJoined** | 229 | Enter party | [member names] |
| **PartyPlayerJoined** | 231 | Player joins party | username |
| **PartyPlayerLeft** | 233 | Player leaves party | username |
| **PartyDisbanded** | 230 | Party disbanded | (none) |

### Operations
| Operation | Code | Purpose | Parameters |
|-----------|------|---------|------------|
| **OP_JOIN** | 2 | Zone entry | Character ID, username |
| **OP_CHANGE_CLUSTER** | 4 | Zone change | Character ID, username, zone |

---

## 🎯 Data Tracked Per Player

```rust
pub struct Entity {
    pub id: u32,                  // Character ID
    pub x: f32, y: f32, z: f32,   // Position
    pub name: String,             // Player name
    pub guild: String,            // Guild name
    pub alliance: Option<String>, // Alliance name
    pub faction: i32,             // 0=passive, 255=hostile, 1-6=faction
    pub current_health: f32,      // Current HP (0 = dead)
    pub max_health: f32,          // Max HP
    pub equipment_ids: Vec<i32>,  // Item IDs per slot
    pub is_dead: bool,            // Health <= 0
    pub in_combat: bool,          // Combat state
    pub detected_at: Instant,     // Zone entry time
    pub last_seen: Instant,       // Last update time
}
```

---

## 🎮 UI Examples

### TUI Display
```
OpenRadar - Albion Online Network Monitor

🤝 ⚠️ ⚔️ [CrimsonGuild] <EasternAlliance> HostilePlayer 💀
    X:  1234.5 Y:  5678.9 Z:     0.0 Health: [0%]

🤝 ⚫ [AllyGuild] AllyPlayer
    X:  2000.0 Y:  3000.0 Z:   100.0 Health: [95%]

🚩 ⚔️ FactionPlayer
    X:  5000.0 Y:  6000.0 Z:    50.0 Health: [75%]

✨ PassivePlayer
    X:  8000.0 Y:  9000.0 Z:   200.0 Health: [100%]
```

**Indicators:**
- 🤝 = Party member
- ⚠️ = Hostile (red name)
- 🚩 = Faction player
- ⚔️ = In combat
- 💀 = Dead
- ✨ = Passive/safe

---

## 📝 Logging

All events are automatically logged to `logs/sessions/session_TIMESTAMP.jsonl`:

```json
{"level":"info","tag":"PKT","message":"NewCharacter(29): ID=123456 Name='PlayerName' Guild='MyGuild' Alliance='MyAlliance' Faction=255"}
{"level":"info","tag":"PKT","message":"Move(3): ID=123456 X=1234.50 Y=5678.90 Z=0.00"}
{"level":"debug","tag":"PKT","message":"HealthUpdate(6): ID=123456 Health=95%"}
{"level":"info","tag":"PKT","message":"👋 CharacterLeft(1): ID=123456"}
{"level":"info","tag":"PKT","message":"👥 PartyJoined(229): 3 members - Player1, Player2, Player3"}
```

---

## 🔧 Configuration

### Network Adapter
- Auto-detected on startup
- Override with: `./target/release/openradar --ip 192.168.1.100`

### UI Selection
- **1** = TUI (default, recommended)
- **2** = Terminal Overlay
- **3** = Window Overlay

### Port
- Listens on **UDP 5056** (Albion game server port)

---

## 🏗️ Architecture

```
Network (UDP 5056)
    ↓
Packet Capture (libpcap)
    ↓
Photon Protocol Parser (deserialize all types)
    ↓
Event Handler (match Albion event types)
    ↓
Entity Tracker (thread-safe HashMap)
    ↓
UI Renderers (TUI / Overlay / Window)
```

### Key Components
- **src/main.rs** (550 lines) - Packet handler, event dispatch, CLI
- **src/entities.rs** (350 lines) - Entity tracking with party management
- **src/photon/** (1200+ lines) - Complete Photon Protocol16 deserializer
- **src/tui/mod.rs** (220 lines) - Terminal UI with threat indicators
- **src/overlay/** - Terminal & window overlay implementations
- **src/logger/** - Session logging to JSONL

---

## 🔒 Privacy & Safety

- ✅ **Local Only** - No data transmission, purely local monitoring
- ✅ **Own Computer** - Runs completely on your machine
- ✅ **Party Protection** - Easily identify party members to avoid tracking
- ✅ **Passive** - Never sends packets, only observes incoming traffic

---

## ⚡ Performance

- **Memory**: 10-50MB typical (depends on player count)
- **CPU**: <1% idle, 5-10% during capture peaks
- **Latency**: <5ms event processing
- **Scalability**: Tested with 200+ tracked entities

---

## 🐛 Known Issues

- **TUI limited to 15 entities** - Full list tracked in memory, just limited display
- **window_overlay minimal styling** - Functional but basic egui implementation
- **No persistence between sessions** - Data clears on restart (by design)

---

## 📚 Documentation

- [ENHANCEMENT_PLAN.md](ENHANCEMENT_PLAN.md) - Original design & implementation plan
- [CODEBASE_STATUS.md](CODEBASE_STATUS.md) - Detailed architecture & features
- [Session Logs](logs/sessions/) - JSONL event logs from test runs

---

## 🚀 Roadmap

### v0.2 (Future)
- [ ] Filter UI (exclude party, search by name)
- [ ] Guild stats (members, kills, locations)
- [ ] Distance/bearing visual display
- [ ] Equipment power lookup
- [ ] WebUI dashboard

### v0.3
- [ ] Real-time alerts (hostile detected)
- [ ] Map integration
- [ ] Chat integration
- [ ] Multi-zone tracking

---

## 🤝 Contributing

Contributions welcome! Please:
1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

---

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

---

## ⚖️ Legal Notice

**OpenRadar** is an educational tool for learning Albion Online's network protocol. It is **a passive observer only** - it listens to your own game traffic and does not:
- Send packets to the game server
- Modify game behavior
- Provide unfair advantages
- Violate Albion's Terms of Service when used locally

Use responsibly and in accordance with game rules.

---

## 🙏 Acknowledgments

- Inspired by [Albion-Online-OpenRadar](https://github.com/ao-libre/openradar) (JavaScript version)
- Built with reference to heatsync DPS meter implementation
- Photon Protocol research from community

---

## 📞 Support

- **Issues**: [GitHub Issues](../../issues)
- **Discussions**: [GitHub Discussions](../../discussions)
- **Documentation**: See `/docs` folder and inline code comments

---

**Made with ❤️ for Albion Online players**

*[Back to Top](#openradar---albion-online-network-radar-)*
