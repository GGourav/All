# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] - 2026-03-30

### Added
- ✨ **Complete Photon Protocol16 deserializer** with support for all data types
- 🎮 **Real-time player tracking** with position updates (Event 3, 483)
- 👤 **Player detection** via NewCharacter events (Event 29)
- 🎯 **Self-identification** via OP_JOIN/OP_CHANGE_CLUSTER operations
- 🤝 **Party member tracking** (Events 229-233: PartyJoined, PartyPlayerJoined/Left, PartyDisbanded)
- ❤️ **Health monitoring** with death detection (Events 6-7: HealthUpdate, HealthUpdates)
- ⚔️ **Combat state tracking** (Event 273: InCombatStateUpdate)
- ⚠️ **Threat detection** based on faction (hostile, faction, passive)
- 📦 **Equipment tracking** from Event 29 parameters
- 👋 **Player removal** on leave events (Event 1: CharacterLeft)
- 🗺️ **Automatic zone clearing** on zone transitions (OP_CHANGE_CLUSTER)

### UI Features
- 🎨 **Terminal UI (TUI)** with table view and threat indicators
  - Shows: Threat icon, combat state, party member indicator, guild, alliance, name, health, coordinates
  - Displays first 15 entities with full data tracked in memory
- 🗺️ **Terminal Overlay** with map visualization
- 🪟 **Window Overlay** with floating egui-based interface
- 🚨 **Visual Indicators**:
  - ⚠️ Hostile players (faction 255)
  - 🚩 Faction players (faction 1-6)
  - ⚔️ Active combat state
  - 💀 Dead players (health ≤ 0)
  - 🤝 Party members

### Data Tracking
- Entity ID, position (X, Y, Z), name, guild, alliance
- Current/max health with death detection
- Faction type (passive, hostile, faction)
- Equipment IDs for all 9 slots
- Combat state and timestamp tracking
- Local player self-identification

### Logging
- 📝 Session logging to JSONL format (`logs/sessions/session_*.jsonl`)
- Event-level logging (Info, Debug, Error)
- Raw parameter logging for debugging
- Automatic log rotation and file management

### Utility Features
- 📏 Distance calculation from local player to any entity
- 🧭 Bearing calculation (directional angle)
- 🧹 Automatic stale entity cleanup (300-second timeout)
- 🔄 Robust numeric type extraction (Float, Double, Int, Short, Byte, Long)
- 🛡️ Thread-safe entity and party tracking with Arc/Mutex

### Developer Features
- Complete Rust source code (1000+ lines, well-commented)
- Modular architecture (photon, capture, tui, logger, entities modules)
- CLI argument support (`--ip`, `--version`)
- Comprehensive error handling
- Performance metrics (packets/sec, error count, entity count)

### Configuration
- Automatic network adapter detection
- CLI override for adapter IP selection
- Three UI modes selectable at startup
- Configurable stale timeout (default 300s)

### Network
- UDP packet capture on port 5056
- Passive listening (no packet transmission)
- Support for both Photon events and operations
- Robust deserialization error handling

### Documentation
- Comprehensive README with features, quick start, and examples
- Detailed architecture documentation
- Enhancement plan and implementation notes
- Session logs from reference testing

## [Unreleased] - Future Versions

### Planned (v0.2)
- UI filtering and search functionality
- Guild statistics and tracking
- Visual distance/bearing display on TUI
- Equipment power lookup integration
- Web UI dashboard

### Planned (v0.3)
- Real-time threat alerts
- In-game map integration
- Chat integration
- Multi-zone persistent tracking
- Advanced threat assessment

---

## Implementation Notes

### Key Decisions
1. **Language**: Rust for performance and safety
2. **Architecture**: Real-time async processing with tokio runtime
3. **Storage**: In-memory HashMap for O(1) entity lookup
4. **Thread Safety**: Arc/Mutex for concurrent packet processing
5. **Logging**: JSONL format for easy parsing and analysis

### Known Limitations
1. TUI displays max 15 entities (full data tracked)
2. Window overlay has minimal styling (egui basic)
3. No data persistence between sessions
4. Requires libpcap/WinPcap for network capture

### Performance
- Memory: 10-50MB typical
- CPU: <1% idle
- Latency: <5ms processing
- Supports 200+ concurrent entities

---

## Version Tags

- `v0.1.0` - Initial release with all core features
  - Full player tracking
  - Health and combat monitoring
  - Party member identification
  - Three UI modes
  - Complete documentation
