//! logger/console.rs — Console output with colors and callbacks

use colored::Colorize;
use std::sync::RwLock;

/// Callback function that receives log messages
pub type LogCallback = Box<dyn Fn(&str, &str, &str) + Send + Sync>;

/// Global callback and mutex
static LOG_CALLBACK: RwLock<Option<LogCallback>> = RwLock::new(None);

/// Set a callback function to receive all log messages
/// When set, logs are sent to callback instead of stdout
pub fn set_log_callback(cb: LogCallback) {
    let mut callback = LOG_CALLBACK.write().unwrap();
    *callback = Some(cb);
}

/// Clear the log callback, reverting to stdout
pub fn clear_log_callback() {
    let mut callback = LOG_CALLBACK.write().unwrap();
    *callback = None;
}

/// Format current time as HH:MM:SS
fn timestamp() -> String {
    chrono::Local::now().format("%H:%M:%S").to_string()
}

/// Internal log function that sends to callback or prints to stdout
pub fn log(level: &str, tag: &str, msg: &str) {
    // Try callback first
    {
        let callback = LOG_CALLBACK.read().unwrap();
        if let Some(cb) = callback.as_ref() {
            cb(level, tag, msg);
            return;
        }
    }

    // Fallback to stdout with colors
    let ts = format!("[{}]", timestamp()).black().bold();
    let tag_str = match level {
        "SUCCESS" => format!("[{}]", tag).green(),
        "WARN" => format!("[{}]", tag).yellow(),
        "ERROR" => format!("[{}]", tag).red(),
        _ => format!("[{}]", tag).cyan(),
    };

    println!("{} {} {}", ts, tag_str, msg);
}

/// Print info message (cyan tag)
pub fn print_info(tag: &str, msg: &str) {
    log("INFO", tag, msg);
}

/// Print success message (green tag)
pub fn print_success(tag: &str, msg: &str) {
    log("SUCCESS", tag, msg);
}

/// Print warning message (yellow tag)
pub fn print_warn(tag: &str, msg: &str) {
    log("WARN", tag, msg);
}

/// Print error message (red tag)
pub fn print_error(tag: &str, msg: &str) {
    log("ERROR", tag, msg);
}
