//! logger/mod.rs — File-based logging with buffering

pub mod console;

use anyhow::{Context, Result};
use chrono::Local;
use serde::Serialize;
use std::fs;
use std::io::Write;
use std::path::PathBuf;
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};
use tokio::time::interval;

pub use console::{clear_log_callback, print_error, print_info, print_success, print_warn, set_log_callback};

const FLUSH_INTERVAL: Duration = Duration::from_secs(2);
const MAX_BUFFER_SIZE: usize = 500;

/// A log entry that gets serialized to JSON
#[derive(Debug, Clone, Serialize)]
pub struct LogEntry {
    pub timestamp: String,
    pub level: String,
    pub category: String,
    pub event: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub data: Option<serde_json::Value>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub context: Option<std::collections::HashMap<String, String>>,
}

/// Statistics about logging
#[derive(Debug, Clone, Copy)]
pub struct LogStats {
    pub total_entries: u64,
    pub total_batches: u64,
    pub client_entries: u64,
    pub server_entries: u64,
    pub buffer_size: usize,
}

/// File-based logger with buffering and stats tracking
pub struct Logger {
    logs_dir: PathBuf,
    current_session_file: PathBuf,
    session_start_time: Instant,
    enabled: Arc<Mutex<bool>>,

    // Buffering
    buffer: Arc<Mutex<Vec<LogEntry>>>,

    // Stats
    total_entries: Arc<Mutex<u64>>,
    total_batches: Arc<Mutex<u64>>,
    client_entries: Arc<Mutex<u64>>,
    server_entries: Arc<Mutex<u64>>,

    // For shutdown signaling
    shutdown_flag: Arc<Mutex<bool>>,
}

impl Logger {
    /// Create a new logger
    pub fn new(logs_dir: impl Into<PathBuf>) -> Result<Self> {
        let logs_dir = logs_dir.into();

        // Create directories
        let dirs = vec![
            logs_dir.join("sessions"),
            logs_dir.join("errors"),
            logs_dir.join("debug"),
        ];

        for dir in dirs {
            fs::create_dir_all(&dir).context("Failed to create log directory")?;
        }

        // Create session file
        let timestamp = Local::now().format("%Y-%m-%dT%H-%M-%S").to_string();
        let current_session_file = logs_dir.join("sessions").join(format!("session_{}.jsonl", timestamp));

        Ok(Self {
            logs_dir,
            current_session_file,
            session_start_time: Instant::now(),
            enabled: Arc::new(Mutex::new(true)),
            buffer: Arc::new(Mutex::new(Vec::with_capacity(MAX_BUFFER_SIZE))),
            total_entries: Arc::new(Mutex::new(0)),
            total_batches: Arc::new(Mutex::new(0)),
            client_entries: Arc::new(Mutex::new(0)),
            server_entries: Arc::new(Mutex::new(0)),
            shutdown_flag: Arc::new(Mutex::new(false)),
        })
    }

    /// Start the flush loop (should be spawned as a task)
    pub async fn start_flush_loop(&self) {
        let mut ticker = interval(FLUSH_INTERVAL);
        let buffer = Arc::clone(&self.buffer);
        let total_entries = Arc::clone(&self.total_entries);
        let total_batches = Arc::clone(&self.total_batches);
        let current_file = self.current_session_file.clone();
        let shutdown = Arc::clone(&self.shutdown_flag);

        loop {
            ticker.tick().await;

            // Check if we should shutdown
            if *shutdown.lock().unwrap() {
                // Final flush
                self.flush_internal(buffer.clone(), total_entries.clone(), total_batches.clone(), &current_file);
                break;
            }

            self.flush_internal(buffer.clone(), total_entries.clone(), total_batches.clone(), &current_file);
        }
    }

    /// Internal flush implementation
    fn flush_internal(
        &self,
        buffer: Arc<Mutex<Vec<LogEntry>>>,
        total_entries: Arc<Mutex<u64>>,
        total_batches: Arc<Mutex<u64>>,
        file_path: &PathBuf,
    ) {
        let mut buf = buffer.lock().unwrap();
        if buf.is_empty() {
            return;
        }

        let batch: Vec<LogEntry> = buf.drain(..).collect();
        drop(buf); // Release lock early

        // Write to file
        if let Ok(mut f) = fs::OpenOptions::new()
            .append(true)
            .create(true)
            .open(file_path)
        {
            for entry in &batch {
                if let Ok(line) = serde_json::to_string(entry) {
                    let _ = writeln!(f, "{}", line);
                }
            }
        }

        // Update stats
        *total_entries.lock().unwrap() += batch.len() as u64;
        *total_batches.lock().unwrap() += 1;
    }

    /// Write client logs (from WebSocket subscribers)
    pub fn write_logs(&self, logs: Vec<serde_json::Value>) {
        if logs.is_empty() {
            return;
        }

        let logs_count = logs.len();
        let mut buf = self.buffer.lock().unwrap();
        for log_val in logs {
            let entry = LogEntry {
                timestamp: Local::now().to_rfc3339(),
                level: "CLIENT".to_string(),
                category: "[CLIENT] logs".to_string(),
                event: "client_log".to_string(),
                data: Some(log_val),
                context: None,
            };
            buf.push(entry);
        }
        let should_flush = buf.len() >= MAX_BUFFER_SIZE;
        drop(buf);

        if should_flush {
            self.flush();
        }

        *self.client_entries.lock().unwrap() += logs_count as u64;
    }

    /// Log a server-side event
    pub fn log(&self, level: &str, category: &str, event: &str, data: Option<serde_json::Value>) {
        if !*self.enabled.lock().unwrap() {
            return;
        }

        let mut context = std::collections::HashMap::new();
        context.insert(
            "sessionDuration".to_string(),
            self.session_start_time.elapsed().as_secs().to_string(),
        );

        let entry = LogEntry {
            timestamp: Local::now().to_rfc3339(),
            level: level.to_string(),
            category: format!("[SERVER] {}", category),
            event: event.to_string(),
            data,
            context: if context.is_empty() { None } else { Some(context) },
        };

        let mut buf = self.buffer.lock().unwrap();
        buf.push(entry);
        drop(buf);

        *self.server_entries.lock().unwrap() += 1;
    }

    /// Log debug message
    pub fn debug(&self, category: &str, event: &str, data: Option<serde_json::Value>) {
        self.log("DEBUG", category, event, data);
    }

    /// Log info message
    pub fn info(&self, category: &str, event: &str, data: Option<serde_json::Value>) {
        self.log("INFO", category, event, data);
    }

    /// Log warning message
    pub fn warn(&self, category: &str, event: &str, data: Option<serde_json::Value>) {
        self.log("WARN", category, event, data);
    }

    /// Log error message (also writes to dedicated error file)
    pub fn error(&self, category: &str, event: &str, data: Option<serde_json::Value>) {
        self.log("ERROR", category, event, data.clone());

        // Also write to dedicated error file
        let date = Local::now().format("%Y-%m-%d").to_string();
        let error_file = self.logs_dir.join("errors").join(format!("errors_{}.log", date));

        if let Ok(mut f) = fs::OpenOptions::new()
            .append(true)
            .create(true)
            .open(error_file)
        {
            let data_str = serde_json::to_string(&data).unwrap_or_default();
            let line = format!(
                "[{}] {}.{}: {}\n",
                Local::now().to_rfc3339(),
                category,
                event,
                data_str
            );
            let _ = write!(f, "{}", line);
        }
    }

    /// Log critical message
    pub fn critical(&self, category: &str, event: &str, data: Option<serde_json::Value>) {
        self.log("CRITICAL", category, event, data);
    }

    /// Manual flush of buffer
    pub fn flush(&self) {
        self.flush_internal(
            Arc::clone(&self.buffer),
            Arc::clone(&self.total_entries),
            Arc::clone(&self.total_batches),
            &self.current_session_file,
        );
    }

    /// Get current statistics
    pub fn stats(&self) -> LogStats {
        let buf = self.buffer.lock().unwrap();
        LogStats {
            total_entries: *self.total_entries.lock().unwrap(),
            total_batches: *self.total_batches.lock().unwrap(),
            client_entries: *self.client_entries.lock().unwrap(),
            server_entries: *self.server_entries.lock().unwrap(),
            buffer_size: buf.len(),
        }
    }

    /// Set enabled state
    pub fn set_enabled(&self, enabled: bool) {
        *self.enabled.lock().unwrap() = enabled;
        if enabled {
            print_success("LOG", "Server-side logging ENABLED");
        } else {
            print_warn("LOG", "Server-side logging DISABLED");
        }
    }

    /// Check if logging is enabled
    pub fn is_enabled(&self) -> bool {
        *self.enabled.lock().unwrap()
    }

    /// Print session file info to console
    pub fn print_session_info(&self) {
        print_info("LOG", &format!("Session file: {}", self.current_session_file.display()));
    }

    /// Stop the flush loop
    pub fn stop(&self) {
        *self.shutdown_flag.lock().unwrap() = true;
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_log_entry_serialization() {
        let entry = LogEntry {
            timestamp: "2024-01-01T12:00:00".to_string(),
            level: "INFO".to_string(),
            category: "[SERVER] test".to_string(),
            event: "test_event".to_string(),
            data: Some(serde_json::json!({"key": "value"})),
            context: None,
        };

        let json = serde_json::to_string(&entry).unwrap();
        assert!(json.contains("INFO"));
        assert!(json.contains("test_event"));
    }
}
