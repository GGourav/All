//! photon/mod.rs — public API of the photon module

pub mod reader;
pub mod types;
pub mod command;
pub mod packet;
pub mod protocol16;

// Re-export the most commonly used items so callers can write
// `photon::parse_packet`, `photon::deserialize_event`, etc.
pub use types::{
    PhotonPacket, Command, CommandPayload,
    EventData, OperationRequest, OperationResponse,
    PhotonValue,
    MSG_TYPE_EVENT, MSG_TYPE_REQUEST, MSG_TYPE_RESPONSE,
    CMD_TYPE_RELIABLE, CMD_TYPE_UNRELIABLE, CMD_TYPE_DISCONNECT,
};
pub use packet::parse_packet;
pub use protocol16::{deserialize_event, deserialize_request, deserialize_response};
