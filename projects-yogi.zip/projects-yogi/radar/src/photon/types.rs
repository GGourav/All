//! photon/types.rs
//!
//! Shared data types used across the photon module.
//! Mirrors the structs and type-code constants scattered across the Go package.

use std::collections::HashMap;
use serde::Serialize;

// ── Protocol 16 type codes ────────────────────────────────────────────────────

pub const TYPE_UNKNOWN:            u8 = 0x00;
pub const TYPE_NULL:               u8 = 0x2A; // '*'
pub const TYPE_BYTE:               u8 = 0x62; // 'b'
pub const TYPE_BOOLEAN:            u8 = 0x6F; // 'o'
pub const TYPE_SHORT:              u8 = 0x6B; // 'k'
pub const TYPE_INTEGER:            u8 = 0x69; // 'i'
pub const TYPE_INTEGER_ARRAY:      u8 = 0x6E; // 'n'
pub const TYPE_LONG:               u8 = 0x6C; // 'l'
pub const TYPE_DOUBLE:             u8 = 0x64; // 'd'
pub const TYPE_FLOAT:              u8 = 0x66; // 'f'
pub const TYPE_STRING:             u8 = 0x73; // 's'
pub const TYPE_STRING_ARRAY:       u8 = 0x61; // 'a'
pub const TYPE_BYTE_ARRAY:         u8 = 0x78; // 'x'
pub const TYPE_ARRAY:              u8 = 0x79; // 'y'
pub const TYPE_OBJECT_ARRAY:       u8 = 0x7A; // 'z'
pub const TYPE_DICTIONARY:         u8 = 0x44; // 'D'
pub const TYPE_HASHTABLE:          u8 = 0x68; // 'h'
pub const TYPE_EVENT_DATA:         u8 = 0x65; // 'e'
pub const TYPE_OPERATION_RESPONSE: u8 = 0x71; // 'q'
pub const TYPE_OPERATION_REQUEST:  u8 = 0x72; // 'r'

/// Maximum array/byte-array allocation size — guards against malformed packets.
pub const MAX_ARRAY_SIZE: usize = 65_536;

// ── Command type constants ────────────────────────────────────────────────────

pub const CMD_TYPE_DISCONNECT:  u8 = 4;
pub const CMD_TYPE_RELIABLE:    u8 = 6;
pub const CMD_TYPE_UNRELIABLE:  u8 = 7;

// ── Message type constants ────────────────────────────────────────────────────

pub const MSG_TYPE_REQUEST:  u8 = 2;
pub const MSG_TYPE_RESPONSE: u8 = 3;
pub const MSG_TYPE_EVENT:    u8 = 4;

// ── Photon value — a tagged union covering every Protocol16 type ──────────────

/// Every value that Protocol16 can produce.
/// Using an enum keeps dispatch explicit and avoids `Box<dyn Any>`.
#[derive(Debug, Clone, Serialize)]
#[serde(untagged)]
pub enum PhotonValue {
    Null,
    Byte(u8),
    Bool(bool),
    Short(u16),
    Int(u32),
    Long(i64),
    Float(f32),
    Double(f64),
    String(String),
    ByteArray(Vec<u8>),
    IntArray(Vec<u32>),
    StringArray(Vec<String>),
    Array(Vec<PhotonValue>),
    ObjectArray(Vec<PhotonValue>),
    /// Hashtable / Dictionary — keys are also PhotonValues
    Table(Vec<(PhotonValue, PhotonValue)>),
    EventData(Box<EventData>),
    OperationRequest(Box<OperationRequest>),
    OperationResponse(Box<OperationResponse>),
}

// ── High-level Photon message types ──────────────────────────────────────────

/// Photon event (server → client push).
#[derive(Debug, Clone, Serialize)]
pub struct EventData {
    pub code:       u8,
    /// Parameter table: key = u8 param code, value = any PhotonValue
    pub parameters: HashMap<u8, PhotonValue>,
}

/// Photon operation request (client → server).
#[derive(Debug, Clone, Serialize)]
pub struct OperationRequest {
    pub operation_code: u8,
    pub parameters:     HashMap<u8, PhotonValue>,
}

/// Photon operation response (server → client reply).
#[derive(Debug, Clone, Serialize)]
pub struct OperationResponse {
    pub operation_code: u8,
    pub return_code:    u16,
    pub debug_message:  PhotonValue,
    pub parameters:     HashMap<u8, PhotonValue>,
}

// ── Packet / Command types ────────────────────────────────────────────────────

/// A fully parsed Photon UDP packet.
#[derive(Debug)]
pub struct PhotonPacket {
    pub peer_id:       u16,
    pub flags:         u8,
    pub command_count: u8,
    pub timestamp:     u32,
    pub challenge:     u32,
    pub commands:      Vec<Command>,
}

/// A single Photon command extracted from a packet.
#[derive(Debug)]
pub struct Command {
    pub command_type:    u8,
    pub channel_id:      u8,
    pub command_flags:   u8,
    pub command_length:  u32,
    pub sequence_number: u32,
    pub message_type:    u8,
    /// Parsed payload — `None` for disconnect / incomplete commands.
    pub payload:         Option<CommandPayload>,
}

impl Command {
    pub fn is_event(&self)    -> bool { self.message_type == MSG_TYPE_EVENT    }
    pub fn is_request(&self)  -> bool { self.message_type == MSG_TYPE_REQUEST  }
    pub fn is_response(&self) -> bool { self.message_type == MSG_TYPE_RESPONSE }
}

/// The deserialized body of a reliable/unreliable command.
#[derive(Debug)]
pub struct CommandPayload {
    /// Raw bytes — handed to Protocol16 for deserialization.
    pub data: Vec<u8>,
}
