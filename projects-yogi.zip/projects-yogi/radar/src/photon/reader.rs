//! photon/reader.rs
//!
//! A cursor-style big-endian byte reader.
//! Mirrors Go's internal `Reader` type used throughout the photon package.

use anyhow::{bail, Result};

/// Cheap, borrowing byte reader.
/// All multi-byte integers are read as **big-endian** unless noted otherwise.
pub struct Reader<'a> {
    data: &'a [u8],
    pos:  usize,
}

impl<'a> Reader<'a> {
    /// Create a reader over a byte slice.
    #[inline]
    pub fn new(data: &'a [u8]) -> Self {
        Self { data, pos: 0 }
    }

    /// Bytes not yet consumed.
    #[inline]
    pub fn remaining(&self) -> usize {
        self.data.len().saturating_sub(self.pos)
    }

    /// Advance the cursor without reading (Go's `reader.Skip`).
    #[inline]
    pub fn skip(&mut self, n: usize) {
        self.pos = (self.pos + n).min(self.data.len());
    }

    /// Return a sub-slice of `n` bytes and advance cursor.
    pub fn read_bytes(&mut self, n: usize) -> Result<&'a [u8]> {
        if self.remaining() < n {
            bail!("not enough data: need {n}, have {}", self.remaining());
        }
        let slice = &self.data[self.pos..self.pos + n];
        self.pos += n;
        Ok(slice)
    }

    // ── scalar readers ────────────────────────────────────────────────────────

    pub fn read_u8(&mut self) -> Result<u8> {
        if self.remaining() < 1 {
            bail!("unexpected EOF reading u8");
        }
        let v = self.data[self.pos];
        self.pos += 1;
        Ok(v)
    }

    pub fn read_u16_be(&mut self) -> Result<u16> {
        let b = self.read_bytes(2)?;
        Ok(u16::from_be_bytes([b[0], b[1]]))
    }

    pub fn read_u32_be(&mut self) -> Result<u32> {
        let b = self.read_bytes(4)?;
        Ok(u32::from_be_bytes([b[0], b[1], b[2], b[3]]))
    }

    pub fn read_i64_be(&mut self) -> Result<i64> {
        let b = self.read_bytes(8)?;
        Ok(i64::from_be_bytes(b.try_into().unwrap()))
    }

    pub fn read_f32_be(&mut self) -> Result<f32> {
        let bits = self.read_u32_be()?;
        Ok(f32::from_bits(bits))
    }

    pub fn read_f64_be(&mut self) -> Result<f64> {
        let b = self.read_bytes(8)?;
        let bits = u64::from_be_bytes(b.try_into().unwrap());
        Ok(f64::from_bits(bits))
    }

    /// Read a little-endian f32 (used for Albion position fields).
    pub fn read_f32_le_at(&self, offset: usize) -> Option<f32> {
        let end = offset + 4;
        if end > self.data.len() {
            return None;
        }
        let bits = u32::from_le_bytes(self.data[offset..end].try_into().unwrap());
        Some(f32::from_bits(bits))
    }

    /// Expose full data slice (needed for LE position decoding).
    pub fn full_slice(&self) -> &'a [u8] {
        self.data
    }
}
