//! photon/packet.rs
//!
//! Parses the top-level Photon UDP packet.
//! Direct port of packet.go.

use anyhow::Result;
use crate::photon::{
    command::parse_command,
    reader::Reader,
    types::PhotonPacket,
};

/// Parse a raw UDP payload into a `PhotonPacket`.
///
/// Returns `Ok(None)` for payloads that are too small to be valid
/// (mirrors Go's `return nil, nil` for len < 12).
pub fn parse_packet(payload: &[u8]) -> Result<Option<PhotonPacket>> {
    if payload.len() < 12 {
        return Ok(None);
    }

    let mut reader = Reader::new(payload);

    // ── 12-byte Photon packet header ──────────────────────────────────────────
    // peer_id       (2 bytes, BE)
    // flags         (1 byte)
    // command_count (1 byte)
    // timestamp     (4 bytes, BE)
    // challenge     (4 bytes, BE)

    let peer_id       = reader.read_u16_be()?;
    let flags         = reader.read_u8()?;
    let command_count = reader.read_u8()?;
    let timestamp     = reader.read_u32_be()?;
    let challenge     = reader.read_u32_be()?;

    let mut commands = Vec::with_capacity(command_count as usize);

    for _ in 0..command_count {
        match parse_command(&mut reader) {
            Ok(Some(cmd)) => commands.push(cmd),
            Ok(None)      => break, // truncated — keep what we have
            Err(_)        => break, // parse error — keep what we have
        }
    }

    Ok(Some(PhotonPacket {
        peer_id,
        flags,
        command_count,
        timestamp,
        challenge,
        commands,
    }))
}
