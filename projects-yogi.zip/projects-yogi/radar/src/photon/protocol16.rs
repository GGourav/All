//! photon/protocol16.rs
//!
//! Protocol16 binary deserializer — complete port of protocol16.go.
//!
//! All multi-byte integers are big-endian EXCEPT the Albion move-event
//! position floats which are explicitly little-endian (see event code 3).

use std::collections::HashMap;
use anyhow::{bail, Result};

use crate::photon::{
    reader::Reader,
    types::{
        EventData, OperationRequest, OperationResponse, PhotonValue,
        MAX_ARRAY_SIZE,
        TYPE_UNKNOWN, TYPE_NULL, TYPE_BYTE, TYPE_BOOLEAN, TYPE_SHORT,
        TYPE_INTEGER, TYPE_INTEGER_ARRAY, TYPE_LONG, TYPE_DOUBLE, TYPE_FLOAT,
        TYPE_STRING, TYPE_STRING_ARRAY, TYPE_BYTE_ARRAY, TYPE_ARRAY,
        TYPE_OBJECT_ARRAY, TYPE_DICTIONARY, TYPE_HASHTABLE,
        TYPE_EVENT_DATA, TYPE_OPERATION_RESPONSE, TYPE_OPERATION_REQUEST,
    },
};

// ── Public entry points (mirrors Go's package-level functions) ────────────────

/// Deserialize an event from a command payload byte slice.
pub fn deserialize_event(data: &[u8]) -> Result<EventData> {
    let mut r = Reader::new(data);
    deserialize_event_data(&mut r)
}

/// Deserialize an operation request from a command payload byte slice.
pub fn deserialize_request(data: &[u8]) -> Result<OperationRequest> {
    let mut r = Reader::new(data);
    deserialize_operation_request(&mut r)
}

/// Deserialize an operation response from a command payload byte slice.
pub fn deserialize_response(data: &[u8]) -> Result<OperationResponse> {
    let mut r = Reader::new(data);
    deserialize_operation_response(&mut r)
}

// ── Core deserializer — dispatches on type code ───────────────────────────────

pub fn deserialize(reader: &mut Reader, type_code: u8) -> Result<PhotonValue> {
    match type_code {
        TYPE_UNKNOWN | TYPE_NULL => Ok(PhotonValue::Null),

        TYPE_BYTE    => Ok(PhotonValue::Byte(reader.read_u8()?)),
        TYPE_BOOLEAN => Ok(PhotonValue::Bool(reader.read_u8()? != 0)),
        TYPE_SHORT   => Ok(PhotonValue::Short(reader.read_u16_be()?)),
        TYPE_INTEGER => Ok(PhotonValue::Int(reader.read_u32_be()?)),
        TYPE_LONG    => Ok(PhotonValue::Long(reader.read_i64_be()?)),
        TYPE_FLOAT   => Ok(PhotonValue::Float(reader.read_f32_be()?)),
        TYPE_DOUBLE  => Ok(PhotonValue::Double(reader.read_f64_be()?)),

        TYPE_STRING       => deserialize_string(reader).map(PhotonValue::String),
        TYPE_BYTE_ARRAY   => deserialize_byte_array(reader).map(PhotonValue::ByteArray),
        TYPE_INTEGER_ARRAY=> deserialize_integer_array(reader).map(PhotonValue::IntArray),
        TYPE_STRING_ARRAY => deserialize_string_array(reader).map(PhotonValue::StringArray),
        TYPE_ARRAY        => deserialize_array(reader).map(PhotonValue::Array),
        TYPE_OBJECT_ARRAY => deserialize_object_array(reader).map(PhotonValue::ObjectArray),
        TYPE_HASHTABLE    => deserialize_hashtable(reader),
        TYPE_DICTIONARY   => deserialize_dictionary(reader),

        TYPE_EVENT_DATA         => {
            deserialize_event_data(reader)
                .map(|e| PhotonValue::EventData(Box::new(e)))
        }
        TYPE_OPERATION_REQUEST  => {
            deserialize_operation_request(reader)
                .map(|r| PhotonValue::OperationRequest(Box::new(r)))
        }
        TYPE_OPERATION_RESPONSE => {
            deserialize_operation_response(reader)
                .map(|r| PhotonValue::OperationResponse(Box::new(r)))
        }

        other => bail!("type code {:#04x} not implemented", other),
    }
}

// ── String ────────────────────────────────────────────────────────────────────

fn deserialize_string(reader: &mut Reader) -> Result<String> {
    let size = reader.read_u16_be()? as usize;
    if size == 0 {
        return Ok(String::new());
    }
    let bytes = reader.read_bytes(size)?;
    Ok(String::from_utf8_lossy(bytes).into_owned())
}

// ── Byte array ────────────────────────────────────────────────────────────────

fn deserialize_byte_array(reader: &mut Reader) -> Result<Vec<u8>> {
    let size = reader.read_u32_be()? as usize;
    if size > MAX_ARRAY_SIZE {
        bail!("byte array size {size} exceeds maximum {MAX_ARRAY_SIZE}");
    }
    Ok(reader.read_bytes(size)?.to_vec())
}

// ── Integer array ─────────────────────────────────────────────────────────────

fn deserialize_integer_array(reader: &mut Reader) -> Result<Vec<u32>> {
    let size = reader.read_u32_be()? as usize;
    if size > MAX_ARRAY_SIZE {
        bail!("integer array size {size} exceeds maximum {MAX_ARRAY_SIZE}");
    }
    (0..size).map(|_| reader.read_u32_be()).collect()
}

// ── String array ──────────────────────────────────────────────────────────────

fn deserialize_string_array(reader: &mut Reader) -> Result<Vec<String>> {
    let size = reader.read_u16_be()? as usize;
    (0..size).map(|_| deserialize_string(reader)).collect()
}

// ── Typed array ───────────────────────────────────────────────────────────────

fn deserialize_array(reader: &mut Reader) -> Result<Vec<PhotonValue>> {
    let size      = reader.read_u16_be()? as usize;
    let type_code = reader.read_u8()?;
    (0..size).map(|_| deserialize(reader, type_code)).collect()
}

// ── Object array (heterogeneous — each element has its own type byte) ─────────

fn deserialize_object_array(reader: &mut Reader) -> Result<Vec<PhotonValue>> {
    let size = reader.read_u16_be()? as usize;
    (0..size)
        .map(|_| {
            let tc = reader.read_u8()?;
            deserialize(reader, tc)
        })
        .collect()
}

// ── Hashtable (untyped dictionary) ───────────────────────────────────────────

fn deserialize_hashtable(reader: &mut Reader) -> Result<PhotonValue> {
    let size = reader.read_u16_be()? as usize;
    // Key and value type codes are 0 → read type byte per element
    deserialize_dictionary_elements(reader, size, 0, 0)
}

// ── Typed dictionary ──────────────────────────────────────────────────────────

fn deserialize_dictionary(reader: &mut Reader) -> Result<PhotonValue> {
    let key_tc   = reader.read_u8()?;
    let value_tc = reader.read_u8()?;
    let size     = reader.read_u16_be()? as usize;
    deserialize_dictionary_elements(reader, size, key_tc, value_tc)
}

/// Shared logic for hashtables and dictionaries.
/// When `key_tc` / `value_tc` is 0 or NULL each element reads its own type byte.
fn deserialize_dictionary_elements(
    reader:   &mut Reader,
    size:     usize,
    key_tc:   u8,
    value_tc: u8,
) -> Result<PhotonValue> {
    let mut pairs = Vec::with_capacity(size);

    for _ in 0..size {
        // Key
        let ktc = if key_tc == 0 || key_tc == TYPE_NULL {
            reader.read_u8()?
        } else {
            key_tc
        };
        let key = deserialize(reader, ktc)?;

        // Value
        let vtc = if value_tc == 0 || value_tc == TYPE_NULL {
            reader.read_u8()?
        } else {
            value_tc
        };
        let value = deserialize(reader, vtc)?;

        pairs.push((key, value));
    }

    Ok(PhotonValue::Table(pairs))
}

// ── Parameter table ───────────────────────────────────────────────────────────
//
// Format: u16 count, then for each entry: u8 key, u8 type_code, value

fn deserialize_parameter_table(reader: &mut Reader) -> Result<HashMap<u8, PhotonValue>> {
    let count = reader.read_u16_be()? as usize;
    let mut map = HashMap::with_capacity(count);

    for _ in 0..count {
        let key       = reader.read_u8()?;
        let type_code = reader.read_u8()?;
        let value     = deserialize(reader, type_code)?;
        map.insert(key, value);
    }

    Ok(map)
}

// ── EventData ─────────────────────────────────────────────────────────────────

fn deserialize_event_data(reader: &mut Reader) -> Result<EventData> {
    let code   = reader.read_u8()?;
    let mut params = deserialize_parameter_table(reader)?;

    // Event 3 (Move) — positions are embedded little-endian floats inside
    // parameter 1's byte array, at offsets 9–12 and 13–16.
    // This mirrors the special-case in Go's DeserializeEventData.
    if code == 3 {
        if let Some(PhotonValue::ByteArray(bytes)) = params.get(&1) {
            if bytes.len() >= 17 {
                let pos0 = f32::from_bits(u32::from_le_bytes(bytes[9..13].try_into().unwrap()));
                let pos1 = f32::from_bits(u32::from_le_bytes(bytes[13..17].try_into().unwrap()));
                params.insert(4,   PhotonValue::Float(pos0));
                params.insert(5,   PhotonValue::Float(pos1));
                params.insert(252, PhotonValue::Byte(3));
            }
        }
    }

    Ok(EventData { code, parameters: params })
}

// ── OperationRequest ──────────────────────────────────────────────────────────

fn deserialize_operation_request(reader: &mut Reader) -> Result<OperationRequest> {
    let operation_code = reader.read_u8()?;
    let parameters     = deserialize_parameter_table(reader)?;
    Ok(OperationRequest { operation_code, parameters })
}

// ── OperationResponse ─────────────────────────────────────────────────────────

fn deserialize_operation_response(reader: &mut Reader) -> Result<OperationResponse> {
    let operation_code  = reader.read_u8()?;
    let return_code     = reader.read_u16_be()?;

    // Debug message has an inline type byte before its value
    let debug_type_code = reader.read_u8()?;
    let debug_message   = deserialize(reader, debug_type_code)?;

    let parameters = deserialize_parameter_table(reader)?;

    Ok(OperationResponse {
        operation_code,
        return_code,
        debug_message,
        parameters,
    })
}
