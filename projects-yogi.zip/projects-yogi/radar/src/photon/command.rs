//! photon/command.rs
//!
//! Parses a single Photon command from a Reader.
//! Direct port of command.go — same byte layout, same branching logic.

use anyhow::Result;
use crate::photon::{
    reader::Reader,
    types::{
        Command, CommandPayload,
        CMD_TYPE_DISCONNECT, CMD_TYPE_RELIABLE, CMD_TYPE_UNRELIABLE,
    },
};

/// Parse one command from `reader`, advancing it past the consumed bytes.
///
/// Returns `Ok(None)` when there are not enough bytes or the length field is
/// invalid — matching Go's `return nil, nil` convention.
pub fn parse_command(reader: &mut Reader) -> Result<Option<Command>> {
    if reader.remaining() < 12 {
        return Ok(None);
    }

    // ── 12-byte command header ────────────────────────────────────────────────
    // command_type  (1 byte)
    // channel_id    (1 byte)
    // command_flags (1 byte)
    // <padding>     (1 byte, skipped)
    // command_length(4 bytes, BE)
    // sequence_num  (4 bytes, BE)

    let command_type    = reader.read_u8()?;
    let channel_id      = reader.read_u8()?;
    let command_flags   = reader.read_u8()?;
    reader.skip(1); // padding byte
    let command_length  = reader.read_u32_be()?;
    let sequence_number = reader.read_u32_be()?;

    // Payload length = total command length minus the 12-byte header
    let payload_len = (command_length as usize).saturating_sub(12);
    if payload_len > reader.remaining() {
        return Ok(None); // invalid / truncated
    }

    let payload_data = reader.read_bytes(payload_len)?.to_vec();

    let mut cmd = Command {
        command_type,
        channel_id,
        command_flags,
        command_length,
        sequence_number,
        message_type: 0,
        payload: None,
    };

    match command_type {
        CMD_TYPE_UNRELIABLE => {
            // Unreliable commands have an extra 4-byte header before the
            // reliable payload section — skip it, then fall through.
            let mut inner = Reader::new(&payload_data);
            if inner.remaining() < 4 {
                return Ok(Some(cmd));
            }
            inner.skip(4);
            parse_reliable_payload(&mut cmd, &mut inner);
        }

        CMD_TYPE_RELIABLE => {
            let mut inner = Reader::new(&payload_data);
            parse_reliable_payload(&mut cmd, &mut inner);
        }

        CMD_TYPE_DISCONNECT => {
            // No additional parsing needed for disconnect commands.
        }

        _ => {} // unknown command type — return as-is
    }

    Ok(Some(cmd))
}

/// Reads message type byte and stores the remaining bytes as the payload.
/// Mirrors Go's `parseReliableCommand`.
fn parse_reliable_payload(cmd: &mut Command, reader: &mut Reader) {
    if reader.remaining() < 2 {
        return;
    }

    // Skip 1 signature/reserved byte, then read message type
    reader.skip(1);
    let Ok(msg_type) = reader.read_u8() else { return };
    cmd.message_type = msg_type;

    let remaining = reader.remaining();
    if remaining > 0 {
        if let Ok(data) = reader.read_bytes(remaining) {
            cmd.payload = Some(CommandPayload { data: data.to_vec() });
        }
    }
}
