//! window_overlay/mod.rs — Floating desktop overlay window with map view

use anyhow::Result;
use egui::Color32;
use std::sync::Arc;
use std::sync::atomic::{AtomicU64, Ordering};
use std::time::Instant;

const MAP_WIDTH: usize = 60;
const MAP_HEIGHT: usize = 20;
const MAP_REFRESH_MS: u128 = 500;

#[derive(Clone)]
pub struct WindowOverlayApp {
    packets_processed: Arc<AtomicU64>,
    packets_errors: Arc<AtomicU64>,
    bytes_received: Arc<AtomicU64>,
    tracker: crate::entities::EntityTracker,
    last_update: Instant,
}

impl WindowOverlayApp {
    pub fn new(
        packets_processed: Arc<AtomicU64>,
        packets_errors: Arc<AtomicU64>,
        bytes_received: Arc<AtomicU64>,
        tracker: crate::entities::EntityTracker,
    ) -> Self {
        Self {
            packets_processed,
            packets_errors,
            bytes_received,
            tracker,
            last_update: Instant::now(),
        }
    }
}

impl eframe::App for WindowOverlayApp {
    fn update(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        let now = Instant::now();

        // Refresh every 500ms
        if now.duration_since(self.last_update).as_millis() >= MAP_REFRESH_MS {
            self.last_update = now;
            self.tracker.cleanup_stale();
        }

        // Request repaint every frame for smooth updates
        ctx.request_repaint();

        egui::CentralPanel::default().show(ctx, |ui| {
            ui.heading("🎯 OpenRadar Overlay");

            let all_entities = self.tracker.get_all();
            let entities: Vec<_> = all_entities.iter().filter(|(_, e)| !e.name.is_empty()).cloned().collect();
            let packets_processed = self.packets_processed.load(Ordering::Relaxed);
            let entity_count = entities.len();

            ui.label(format!("Players: {} | Packets: {} pkt/s", entity_count, packets_processed / 100));

            ui.separator();

            // Map box
            ui.group(|ui| {
                ui.label("📍 Player Map:");

                let map_id = self.tracker.get_map_id();
                
                if !map_id.is_empty() {
                    let manifest_dir = env!("CARGO_MANIFEST_DIR");
                    let map_path = format!("file://{}/assets/maps/{}.webp", manifest_dir, map_id);
                    
                    // Create a 600x600 viewport for our map
                    let (rect, response) = ui.allocate_exact_size(egui::vec2(600.0, 600.0), egui::Sense::hover());
                    
                    // Retrieve LocalPlayer absolute position
                    let lp = self.tracker.get_local_player();
                    let (lp_x, lp_y) = lp.as_ref().map(|p| (p.x, p.y)).unwrap_or((0.0, 0.0));
                    
                    // Define strict geometric scaling factors
                    let map_scale = 4.0; 
                    let map_pixel_size = 825.0 * map_scale;
                    
                    // Lock the canvas clip rect so the map doesn't visually bleed onto the entire app
                    let mut painter = ui.painter().with_clip_rect(rect);
                    
                    // ── Exact port of Nouuu-Radar's DrawingUtils.transformPoint() ──────────────────
                    // JS source:
                    //   interpolateEntity: hX = -entity.posX + lpX,  hY = entity.posY - lpY
                    //   transformPoint:    angle = -0.785398 (-45°)
                    //                      newX = angle * (hX - hY)
                    //                      newY = angle * (hX + hY)
                    //
                    // MapsDrawing.js map pan:
                    //   hX = lpX,  hY = -lpY  (from interpolate())
                    //   DrawImageMap translates by (-hX*scale, hY*scale) = (-lpX*scale, -lpY*scale)
                    //   Then draws at position (newX, newY) relative to after scale(1,-1)+translate+rotate
                    //
                    // Net effect for map center offset in screen space (both JS canvas and egui Y-down):
                    //   tx = -lpX * scale,  ty = -lpY * scale  → feed into transformPoint
                    let angle: f32 = -0.785398_f32; // -45° radians (Nouuu constant)
                    let zoom = map_scale;

                    // Map center offset: pan so the local player's world position is at screen center.
                    // Matches MapsDrawing.js: hX=lpX, hY=-lpY, then translate(-hX*scale, hY*scale)
                    // = translate(-lpX*scale, -lpY*scale). Under egui's Y-down system:
                    let tx = lp_x * zoom;
                    let ty = -lp_y * zoom;  // MapsDrawing negates lpY: hY = -lpY
                    let map_screen_x = angle * (tx - ty);
                    let map_screen_y = angle * (tx + ty);

                    let map_origin = rect.center() + egui::vec2(map_screen_x, map_screen_y);
                    let map_rect = egui::Rect::from_center_size(map_origin, egui::vec2(map_pixel_size, map_pixel_size));

                    // Map texture: uv y-flip replicates ctx.scale(1,-1); +45° egui rotation
                    // replicates ctx.rotate(-45°) applied after scale(1,-1) flip.
                    ui.put(
                        map_rect,
                        egui::Image::new(&map_path)
                            .uv(egui::Rect::from_min_max(egui::pos2(0.0, 1.0), egui::pos2(1.0, 0.0)))
                            .rotate(std::f32::consts::FRAC_PI_4, egui::vec2(0.5, 0.5))
                    );

                    for (_id, entity) in &entities {
                        // Skip entities that were spawned but never received a real coordinate.
                        // (999999 is our sentinel for "position unknown".)
                        if entity.x.abs() > 50_000.0 || entity.y.abs() > 50_000.0 {
                            continue;
                        }

                        // Exact port of interpolateEntity + transformPoint:
                        //   hX = -entity.posX + lpX,  hY = entity.posY - lpY
                        //   screen_x = angle * (hX - hY),  screen_y = angle * (hX + hY)
                        let hx = -entity.x + lp_x;
                        let hy =  entity.y - lp_y;
                        let sx = (hx - hy) * angle * zoom;
                        let sy = (hx + hy) * angle * zoom;

                        let pos = rect.center() + egui::vec2(sx, sy);

                        // Prevent rendering overhead for objects outside of the clipping mask
                        let margin = 20.0;
                        if pos.x < rect.min.x - margin || pos.x > rect.max.x + margin || pos.y < rect.min.y - margin || pos.y > rect.max.y + margin {
                            continue;
                        }

                        let color = if entity.faction == 255 { Color32::RED } else { Color32::GREEN };

                        painter.circle_filled(pos, 4.0, color);
                        painter.text(
                            pos + egui::vec2(5.0, -5.0),
                            egui::Align2::LEFT_BOTTOM,
                            &entity.name,
                            egui::FontId::proportional(12.0),
                            Color32::WHITE,
                        );
                    }

                    // Directly and permanently anchor the Local Player (YOU) at exactly (300, 300) [Center]
                    if let Some(ref lp_obj) = lp {
                        let center_pos = rect.center();
                        painter.circle_filled(center_pos, 6.0, Color32::from_rgb(0, 150, 255));
                        painter.circle_stroke(center_pos, 7.0, egui::Stroke::new(1.0, Color32::WHITE));
                        painter.text(
                            center_pos + egui::vec2(6.0, -6.0),
                            egui::Align2::LEFT_BOTTOM,
                            &lp_obj.name,
                            egui::FontId::proportional(14.0),
                            Color32::WHITE,
                        );
                    }
                } else {
                    ui.label("Map ID unknown. Waiting for zone change...");
                    // Create map fallback
                    let map = create_map(&entities);

                    // Draw map with monospace font
                    let _monospace = egui::FontId::monospace(12.0);
                    let mut map_text = String::new();
                    for row in map {
                        for ch in row {
                            map_text.push(ch);
                        }
                        map_text.push('\n');
                    }

                    ui.code(&map_text);
                }
            });

            ui.separator();

            // Player list
            ui.group(|ui| {
                ui.label("👥 Player List (first 20):");

                for (idx, (_id, entity)) in entities.iter().enumerate().take(20) {
                    let marker = if idx < 9 {
                        format!("{}", idx + 1)
                    } else if idx < 35 {
                        format!("{}", ((idx - 9) as u8 + b'A') as char)
                    } else {
                        "*".to_string()
                    };

                    let display = if !entity.guild.is_empty() && entity.alliance.as_ref().map(|a| !a.is_empty()).unwrap_or(false) {
                        format!("[{}] <{}> {}", entity.guild, entity.alliance.as_ref().unwrap(), entity.name)
                    } else if !entity.guild.is_empty() {
                        format!("[{}] {}", entity.guild, entity.name)
                    } else if entity.alliance.as_ref().map(|a| !a.is_empty()).unwrap_or(false) {
                        format!("<{}> {}", entity.alliance.as_ref().unwrap(), entity.name)
                    } else {
                        entity.name.clone()
                    };

                    ui.horizontal(|ui| {
                        ui.label(egui::RichText::new(&marker).monospace().strong().color(Color32::YELLOW));
                        ui.label(format!("→ {}", display));
                    });
                }

                if entity_count > 20 {
                    ui.label(format!("... and {} more", entity_count - 20));
                }
            });
        });
    }
}

fn create_map(entities: &[(u32, crate::entities::Entity)]) -> Vec<Vec<char>> {
    let mut map = vec![vec!['.'; MAP_WIDTH]; MAP_HEIGHT];

    if entities.is_empty() {
        return map;
    }

    // Find bounds
    let (min_x, max_x, min_y, max_y) = calculate_bounds(entities);
    let width_range = (max_x - min_x).max(1.0);
    let height_range = (max_y - min_y).max(1.0);

    // Plot players
    for (idx, (_id, entity)) in entities.iter().enumerate() {
        let grid_x = {
            let normalized = (entity.x - min_x) / width_range;
            ((normalized * (MAP_WIDTH - 1) as f32).max(0.0).min((MAP_WIDTH - 1) as f32)) as usize
        };
        let grid_y = {
            let normalized = (entity.y - min_y) / height_range;
            ((normalized * (MAP_HEIGHT - 1) as f32).max(0.0).min((MAP_HEIGHT - 1) as f32)) as usize
        };

        if grid_x < MAP_WIDTH && grid_y < MAP_HEIGHT {
            let marker = if idx < 9 {
                (b'1' + idx as u8) as char
            } else if idx < 35 {
                (b'A' + (idx - 9) as u8) as char
            } else {
                '*'
            };
            map[grid_y][grid_x] = marker;
        }
    }

    map
}

fn calculate_bounds(entities: &[(u32, crate::entities::Entity)]) -> (f32, f32, f32, f32) {
    let mut min_x = f32::MAX;
    let mut max_x = f32::MIN;
    let mut min_y = f32::MAX;
    let mut max_y = f32::MIN;

    for (_id, entity) in entities {
        min_x = min_x.min(entity.x);
        max_x = max_x.max(entity.x);
        min_y = min_y.min(entity.y);
        max_y = max_y.max(entity.y);
    }

    if min_x == f32::MAX {
        min_x = 0.0;
    }
    if max_x == f32::MIN {
        max_x = 100.0;
    }
    if min_y == f32::MAX {
        min_y = 0.0;
    }
    if max_y == f32::MIN {
        max_y = 100.0;
    }

    (min_x, max_x, min_y, max_y)
}

pub fn run_window_overlay(state: WindowOverlayApp) -> Result<()> {
    let options = eframe::NativeOptions {
        viewport: egui::ViewportBuilder::default()
            .with_inner_size([800.0, 700.0])
            .with_title("OpenRadar Overlay"),
        ..Default::default()
    };

    let _ = eframe::run_native(
        "OpenRadar",
        options,
        Box::new(move |cc| {
            egui_extras::install_image_loaders(&cc.egui_ctx);
            Box::new(state.clone())
        }),
    );

    Ok(())
}
