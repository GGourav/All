//! overlay/mod.rs — Map-based overlay UI with numbered player dots

use anyhow::Result;
use crossterm::{
    event::{self, Event, KeyCode},
    execute,
    terminal::{disable_raw_mode, enable_raw_mode, EnterAlternateScreen, LeaveAlternateScreen, Clear, ClearType},
};
use std::sync::Arc;
use std::sync::atomic::{AtomicU64, Ordering};
use std::time::{Duration, Instant};
use std::io::{self, Write};

const MAP_WIDTH: usize = 60;
const MAP_HEIGHT: usize = 20;
const MAP_REFRESH_MS: u64 = 500;

pub struct OverlayState {
    pub packets_processed: Arc<AtomicU64>,
    pub packets_errors: Arc<AtomicU64>,
    pub bytes_received: Arc<AtomicU64>,
    pub tracker: crate::entities::EntityTracker,
    last_update: Instant,
}

impl OverlayState {
    pub fn new(
        packets_processed: Arc<AtomicU64>,
        packets_errors: Arc<AtomicU64>,
        bytes_received: Arc<AtomicU64>,
        tracker: crate::entities::EntityTracker,
    ) -> Self {
        Self {
            packets_processed,
            packets_errors,
            bytes_received,
            tracker,
            last_update: Instant::now(),
        }
    }
}

pub async fn run_overlay(state: OverlayState) -> Result<()> {
    enable_raw_mode()?;
    let mut stdout = io::stdout();
    execute!(stdout, EnterAlternateScreen)?;

    let result = run_app(state).await;

    disable_raw_mode()?;
    execute!(io::stdout(), LeaveAlternateScreen)?;

    result
}

async fn run_app(mut state: OverlayState) -> Result<()> {
    let mut stdout = io::stdout();
    let timeout = Duration::from_millis(100);

    loop {
        // Handle input (q to quit)
        if event::poll(timeout)? {
            if let Event::Key(key) = event::read()? {
                if key.code == KeyCode::Char('q') || key.code == KeyCode::Esc {
                    break;
                }
            }
        }

        // Refresh map every 500ms
        let now = Instant::now();
        if now.duration_since(state.last_update).as_millis() >= MAP_REFRESH_MS as u128 {
            state.last_update = now;
            state.tracker.cleanup_stale();

            draw_overlay(&mut stdout, &state)?;
        }
    }

    Ok(())
}

fn draw_overlay(stdout: &mut io::Stdout, state: &OverlayState) -> Result<()> {
    execute!(stdout, Clear(ClearType::All))?;

    // Get player data
    let all_entities = state.tracker.get_all();
    let entities: Vec<_> = all_entities.iter().filter(|(_, e)| !e.name.is_empty()).cloned().collect();
    let packets_processed = state.packets_processed.load(Ordering::Relaxed);
    let _bytes_received = state.bytes_received.load(Ordering::Relaxed);

    // Create map grid
    let mut map = vec![vec!['.'; MAP_WIDTH]; MAP_HEIGHT];

    // Find bounds for coordinate normalization
    let (min_x, max_x, min_y, max_y) = calculate_bounds(&entities);
    let width_range = (max_x - min_x).max(1.0);
    let height_range = (max_y - min_y).max(1.0);

    // Plot players on map (normalize coordinates to fit in grid)
    for (idx, (_id, entity)) in entities.iter().enumerate() {
        let grid_x = {
            let normalized = (entity.x - min_x) / width_range;
            ((normalized * (MAP_WIDTH - 1) as f32).max(0.0).min((MAP_WIDTH - 1) as f32)) as usize
        };
        let grid_y = {
            let normalized = (entity.y - min_y) / height_range;
            ((normalized * (MAP_HEIGHT - 1) as f32).max(0.0).min((MAP_HEIGHT - 1) as f32)) as usize
        };

        if grid_x < MAP_WIDTH && grid_y < MAP_HEIGHT {
            // Use number for player (1-9, then letters)
            let marker = if idx < 9 {
                (b'1' + idx as u8) as char
            } else if idx < 35 {
                (b'A' + (idx - 9) as u8) as char
            } else {
                '*'
            };
            map[grid_y][grid_x] = marker;
        }
    }

    // Draw header
    writeln!(stdout, "╔═══════════════════════════════════════════════════════════╗")?;
    writeln!(
        stdout,
        "║  OpenRadar Overlay - {} Players | {} pkt/s | Press 'q' to exit  ║",
        entities.len(),
        (packets_processed / 1).min(999)
    )?;
    writeln!(stdout, "╠═══════════════════════════════════════════════════════════╣")?;

    // Draw map
    for row in map {
        write!(stdout, "║ ")?;
        for ch in row {
            write!(stdout, "{}", ch)?;
        }
        writeln!(stdout, " ║")?;
    }

    writeln!(stdout, "╠═══════════════════════════════════════════════════════════╣")?;

    // Draw player list
    writeln!(stdout, "║ PLAYER LIST                                               ║")?;
    for (idx, (_id, entity)) in entities.iter().enumerate().take(15) {
        let marker = if idx < 9 {
            (b'1' + idx as u8) as char
        } else if idx < 35 {
            (b'A' + (idx - 9) as u8) as char
        } else {
            '*'
        };

        let display = if !entity.guild.is_empty() && entity.alliance.as_ref().map(|a| !a.is_empty()).unwrap_or(false) {
            format!("[{}] <{}> {}", entity.guild, entity.alliance.as_ref().unwrap(), entity.name)
        } else if !entity.guild.is_empty() {
            format!("[{}] {}", entity.guild, entity.name)
        } else if entity.alliance.as_ref().map(|a| !a.is_empty()).unwrap_or(false) {
            format!("<{}> {}", entity.alliance.as_ref().unwrap(), entity.name)
        } else {
            entity.name.clone()
        };

        let truncated = if display.len() > 50 {
            &display[..47]
        } else {
            &display
        };

        writeln!(stdout, "║{} {} {:<48}║", marker, "→", truncated)?;
    }

    if entities.len() > 15 {
        writeln!(stdout, "║ ... and {} more players                             ║", entities.len() - 15)?;
    }

    writeln!(stdout, "╚═══════════════════════════════════════════════════════════╝")?;
    stdout.flush()?;

    Ok(())
}

fn calculate_bounds(entities: &[(u32, crate::entities::Entity)]) -> (f32, f32, f32, f32) {
    let mut min_x = f32::MAX;
    let mut max_x = f32::MIN;
    let mut min_y = f32::MAX;
    let mut max_y = f32::MIN;

    for (_id, entity) in entities {
        min_x = min_x.min(entity.x);
        max_x = max_x.max(entity.x);
        min_y = min_y.min(entity.y);
        max_y = max_y.max(entity.y);
    }

    if min_x == f32::MAX {
        min_x = 0.0;
    }
    if max_x == f32::MIN {
        max_x = 100.0;
    }
    if min_y == f32::MAX {
        min_y = 0.0;
    }
    if max_y == f32::MIN {
        max_y = 100.0;
    }

    (min_x, max_x, min_y, max_y)
}
