//! entities.rs — Player and entity tracking from Albion packet data

use std::collections::HashMap;
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};

#[derive(Debug, Clone)]
pub struct Entity {
    pub id: u32,
    pub x: f32,
    pub y: f32,
    pub z: f32,
    pub name: String,
    pub guild: String,
    pub alliance: Option<String>,
    pub last_seen: Instant,
    // NEW: Extended player details
    pub faction: i32,              // 0=passive, 1-6=faction city, 255=hostile
    pub current_health: f32,       // Current HP (0 = dead)
    pub max_health: f32,           // Max HP
    pub equipment_ids: Vec<i32>,   // Item IDs for each equipment slot
    // NEW: Tracking state
    pub detected_at: Instant,      // When first seen (zone entry)
    pub is_dead: bool,             // current_health == 0
    pub in_combat: bool,           // In combat state
}

#[derive(Debug, Clone)]
pub struct LocalPlayer {
    pub id: u32,
    pub name: String,
    pub x: f32,
    pub y: f32,
}

pub struct EntityTracker {
    entities: Arc<Mutex<HashMap<u32, Entity>>>,
    stale_timeout: Duration,
    local_player: Arc<Mutex<Option<LocalPlayer>>>,
    party_members: Arc<Mutex<std::collections::HashSet<String>>>,
    current_map_id: Arc<Mutex<String>>,
}

impl EntityTracker {
    pub fn new(stale_timeout: Duration) -> Self {
        Self {
            entities: Arc::new(Mutex::new(HashMap::new())),
            stale_timeout,
            local_player: Arc::new(Mutex::new(None)),
            party_members: Arc::new(Mutex::new(std::collections::HashSet::new())),
            current_map_id: Arc::new(Mutex::new(String::new())),
        }
    }

    /// Update or insert an entity with full data
    pub fn update_entity(
        &self,
        id: u32,
        x: f32,
        y: f32,
        z: f32,
        name: String,
        guild: String,
        alliance: Option<String>,
        faction: i32,
        max_health: f32,
        equipment_ids: Vec<i32>,
    ) {
        let mut entities = self.entities.lock().unwrap();
        entities.insert(
            id,
            Entity {
                id,
                x,
                y,
                z,
                name,
                guild,
                alliance,
                faction,
                current_health: max_health, // Assume full health on spawn
                max_health,
                equipment_ids,
                last_seen: Instant::now(),
                detected_at: Instant::now(),
                is_dead: false,
                in_combat: false,
            },
        );
    }

    /// Update position, optionally updating name/guild/alliance if they're not empty
    pub fn update_with_merge(&self, id: u32, x: f32, y: f32, z: f32, name: String, guild: String, alliance: Option<String>) {
        let mut entities = self.entities.lock().unwrap();
        entities.entry(id)
            .and_modify(|entity| {
                entity.x = x;
                entity.y = y;
                entity.z = z;
                entity.last_seen = Instant::now();
                if !name.is_empty() {
                    entity.name = name.clone();
                }
                if !guild.is_empty() {
                    entity.guild = guild.clone();
                }
                if let Some(a) = alliance {
                    if !a.is_empty() {
                        entity.alliance = Some(a);
                    }
                }
            });
    }

    /// Update position only for existing entities (used for Move events)
    /// Does NOT create new entities
    pub fn update_position(&self, id: u32, x: f32, y: f32, z: f32) {
        let mut entities = self.entities.lock().unwrap();
        if let Some(entity) = entities.get_mut(&id) {
            entity.x = x;
            entity.y = y;
            entity.z = z;
            entity.last_seen = Instant::now();
        }
        
        let mut local_player = self.local_player.lock().unwrap();
        if let Some(ref mut lp) = *local_player {
            if lp.id == id {
                lp.x = x;
                lp.y = y;
            }
        }
    }

    /// Returns true if the entity exists but has never received a real position (still at 999999 sentinel)
    pub fn is_entity_at_unknown_position(&self, id: u32) -> bool {
        let entities = self.entities.lock().unwrap();
        if let Some(entity) = entities.get(&id) {
            entity.x.abs() > 50_000.0 || entity.y.abs() > 50_000.0
        } else {
            false
        }
    }

    /// Remove stale entities (not seen for timeout duration)
    pub fn cleanup_stale(&self) {
        let mut entities = self.entities.lock().unwrap();
        let now = Instant::now();
        entities.retain(|_, entity| now.duration_since(entity.last_seen) < self.stale_timeout);
    }

    /// Get current entity list
    pub fn get_entities(&self) -> Vec<Entity> {
        let entities = self.entities.lock().unwrap();
        entities.values().cloned().collect()
    }

    /// Get all entities as (id, entity) pairs for indexing/enumeration
    pub fn get_all(&self) -> Vec<(u32, Entity)> {
        let entities = self.entities.lock().unwrap();
        entities.iter().map(|(id, entity)| (*id, entity.clone())).collect()
    }

    /// Get entity count
    pub fn count(&self) -> usize {
        let entities = self.entities.lock().unwrap();
        entities.len()
    }

    /// Get cloned Arc for sharing
    pub fn clone_handle(&self) -> Arc<Mutex<HashMap<u32, Entity>>> {
        Arc::clone(&self.entities)
    }

    // === NEW METHODS (Phase 2-5) ===

    /// Set the local (own) player
    pub fn set_local_player(&self, id: u32, name: String) {
        let mut player = self.local_player.lock().unwrap();
        *player = Some(LocalPlayer {
            id,
            name,
            x: 0.0,
            y: 0.0,
        });
    }

    /// Get the local (own) player
    pub fn get_local_player(&self) -> Option<LocalPlayer> {
        self.local_player.lock().unwrap().clone()
    }

    /// Update local player position
    pub fn update_local_player_position(&self, x: f32, y: f32) {
        let mut player = self.local_player.lock().unwrap();
        if let Some(ref mut p) = *player {
            p.x = x;
            p.y = y;
        }
    }

    /// Update entity health
    pub fn update_health(&self, id: u32, current_health: Option<f32>, max_health: Option<f32>) {
        let mut entities = self.entities.lock().unwrap();
        if let Some(entity) = entities.get_mut(&id) {
            if let Some(ch) = current_health {
                entity.current_health = ch;
                entity.is_dead = ch <= 0.0;
            }
            if let Some(mh) = max_health {
                entity.max_health = mh;
            }
            entity.last_seen = Instant::now();
        }
    }

    /// Update entity combat state
    pub fn update_combat_state(&self, id: u32, in_combat: bool) {
        let mut entities = self.entities.lock().unwrap();
        if let Some(entity) = entities.get_mut(&id) {
            entity.in_combat = in_combat;
            entity.last_seen = Instant::now();
        }
    }

    /// Remove an entity (character left)
    pub fn remove_entity(&self, id: u32) {
        let mut entities = self.entities.lock().unwrap();
        entities.remove(&id);
    }

    /// Clear all entities in zone (zone changed)
    pub fn clear_zone(&self) {
        let mut entities = self.entities.lock().unwrap();
        entities.clear();
    }

    /// Get distance from local player to entity
    pub fn get_distance_to_entity(&self, entity_id: u32) -> Option<f32> {
        let local = self.local_player.lock().unwrap();
        let local_player = local.as_ref()?;

        let entities = self.entities.lock().unwrap();
        let entity = entities.get(&entity_id)?;

        let dx = entity.x - local_player.x;
        let dy = entity.y - local_player.y;
        Some((dx * dx + dy * dy).sqrt())
    }

    /// Get bearing from local player to entity (in radians)
    pub fn get_bearing_to_entity(&self, entity_id: u32) -> Option<f32> {
        let local = self.local_player.lock().unwrap();
        let local_player = local.as_ref()?;

        let entities = self.entities.lock().unwrap();
        let entity = entities.get(&entity_id)?;

        let dx = entity.x - local_player.x;
        let dy = entity.y - local_player.y;
        Some(dy.atan2(dx))
    }

    // === PARTY MEMBER TRACKING (New) ===

    /// Add party members from PartyJoined event
    pub fn set_party_members(&self, members: Vec<String>) {
        let mut party = self.party_members.lock().unwrap();
        party.clear();
        for member in members {
            party.insert(member);
        }
    }

    /// Add a single party member (PartyPlayerJoined)
    pub fn add_party_member(&self, username: String) {
        let mut party = self.party_members.lock().unwrap();
        party.insert(username);
    }

    /// Remove a party member (PartyPlayerLeft)
    pub fn remove_party_member(&self, username: &str) {
        let mut party = self.party_members.lock().unwrap();
        party.remove(username);
    }

    /// Clear all party members (PartyDisbanded)
    pub fn clear_party(&self) {
        let mut party = self.party_members.lock().unwrap();
        party.clear();
    }

    /// Check if a player is in party
    pub fn is_party_member(&self, username: &str) -> bool {
        let party = self.party_members.lock().unwrap();
        party.contains(username)
    }

    /// Get list of party members
    pub fn get_party_members(&self) -> Vec<String> {
        let party = self.party_members.lock().unwrap();
        party.iter().cloned().collect()
    }

    /// Get party size
    pub fn party_size(&self) -> usize {
        let party = self.party_members.lock().unwrap();
        party.len()
    }

    /// Set current map based on zone change
    pub fn set_map_id(&self, map_id: String) {
        let mut m = self.current_map_id.lock().unwrap();
        *m = map_id;
    }

    /// Get current map ID
    pub fn get_map_id(&self) -> String {
        self.current_map_id.lock().unwrap().clone()
    }
}

impl Clone for EntityTracker {
    fn clone(&self) -> Self {
        Self {
            entities: Arc::clone(&self.entities),
            stale_timeout: self.stale_timeout,
            local_player: Arc::clone(&self.local_player),
            party_members: Arc::clone(&self.party_members),
            current_map_id: Arc::clone(&self.current_map_id),
        }
    }
}

/// Extract position from Albion event
/// Returns Some((x, y, z)) if event is a movement event with position data
pub fn extract_position_from_event(
    event_code: u8,
    parameters: &std::collections::HashMap<u8, crate::photon::types::PhotonValue>,
) -> Option<(f32, f32, f32)> {
    // Event code 160: Movement
    if event_code != 160 {
        return None;
    }

    // Try to extract X, Y, Z from standard parameter codes
    // Parameter codes vary but typically 1, 2, 3 for X, Y, Z
    fn get_float(
        params: &std::collections::HashMap<u8, crate::photon::types::PhotonValue>,
        key: u8,
    ) -> Option<f32> {
        match params.get(&key) {
            Some(crate::photon::types::PhotonValue::Float(f)) => Some(*f),
            Some(crate::photon::types::PhotonValue::Double(d)) => Some(*d as f32),
            _ => None,
        }
    }

    // Try common parameter codes for X, Y, Z
    let x = get_float(parameters, 1)?;
    let y = get_float(parameters, 2)?;
    let z = get_float(parameters, 3)?;

    Some((x, y, z))
}

/// Extract entity ID from Albion event
pub fn extract_entity_id(
    parameters: &std::collections::HashMap<u8, crate::photon::types::PhotonValue>,
) -> Option<u32> {
    match parameters.get(&0) {
        Some(crate::photon::types::PhotonValue::Int(id)) => Some(*id),
        Some(crate::photon::types::PhotonValue::Long(id)) => Some(*id as u32),
        _ => None,
    }
}
