//! tui/mod.rs — Terminal UI using ratatui

use anyhow::Result;
use crossterm::{
    event::{self, Event, KeyCode},
    execute,
    terminal::{disable_raw_mode, enable_raw_mode, EnterAlternateScreen, LeaveAlternateScreen},
};
use ratatui::{
    backend::CrosstermBackend,
    layout::{Alignment, Constraint, Direction, Layout},
    style::{Color, Modifier, Style},
    text::{Line, Span},
    widgets::{Block, Borders, Gauge, List, ListItem, Paragraph},
    Terminal,
};
use std::sync::Arc;
use std::sync::atomic::{AtomicU64, Ordering};
use std::time::{Duration, Instant};

pub struct TuiState {
    pub packets_processed: Arc<AtomicU64>,
    pub packets_errors: Arc<AtomicU64>,
    pub bytes_received: Arc<AtomicU64>,
    pub last_update: Instant,
    pub packets_per_sec: u64,
    pub tracker: crate::entities::EntityTracker,
}

impl TuiState {
    pub fn new(
        packets_processed: Arc<AtomicU64>,
        packets_errors: Arc<AtomicU64>,
        bytes_received: Arc<AtomicU64>,
        tracker: crate::entities::EntityTracker,
    ) -> Self {
        Self {
            packets_processed,
            packets_errors,
            bytes_received,
            last_update: Instant::now(),
            packets_per_sec: 0,
            tracker,
        }
    }

    pub fn update(&mut self) {
        let now = Instant::now();
        let elapsed = now.duration_since(self.last_update).as_secs_f64();

        if elapsed >= 1.0 {
            let current = self.packets_processed.load(Ordering::Relaxed);
            self.packets_per_sec = (current as f64 / elapsed) as u64;
            self.last_update = now;
        }
    }
}

pub async fn run_tui(state: TuiState) -> Result<()> {
    enable_raw_mode()?;
    let mut stdout = std::io::stdout();
    execute!(stdout, EnterAlternateScreen)?;
    let backend = CrosstermBackend::new(stdout);
    let mut terminal = Terminal::new(backend)?;

    let result = run_app(&mut terminal, state).await;

    disable_raw_mode()?;
    execute!(terminal.backend_mut(), LeaveAlternateScreen)?;
    terminal.show_cursor()?;

    result
}

async fn run_app(terminal: &mut Terminal<CrosstermBackend<std::io::Stdout>>, mut state: TuiState) -> Result<()> {
    loop {
        state.update();
        state.tracker.cleanup_stale();

        let packets_processed = state.packets_processed.load(Ordering::Relaxed);
        let packets_errors = state.packets_errors.load(Ordering::Relaxed);
        let bytes_received = state.bytes_received.load(Ordering::Relaxed);
        let pps = state.packets_per_sec;
        let entity_count = state.tracker.count();

        terminal.draw(|f| {
            let chunks = Layout::default()
                .direction(Direction::Vertical)
                .margin(1)
                .constraints([
                    Constraint::Length(3),
                    Constraint::Length(5),
                    Constraint::Min(10),
                ])
                .split(f.size());

            let title = Paragraph::new(
                Line::from(vec![
                    Span::styled("OpenRadar ", Style::default().fg(Color::Cyan).add_modifier(Modifier::BOLD)),
                    Span::raw("- Albion Online Network Monitor"),
                ])
            )
            .alignment(Alignment::Center)
            .style(Style::default().bg(Color::Black));
            f.render_widget(title, chunks[0]);

            let stats_chunk = chunks[1];
            let stats_chunks = Layout::default()
                .direction(Direction::Horizontal)
                .constraints([Constraint::Percentage(25), Constraint::Percentage(25), Constraint::Percentage(25), Constraint::Percentage(25)])
                .split(stats_chunk);

            let gauge_packets = Gauge::default()
                .block(Block::default().title("Packets").borders(Borders::ALL))
                .gauge_style(Style::default().fg(Color::Green))
                .ratio((packets_processed % 1000) as f64 / 1000.0)
                .label(format!("{}", packets_processed));
            f.render_widget(gauge_packets, stats_chunks[0]);

            let pps_text = Paragraph::new(format!("{} pkt/s", pps))
                .block(Block::default().title("Rate").borders(Borders::ALL))
                .alignment(Alignment::Center)
                .style(Style::default().fg(Color::Yellow));
            f.render_widget(pps_text, stats_chunks[1]);

            let error_color = if packets_errors > 0 { Color::Red } else { Color::Green };
            let error_text = Paragraph::new(format!("{} errors", packets_errors))
                .block(Block::default().title("Errors").borders(Borders::ALL))
                .alignment(Alignment::Center)
                .style(Style::default().fg(error_color));
            f.render_widget(error_text, stats_chunks[2]);

            let entity_text = Paragraph::new(format!("{} entities", entity_count))
                .block(Block::default().title("Tracked").borders(Borders::ALL))
                .alignment(Alignment::Center)
                .style(Style::default().fg(Color::Magenta));
            f.render_widget(entity_text, stats_chunks[3]);

            // Entity list panel
            let all_entities = state.tracker.get_entities();
            let entities: Vec<_> = all_entities.iter().filter(|e| !e.name.is_empty()).cloned().collect();
            let entity_lines: Vec<ListItem> = entities
                .iter()
                .take(15)
                .map(|e| {
                    // ⭐ NEW: Threat indicator based on faction
                    let threat_icon = match e.faction {
                        255 => "⚠️ ",  // Hostile
                        1..=6 => "🚩 ", // Faction
                        _ => "  ",      // Passive
                    };

                    // ⭐ NEW: Combat indicator
                    let combat_indicator = if e.in_combat { "⚔️ " } else { "  " };

                    // ⭐ NEW: Party member indicator
                    let party_indicator = if state.tracker.is_party_member(&e.name) { "🤝 " } else { "  " };

                    // ⭐ NEW: Health bar
                    let health_display = if e.max_health > 0.0 {
                        let hp_percent = (e.current_health / e.max_health * 100.0) as i32;
                        format!("[{}%]", hp_percent)
                    } else {
                        String::new()
                    };

                    // ⭐ NEW: Dead indicator
                    let dead_indicator = if e.is_dead { " 💀" } else { "" };

                    let guild_tag = if !e.guild.is_empty() {
                        format!("[{}]", e.guild)
                    } else {
                        String::new()
                    };
                    let alliance_tag = match &e.alliance {
                        Some(a) if !a.is_empty() => format!("<{}>", a),
                        _ => String::new(),
                    };
                    let tags = if !guild_tag.is_empty() || !alliance_tag.is_empty() {
                        format!("{}{}{} {} {}", threat_icon, combat_indicator, party_indicator, guild_tag, alliance_tag)
                    } else {
                        format!("{}{}{}", threat_icon, combat_indicator, party_indicator)
                    };
                    ListItem::new(format!(
                        "{} {}{}\n    X: {:8.1} Y: {:8.1} Z: {:8.1} Health: {}",
                        tags, e.name, dead_indicator, e.x, e.y, e.z, health_display
                    ))
                })
                .collect();

            if entity_lines.is_empty() {
                let bytes_str = if bytes_received > 1_000_000 {
                    format!("{:.2} MB", bytes_received as f64 / 1_000_000.0)
                } else if bytes_received > 1_000 {
                    format!("{:.2} KB", bytes_received as f64 / 1_000.0)
                } else {
                    format!("{} B", bytes_received)
                };

                let log_text = vec![
                    Line::from(format!("Total bytes received: {}", bytes_str)),
                    Line::from(""),
                    Line::from("Listening on UDP port 5056..."),
                    Line::from("[Press 'q' or ESC to exit]"),
                ];

                let log_widget = Paragraph::new(log_text)
                    .block(Block::default().title("Network Activity").borders(Borders::ALL))
                    .style(Style::default().fg(Color::White));

                f.render_widget(log_widget, chunks[2]);
            } else {
                let entity_list = List::new(entity_lines)
                    .block(Block::default().title("Active Entities (showing first 15)").borders(Borders::ALL))
                    .style(Style::default().fg(Color::Cyan));

                f.render_widget(entity_list, chunks[2]);
            }
        })?;

        if crossterm::event::poll(Duration::from_millis(200))? {
            if let Event::Key(key) = event::read()? {
                if matches!(key.code, KeyCode::Char('q') | KeyCode::Esc) {
                    return Ok(());
                }
            }
        }
    }
}
