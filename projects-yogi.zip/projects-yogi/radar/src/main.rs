//! main.rs — Rust port of albion-openradar main.go
//!
//! Terminal UI application for monitoring Albion Online network traffic.
//! Wires together: capture → photon parser → TUI display

use std::{
    process,
    sync::{
        atomic::{AtomicU64, Ordering},
        Arc,
    },
    time::Duration,
    io::Write,
};
use clap::Parser;
use tokio::{sync::Notify, task};

pub mod photon;
pub mod capture;
pub mod tui;
pub mod overlay;
pub mod window_overlay;
pub mod logger;
pub mod entities;

// Re-export logger functions for convenience
use logger::console::{print_info, print_success, print_warn};

// ── Utility Functions ──────────────────────────────────────────────────────

#[derive(Debug, Clone)]
struct LocalPlayerData {
    character_id: i32,
    username: String,
}

fn extract_u32(val: &photon::PhotonValue) -> u32 {
    match val {
        photon::PhotonValue::Int(i) => *i as u32,
        photon::PhotonValue::Short(s) => *s as u32,
        photon::PhotonValue::Byte(b) => *b as u32,
        photon::PhotonValue::Long(l) => *l as u32,
        _ => 0,
    }
}

fn extract_i32(val: Option<&photon::PhotonValue>) -> Option<i32> {
    match val? {
        photon::PhotonValue::Int(i) => Some(*i as i32),
        photon::PhotonValue::Short(s) => Some(*s as i32),
        photon::PhotonValue::Byte(b) => Some(*b as i32),
        photon::PhotonValue::Long(l) => Some(*l as i32),
        _ => None,
    }
}

fn extract_f32_safe(val: Option<&photon::PhotonValue>) -> Option<f32> {
    match val? {
        photon::PhotonValue::Float(f) => Some(*f),
        photon::PhotonValue::Double(d) => Some(*d as f32),
        photon::PhotonValue::Int(i) => Some(*i as f32),
        photon::PhotonValue::Short(s) => Some(*s as f32),
        photon::PhotonValue::Byte(b) => Some(*b as f32),
        photon::PhotonValue::Long(l) => Some(*l as f32),
        _ => None,
    }
}

fn extract_position(val: Option<&photon::PhotonValue>) -> Option<(f32, f32)> {
    match val? {
        photon::PhotonValue::Array(arr) if arr.len() >= 2 => {
            let x = extract_f32_safe(Some(&arr[0]))?;
            let y = extract_f32_safe(Some(&arr[1]))?;
            Some((x, y))
        }
        _ => None,
    }
}

fn extract_array_last_f32(val: Option<&photon::PhotonValue>) -> Option<f32> {
    match val? {
        photon::PhotonValue::Array(arr) if !arr.is_empty() => {
            extract_f32_safe(Some(arr.last().unwrap()))
        }
        _ => None,
    }
}

fn extract_local_player(
    params: &std::collections::HashMap<u8, photon::PhotonValue>,
) -> Option<LocalPlayerData> {
    // Try multiple keys for username (matching Python: [1, 2, 5])
    let username = [1u8, 2, 5]
        .iter()
        .find_map(|k| {
            params.get(k).and_then(|v| {
                if let photon::PhotonValue::String(s) = v {
                    if s.len() >= 2 && s.len() <= 30 {
                        Some(s.clone())
                    } else {
                        None
                    }
                } else {
                    None
                }
            })
        })?;

    // Try multiple keys for char_id (matching Python: [0, 3])
    let character_id = [0u8, 3]
        .iter()
        .find_map(|k| params.get(k).and_then(|v| extract_i32(Some(v))))?;

    Some(LocalPlayerData {
        character_id,
        username,
    })
}

// ── Build-time constants ──────────────────────────────────────────────────────

const VERSION:    &str = match option_env!("CARGO_PKG_VERSION") {
    Some(v) => v,
    None => "dev",
};
const BUILD_TIME: &str = match option_env!("BUILD_TIME") {
    Some(t) => t,
    None => "unknown",
};

// ── CLI config ────────────────────────────────────────────────────────────────

#[derive(Debug, Parser)]
#[command(name = "openradar", about = "Albion Online radar — network monitor")]
struct Config {
    /// Network adapter IP (skips interactive prompt)
    #[arg(long = "ip", default_value = "")]
    ip_addr: String,

    /// Print version and exit
    #[arg(long = "version")]
    show_version: bool,
}

// ── Shared counters ───────────────────────────────────────────────────────────

struct Counters {
    packets_processed: Arc<AtomicU64>,
    packets_errors:    Arc<AtomicU64>,
    bytes_received:    Arc<AtomicU64>,
}

impl Counters {
    fn new() -> Self {
        Self {
            packets_processed: Arc::new(AtomicU64::new(0)),
            packets_errors:    Arc::new(AtomicU64::new(0)),
            bytes_received:    Arc::new(AtomicU64::new(0)),
        }
    }
}

// ── Application state ─────────────────────────────────────────────────────────

struct App {
    capturer:   Arc<capture::Capturer>,
    counters:   Arc<Counters>,
    adapter_ip: String,
    shutdown:   Arc<Notify>,
    logger:     Arc<logger::Logger>,
    tracker:    entities::EntityTracker,
}

// ── Entry point ───────────────────────────────────────────────────────────────

#[tokio::main]
async fn main() {
    let cfg = Config::parse();

    if cfg.show_version {
        println!("OpenRadar v{VERSION} (built: {BUILD_TIME})");
        return;
    }

    print_banner();

    if let Err(e) = run_app(&cfg).await {
        eprintln!("Error: {e}");
        process::exit(1);
    }
}

// ── One full application lifecycle ────────────────────────────────────────────

async fn run_app(cfg: &Config) -> anyhow::Result<()> {
    let app_dir = std::env::current_dir()
        .unwrap_or_else(|e| exit_with_error("Failed to get working directory", e));

    // Initialize logger first (creates log directory and session file)
    let log = Arc::new(logger::Logger::new(app_dir.join("logs"))?);
    log.print_session_info();

    // Start logger flush loop in background
    {
        let log_clone = Arc::clone(&log);
        tokio::spawn(async move {
            log_clone.start_flush_loop().await;
        });
    }

    // Build capturer (may prompt for adapter selection)
    let mut capturer = capture::Capturer::new(&app_dir, &cfg.ip_addr)
        .await
        .unwrap_or_else(|e| exit_with_error("Failed to create capturer", e));

    let adapter_ip = capturer.adapter_ip().to_owned();
    let counters = Arc::new(Counters::new());
    let shutdown = Arc::new(Notify::new());
    let tracker = entities::EntityTracker::new(Duration::from_secs(300));

    // Register packet callback
    {
        let pkt_counter = Arc::clone(&counters.packets_processed);
        let err_counter = Arc::clone(&counters.packets_errors);
        let bytes_counter = Arc::clone(&counters.bytes_received);
        let tracker_clone = tracker.clone();
        let log_clone = Arc::clone(&log);

        capturer.on_packet(move |payload| {
            // DEBUG EVERY OUTGOING PACKET RAW
            if payload.len() >= 4 { // IP/UDP payload starts with ports
                // wait, the payload passed here is JUST UDP payload.
                // In main.rs, capturer.on_packet(move |payload|) receives the inner UDP payload!
                // But wait! extract_udp_payload filters to ALBION_PORT. We don't know if it's incoming or outgoing just from `payload`.
                // Actually, let's just log ALL parsed Commands that aren't Events!
            }

            match photon::parse_packet(payload) {
                Ok(Some(packet)) => {
                    pkt_counter.fetch_add(1, Ordering::Relaxed);

                    // Extract events and track player positions
                    for cmd in &packet.commands {
                        // LOG OUTGOING PACKETS (which are typically requests or unreliable)
                        if !cmd.is_event() && !cmd.is_response() {
                            if let Ok(mut file) = std::fs::OpenOptions::new().create(true).append(true).open("/tmp/openradar_outgoing.log") {
                                let len = cmd.payload.as_ref().map_or(0, |p| p.data.len());
                                let _ = writeln!(file, "COMMAND -> type: {}, msg_type: {}, len: {}", cmd.command_type, cmd.message_type, len);
                            }
                        }
                        // === PHASE 2: Operation handlers (OP_JOIN, OP_CHANGE_CLUSTER, REQUEST_MOVE) ===
                        if !cmd.is_event() {
                            if let Some(ref cmd_payload) = cmd.payload {
                                if cmd.is_response() {
                                    if let Ok(response) = photon::deserialize_response(&cmd_payload.data) {
                                        let opcode = response.operation_code as i32;
                                        
                                        match opcode {
                                            1 => { // OP_JOIN / OP_CHANGE_CLUSTER (Albion moved these to Opcode 1)
                                                // Sub-type 322: Map ID is in parameter 0
                                                if let Some(photon::PhotonValue::Int(322)) = response.parameters.get(&255) {
                                                    if let Some(photon::PhotonValue::String(cluster_id)) = response.parameters.get(&0) {
                                                        tracker_clone.clear_zone();
                                                        tracker_clone.set_map_id(cluster_id.clone());
                                                        log_clone.info("OOP", &format!("🗺️ MAP ID SET TO (from 322): {}", cluster_id), None);
                                                    }
                                                } 
                                                // The huge join packet has Player Name in 2, Player ID in 0, and Map ID in 8
                                                else if let Some(photon::PhotonValue::String(player_name)) = response.parameters.get(&2) {
                                                    if let Some(photon::PhotonValue::String(cluster_id)) = response.parameters.get(&8) {
                                                        tracker_clone.clear_zone();
                                                        tracker_clone.set_map_id(cluster_id.clone());
                                                        log_clone.info("OOP", &format!("🗺️ MAP ID SET TO (from join): {}", cluster_id), None);
                                                    }
                                                    if let Some(photon::PhotonValue::Int(player_id)) = response.parameters.get(&0) {
                                                        tracker_clone.set_local_player(*player_id as u32, player_name.clone());
                                                        print_success("OOP", &format!("🎮 LOCAL PLAYER AUTH: {} (ID: {})", player_name, player_id));
                                                    }
                                                }
                                            }
                                            2 => {  // Legacy OP_JOIN fallback
                                                if let Some(local_player) = extract_local_player(&response.parameters) {
                                                    tracker_clone.set_local_player(local_player.character_id as u32, local_player.username.clone());
                                                }
                                            }
                                            4 => {  // Legacy OP_CHANGE_CLUSTER fallback
                                                tracker_clone.clear_zone();
                                                if let Some(photon::PhotonValue::String(cluster_id)) = response.parameters.get(&0) {
                                                    tracker_clone.set_map_id(cluster_id.clone());
                                                }
                                            }
                                            _ => {}
                                        }
                                    }
                                } else if cmd.is_request() {
                                    if let Ok(request) = photon::deserialize_request(&cmd_payload.data) {
                                        let mut opcode = request.operation_code as i32;
                                        
                                        // Albion Online encapsulates the real Opcode inside Parameter 253 to evade simple packet inspection.
                                        if let Some(real_op) = request.parameters.get(&253) {
                                            match real_op {
                                                photon::PhotonValue::Short(v) => opcode = *v as i32,
                                                photon::PhotonValue::Byte(v) => opcode = *v as i32,
                                                photon::PhotonValue::Int(v) => opcode = *v as i32,
                                                _ => {}
                                            }
                                        }

                                        match opcode {
                                            21 => { // Request_Move (Local Player continuous movement)
                                                if let Some(pos_val) = request.parameters.get(&1) {
                                                    if let photon::PhotonValue::ByteArray(arr) = pos_val {
                                                        if arr.len() >= 8 {
                                                            let mut x_bytes = [0u8; 4];
                                                            let mut y_bytes = [0u8; 4];
                                                            x_bytes.copy_from_slice(&arr[0..4]);
                                                            y_bytes.copy_from_slice(&arr[4..8]);
                                                            tracker_clone.update_local_player_position(
                                                                f32::from_le_bytes(x_bytes),
                                                                f32::from_le_bytes(y_bytes)
                                                            );
                                                        }
                                                    } else if let photon::PhotonValue::Array(arr) = pos_val {
                                                        if arr.len() >= 2 {
                                                            if let (photon::PhotonValue::Float(x), photon::PhotonValue::Float(y)) = (&arr[0], &arr[1]) {
                                                                tracker_clone.update_local_player_position(*x, *y);
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                            _ => {}
                                        }
                                    }
                                }
                            }
                            continue;
                        }

                        if let Some(ref cmd_payload) = cmd.payload {
                            // Deserialize event from payload
                            match photon::deserialize_event(&cmd_payload.data) {
                                Ok(event) => {
                                    // Extract real Albion event type from params[252]
                                    let albion_event_type: i32 = if let Some(photon::PhotonValue::Short(et)) = event.parameters.get(&252) {
                                        *et as i32
                                    } else if let Some(photon::PhotonValue::Byte(et)) = event.parameters.get(&252) {
                                        *et as i32
                                    } else if let Some(photon::PhotonValue::Int(et)) = event.parameters.get(&252) {
                                        *et as i32
                                    } else {
                                        -1_i32
                                    };

                                    // Extract entity ID from parameter 0
                                    let entity_id = if let Some(photon::PhotonValue::Int(id)) = event.parameters.get(&0) {
                                        *id as u32
                                    } else if let Some(photon::PhotonValue::Byte(id)) = event.parameters.get(&0) {
                                        *id as u32
                                    } else if let Some(photon::PhotonValue::Long(id)) = event.parameters.get(&0) {
                                        *id as u32
                                    } else if let Some(photon::PhotonValue::Short(id)) = event.parameters.get(&0) {
                                        *id as u32
                                    } else {
                                        0
                                    };

                                    match albion_event_type {
                                        // Event 3 = Move (position update)
                                        3 => {
                                            if entity_id == 0 {
                                                continue;
                                            }

                                            let mut z = 0.0;

                                            // Universal f32 casting heuristic
                                            let extract_f32 = |v: &photon::PhotonValue| -> f32 {
                                                match v {
                                                    photon::PhotonValue::Float(f) => *f,
                                                    photon::PhotonValue::Double(d) => *d as f32,
                                                    photon::PhotonValue::Int(i) => *i as f32,
                                                    photon::PhotonValue::Short(s) => *s as f32,
                                                    photon::PhotonValue::Byte(b) => *b as f32,
                                                    photon::PhotonValue::Long(l) => *l as f32,
                                                    _ => 0.0,
                                                }
                                            };

                                            let ox = event.parameters.get(&4).map(|v| extract_f32(v)).unwrap_or(0.0);
                                            let oy = event.parameters.get(&5).map(|v| extract_f32(v)).unwrap_or(0.0);
                                            
                                            // Reject only when BOTH coords are exactly 0.0 — that signals
                                            // the packet simply didn't carry position data.
                                            // Individual zero components are valid map coords.
                                            let is_valid_pair = |x: f32, y: f32| -> bool {
                                                x.is_finite() && y.is_finite()
                                                && x.abs() < 50_000.0 && y.abs() < 50_000.0
                                                && !(x == 0.0 && y == 0.0)
                                            };

                                            let mut best_x = None;
                                            let mut best_y = None;

                                            // Attempt 1: Are Parameters 4 & 5 valid unencrypted coords?
                                            if is_valid_pair(ox, oy) {
                                                best_x = Some(ox);
                                                best_y = Some(oy);
                                            }

                                            // Attempt 2: Unpack from ByteArray (mobs/resources)
                                            if best_x.is_none() {
                                                if let Some(photon::PhotonValue::ByteArray(arr)) = event.parameters.get(&1) {
                                                    if arr.len() >= 17 {
                                                        let mut xb = [0u8; 4];
                                                        let mut yb = [0u8; 4];
                                                        xb.copy_from_slice(&arr[9..13]);
                                                        yb.copy_from_slice(&arr[13..17]);
                                                        let bx = f32::from_le_bytes(xb);
                                                        let by = f32::from_le_bytes(yb);
                                                        if is_valid_pair(bx, by) {
                                                            best_x = Some(bx);
                                                            best_y = Some(by);
                                                        }
                                                    }
                                                }
                                            }

                                            // Fallback to updating only if coordinates survived the physical heuristic verification
                                            // This prevents Albion's stream encryption keys from wiping currently tracked valid entities off the UI
                                            if let (Some(final_x), Some(final_y)) = (best_x, best_y) {
                                                tracker_clone.update_position(entity_id, final_x, final_y, z);
                                            }
                                        }
                                        // Event 4 = Teleport — captures the actual position for static/AFK players
                                        4 => {
                                            if entity_id == 0 { continue; }
                                            let is_valid_coord = |val: f32| -> bool {
                                                val.is_finite() && val.abs() < 50_000.0
                                            };
                                            let ox = event.parameters.get(&4).and_then(|v| match v {
                                                photon::PhotonValue::Float(f) => Some(*f),
                                                _ => None,
                                            }).unwrap_or(f32::NAN);
                                            let oy = event.parameters.get(&5).and_then(|v| match v {
                                                photon::PhotonValue::Float(f) => Some(*f),
                                                _ => None,
                                            }).unwrap_or(f32::NAN);
                                            if is_valid_coord(ox) && is_valid_coord(oy) {
                                                tracker_clone.update_position(entity_id, ox, oy, 0.0);
                                            }
                                        }
                                        // Event 29 = NewCharacter (player joins zone)
                                        29 => {
                                            // Only track players with both valid ID and actual name
                                            if entity_id == 0 {
                                                continue;
                                            }

                                            // Extract actual name (not fallback) — skip if name is missing
                                            let name = if let Some(photon::PhotonValue::String(n)) = event.parameters.get(&1) {
                                                n.clone()
                                            } else if let Some(photon::PhotonValue::ByteArray(ba)) = event.parameters.get(&1) {
                                                String::from_utf8_lossy(ba).to_string()
                                            } else {
                                                // No actual name found — skip this event
                                                continue;
                                            };

                                            // Skip if name is empty after extraction
                                            if name.is_empty() {
                                                continue;
                                            }

                                            let guild = if let Some(photon::PhotonValue::String(g)) = event.parameters.get(&8) {
                                                g.clone()
                                            } else {
                                                String::new()
                                            };

                                            let alliance = if let Some(photon::PhotonValue::String(a)) = event.parameters.get(&51) {
                                                Some(a.clone())
                                            } else {
                                                None
                                            };

                                            // NEW: Faction (0=passive, 1-6=faction, 255=hostile)
                                            let faction: i32 = extract_i32(event.parameters.get(&53))
                                                .unwrap_or(0);

                                            // NEW: Max Health (initial)
                                            let max_health = extract_f32_safe(event.parameters.get(&22))
                                                .unwrap_or(0.0);

                                            // NEW: Equipment IDs (param 40 = array of item IDs)
                                            let mut equipment_ids = Vec::new();
                                            if let Some(photon::PhotonValue::IntArray(arr)) = event.parameters.get(&40) {
                                                equipment_ids = arr.iter().map(|x| *x as i32).collect();
                                            } else if let Some(photon::PhotonValue::Array(arr)) = event.parameters.get(&40) {
                                                for item in arr {
                                                    if let Some(id) = extract_i32(Some(item)) {
                                                        equipment_ids.push(id);
                                                    }
                                                }
                                            }

                                            // Format display with proper tags
                                            let display = match (guild.is_empty(), alliance.is_none()) {
                                                (false, false) => format!("[{}] <{}> {}", guild, alliance.as_ref().unwrap_or(&String::new()), name),
                                                (false, true) => format!("[{}] {}", guild, name),
                                                (true, false) => format!("<{}> {}", alliance.as_ref().unwrap_or(&String::new()), name),
                                                (true, true) => name.clone(),
                                            };

                                            // Add threat indicator based on faction
                                            let threat_indicator = match faction {
                                                255 => "⚠️",
                                                1..=6 => "🚩",
                                                _ => "✨",
                                            };

                                            // Update tracker with full data
                                            tracker_clone.update_entity(
                                                entity_id,
                                                999999.0, 999999.0, 0.0,  // Initial position mathematically voided to prevent (0,0) clumps globally
                                                name.clone(),
                                                guild.clone(),
                                                alliance.clone(),
                                                faction,
                                                max_health,
                                                equipment_ids,
                                            );

                                            print_success("PLY", &format!("{} NEW PLAYER: {} (ID: {})", threat_indicator, display, entity_id));
                                            let alliance_str = alliance.as_ref().map(|a| a.clone()).unwrap_or_default();
                                            log_clone.info("PKT", &format!("NewCharacter(29): ID={} Name='{}' Guild='{}' Alliance='{}' Faction={}",
                                                entity_id, name, guild, alliance_str, faction), None);
                                        }
                                        // Event 1 = Leave (player exits zone) ⭐
                                        1 => {
                                            if entity_id > 0 {
                                                tracker_clone.remove_entity(entity_id);
                                                log_clone.debug("PKT", &format!("👋 CharacterLeft(1): ID={}", entity_id), None);
                                            }
                                        }
                                        // Event 6 = Health Update (single damage/heal) ⭐
                                        6 => {
                                            if let Some(current_health) = extract_f32_safe(event.parameters.get(&2)) {
                                                tracker_clone.update_health(entity_id, Some(current_health), None);
                                                if current_health <= 0.0 {
                                                    log_clone.debug("PKT", &format!("💀 PlayerDead(6): ID={}", entity_id), None);
                                                }
                                            }
                                        }
                                        // Event 7 = Health Updates (batch - multiple targets) ⭐
                                        7 => {
                                            if let Some(max_health) = extract_f32_safe(event.parameters.get(&3)) {
                                                if let Some(current_health) = extract_array_last_f32(event.parameters.get(&2)) {
                                                    tracker_clone.update_health(entity_id, Some(current_health), Some(max_health));
                                                    if current_health <= 0.0 {
                                                        log_clone.debug("PKT", &format!("💀 PlayerDead(7-batch): ID={}", entity_id), None);
                                                    }
                                                }
                                            }
                                        }
                                        // Event 273 = In Combat State Update ⭐
                                        273 => {
                                            let in_combat = event.parameters.contains_key(&1);
                                            tracker_clone.update_combat_state(entity_id, in_combat);
                                            let state_str = if in_combat { "COMBAT" } else { "IDLE" };
                                            log_clone.debug("PKT", &format!("⚔️ CombatState(273): ID={} State={}", entity_id, state_str), None);
                                        }
                                        // Event 483 = Position Update (alternative format) ⭐
                                        483 => {
                                            if let Some((x, y)) = extract_position(event.parameters.get(&1)) {
                                                // Prevent coordinate wipeouts due to obfuscation
                                                let is_valid_coord = |val: f32| -> bool {
                                                    val.is_finite() && val.abs() < 100_000.0 && val != 0.0
                                                };
                                                
                                                if is_valid_coord(x) && is_valid_coord(y) {
                                                    tracker_clone.update_position(entity_id, x, y, 0.0);
                                                    log_clone.debug("PKT", &format!("Move(483): ID={} X={:.2} Y={:.2}", entity_id, x, y), None);
                                                }
                                            }
                                        }
                                        // Event 229 = Party Joined ⭐ NEW
                                        229 => {
                                            // params[6] = array of member names
                                            if let Some(members_val) = event.parameters.get(&6) {
                                                let mut members = Vec::new();
                                                match members_val {
                                                    photon::PhotonValue::StringArray(arr) => members = arr.clone(),
                                                    photon::PhotonValue::Array(arr) => {
                                                        for v in arr {
                                                            if let photon::PhotonValue::String(s) = v {
                                                                members.push(s.clone());
                                                            }
                                                        }
                                                    }
                                                    _ => {}
                                                }
                                                if !members.is_empty() {
                                                    tracker_clone.set_party_members(members.clone());
                                                    // Add self to party (from local player)
                                                    if let Some(me) = tracker_clone.get_local_player() {
                                                        tracker_clone.add_party_member(me.name.clone());
                                                    }
                                                    log_clone.info("PKT", &format!("👥 PartyJoined(229): {} members - {}", members.len(), members.join(", ")), None);
                                                    print_info("PLY", &format!("👥 PARTY JOINED: {} members", members.len()));
                                                }
                                            }
                                        }
                                        // Event 231 = Party Player Joined ⭐ NEW
                                        231 => {
                                            if let Some(photon::PhotonValue::String(username)) = event.parameters.get(&2) {
                                                tracker_clone.add_party_member(username.clone());
                                                log_clone.info("PKT", &format!("👥 PartyPlayerJoined(231): {}", username), None);
                                                print_info("PLY", &format!("👥 {} JOINED PARTY", username));
                                            }
                                        }
                                        // Event 233 = Party Player Left ⭐ NEW
                                        233 => {
                                            if let Some(photon::PhotonValue::String(username)) = event.parameters.get(&2) {
                                                tracker_clone.remove_party_member(username);
                                                log_clone.info("PKT", &format!("👥 PartyPlayerLeft(233): {}", username), None);
                                                print_info("PLY", &format!("👥 {} LEFT PARTY", username));
                                            }
                                        }
                                        // Event 230 = Party Disbanded ⭐ NEW
                                        230 => {
                                            tracker_clone.clear_party();
                                            log_clone.info("PKT", "👥 PartyDisbanded(230): Party cleared", None);
                                            print_info("PLY", "👥 PARTY DISBANDED");
                                        }
                                        // Other known events - log but don't spam
                                        other => {
                                            static LOGGED_EVENTS: std::sync::atomic::AtomicU32 = std::sync::atomic::AtomicU32::new(0);
                                            let count = LOGGED_EVENTS.fetch_add(1, Ordering::Relaxed);

                                            // Only log first occurrence of each event type
                                            match other {
                                                6 | 7 | 19 | 273 => {
                                                    // Common events - log sparingly
                                                    if count < 100 {
                                                        log_clone.debug("PKT", &format!("Event({}): ID={}", other, entity_id), None);
                                                    }
                                                }
                                                _ => {
                                                    // Rare events - log always
                                                    log_clone.info("PKT", &format!("Event({}): ID={} [Unknown event type]", other, entity_id), None);
                                                }
                                            }
                                        }
                                    }
                                }
                                Err(e) => {
                                    // Log deserialization errors for debugging
                                    log_clone.debug("PKT", &format!("Deserialization error: {}", e), None);
                                }
                            }
                        }
                    }
                }
                Ok(None) => {},
                Err(e) => {
                    let n = err_counter.fetch_add(1, Ordering::Relaxed) + 1;
                    if n % 100 == 1 {
                        print_warn("PKT", &format!("Parsing errors: {n} (latest: {e})"));
                    }
                }
            }
            bytes_counter.fetch_add(payload.len() as u64, Ordering::Relaxed);
        });
    }

    let capturer = Arc::new(capturer);

    let app = Arc::new(App {
        capturer: Arc::clone(&capturer),
        counters: Arc::clone(&counters),
        adapter_ip: adapter_ip.clone(),
        shutdown: Arc::clone(&shutdown),
        logger: Arc::clone(&log),
        tracker: tracker.clone(),
    });

    // ── Start background tasks ────────────────────────────────────────────────
    {
        let a = Arc::clone(&app);
        a.start_capture_thread();
    }

    // ── Start TUI ──────────────────────────────────────────────────────────────
    print_success("APP", &format!("Starting OpenRadar v{VERSION}"));
    print_info("NET", &format!("Adapter: {}", app.adapter_ip));
    print_info("PKT", "Listening for Albion packets on UDP port 5056...");

    // ── UI Selection Menu ──────────────────────────────────────────────────────
    println!("\n╔═══════════════════════════════════════╗");
    println!("║       OpenRadar - Select UI Mode      ║");
    println!("╔═══════════════════════════════════════╗");
    println!("║       OpenRadar - Select UI Mode      ║");
    println!("╠═══════════════════════════════════════╣");
    println!("║  1. TUI (Table view - terminal)       ║");
    println!("║  2. Terminal Overlay (map + list)     ║");
    println!("║  3. Window Overlay (floating window)  ║");
    println!("║  4. TUI + Window Overlay              ║");
    println!("╚═══════════════════════════════════════╝");
    println!("\nEnter choice (1-4, default: 1): ");

    let mut choice = String::new();
    std::io::stdin().read_line(&mut choice).ok();
    let choice = choice.trim().parse::<u32>().unwrap_or(1);

    // Set silent callback for UI mode
    logger::set_log_callback(Box::new(|_level, _tag, _msg| {
        // Silent mode - logs only written to file, not stdout
    }));

    // Run selected UI
    match choice {
        2 => {
            // Terminal Overlay mode
            let overlay_state = overlay::OverlayState::new(
                Arc::clone(&counters.packets_processed),
                Arc::clone(&counters.packets_errors),
                Arc::clone(&counters.bytes_received),
                tracker.clone(),
            );
            if let Err(e) = overlay::run_overlay(overlay_state).await {
                eprintln!("Overlay error: {e}");
            }
        }
        3 => {
            // Window Overlay mode
            let window_state = window_overlay::WindowOverlayApp::new(
                Arc::clone(&counters.packets_processed),
                Arc::clone(&counters.packets_errors),
                Arc::clone(&counters.bytes_received),
                tracker.clone(),
            );
            if let Err(e) = window_overlay::run_window_overlay(window_state) {
                eprintln!("Window overlay error: {e}");
            }
        }
        4 => {
            // TUI + Window Overlay
            let tui_state = tui::TuiState::new(
                Arc::clone(&counters.packets_processed),
                Arc::clone(&counters.packets_errors),
                Arc::clone(&counters.bytes_received),
                tracker.clone(),
            );
            
            let window_state = window_overlay::WindowOverlayApp::new(
                Arc::clone(&counters.packets_processed),
                Arc::clone(&counters.packets_errors),
                Arc::clone(&counters.bytes_received),
                tracker.clone(),
            );
            
            // Spawn TUI in a dedicated background OS thread
            std::thread::spawn(move || {
                let rt = tokio::runtime::Builder::new_current_thread().enable_all().build().unwrap();
                if let Err(e) = rt.block_on(tui::run_tui(tui_state)) {
                    eprintln!("TUI error: {e}");
                }
            });
            
            // Run egui on the main thread
            if let Err(e) = window_overlay::run_window_overlay(window_state) {
                eprintln!("Window overlay error: {e}");
            }
        }
        _ => {
            // TUI mode (default)
            let tui_state = tui::TuiState::new(
                Arc::clone(&counters.packets_processed),
                Arc::clone(&counters.packets_errors),
                Arc::clone(&counters.bytes_received),
                tracker.clone(),
            );
            if let Err(e) = tui::run_tui(tui_state).await {
                eprintln!("TUI error: {e}");
            }
        }
    }

    // ── Graceful shutdown ──────────────────────────────────────────────────────
    // Clear silent callback to show shutdown messages
    logger::clear_log_callback();
    app.shutdown().await;

    // Flush logger and wait for async writes
    log.flush();
    tokio::time::sleep(tokio::time::Duration::from_millis(500)).await;

    Ok(())
}

// ── App methods ────────────────────────────────────────────────────────────────

impl App {
    fn start_capture_thread(self: &Arc<Self>) {
        let cap = Arc::clone(&self.capturer);
        let shutdown = Arc::clone(&self.shutdown);

        std::thread::spawn(move || {
            if let Err(e) = cap.start_blocking() {
                logger::print_error("CAP", &format!("Capture error: {}", e));
            }
            shutdown.notify_waiters();
        });
    }

    async fn shutdown(&self) {
        logger::print_info("APP", "Shutting down gracefully...");
        self.shutdown.notify_waiters();
        self.capturer.close().await;
        logger::print_success("APP", "Shutdown complete");
    }
}

// ── Utilities ──────────────────────────────────────────────────────────────────

fn print_banner() {
    println!();
    println!("╔═══════════════════════════════════════╗");
    println!("║       OpenRadar v{:<23} ║", VERSION);
    println!("║     Albion Online Network Monitor     ║");
    println!("╚═══════════════════════════════════════╝");
    println!();
}

fn exit_with_error<E: std::fmt::Display>(msg: &str, err: E) -> ! {
    eprintln!("{msg}: {err}");
    process::exit(1);
}
