//! capture/reader.rs - stub placeholder
