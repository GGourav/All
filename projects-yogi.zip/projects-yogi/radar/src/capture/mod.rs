//! capture/mod.rs
//!
//! Network packet capture — complete port of pcap.go.
//!
//! Uses the `pcap` crate (wraps libpcap).
//! Requires `libpcap-dev` (Debian/Ubuntu) or `libpcap-devel` (Fedora/RHEL).

pub mod reader;
pub mod types;
pub mod command;
pub mod packet;
pub mod protocol16;

use std::{
    fs,
    io::{self, BufRead, Write},
    net::IpAddr,
    path::Path,
    str::FromStr,
    sync::{
        atomic::{AtomicU64, Ordering},
        Arc,
    },
};

use anyhow::{bail, Context, Result};
use pcap::{Capture, Device, Packet};
use tokio::{sync::watch, task};

const ALBION_PORT: u16  = 5056;
const SNAP_LEN:    i32  = 65_536;
const PROMISCUOUS: bool = false;

/// Called for every captured UDP payload.
pub type PacketHandler = Arc<dyn Fn(&[u8]) + Send + Sync + 'static>;

/// Describes a network interface candidate.
#[derive(Debug, Clone)]
pub struct NetworkInterface {
    pub name:    String, // human-readable description
    pub address: String, // IPv4 string
    pub device:  String, // OS device name (e.g. "eth0", "\\Device\\...")
}

// ── Capturer ──────────────────────────────────────────────────────────────────

pub struct Capturer {
    device:         String,
    adapter_ip:     String,
    on_packet:      Option<PacketHandler>,
    bytes_received: Arc<AtomicU64>,
    /// Sending `true` on this channel stops the capture loop.
    stop_tx:        watch::Sender<bool>,
    stop_rx:        watch::Receiver<bool>,
}

impl Capturer {
    /// Create a new capturer.
    ///
    /// `ip_override` — if non-empty and a valid IP, skip interactive prompt.
    /// `app_dir`     — directory where `ip.txt` is stored / read.
    pub async fn new(app_dir: &Path, ip_override: &str) -> Result<Self> {
        // Run the blocking adapter-selection prompt on a thread-pool thread
        // so we don't stall the async runtime.
        let app_dir_owned = app_dir.to_path_buf();
        let ip_override   = ip_override.to_string();

        let (adapter_ip, device) = task::spawn_blocking(move || {
            resolve_adapter(&app_dir_owned, &ip_override)
        })
        .await
        .context("adapter resolution thread panicked")??;

        let (stop_tx, stop_rx) = watch::channel(false);

        Ok(Self {
            device,
            adapter_ip,
            on_packet:      None,
            bytes_received: Arc::new(AtomicU64::new(0)),
            stop_tx,
            stop_rx,
        })
    }

    /// Register the callback invoked for every captured UDP payload.
    pub fn on_packet<F>(&mut self, handler: F)
    where
        F: Fn(&[u8]) + Send + Sync + 'static,
    {
        self.on_packet = Some(Arc::new(handler));
    }

    /// Begin capturing packets.  Blocking — run inside `spawn_blocking`.
    ///
    /// Returns when the stop signal is sent or a fatal error occurs.
    pub fn start_blocking(&self) -> Result<()> {
        let mut cap = open_device(&self.device)?;
        let handler       = self.on_packet.clone();
        let bytes_counter = Arc::clone(&self.bytes_received);
        let stop_rx   = self.stop_rx.clone();

        loop {
            // Check for stop signal (non-blocking)
            if *stop_rx.borrow() {
                return Ok(());
            }

            match cap.next_packet() {
                Ok(packet) => {
                    if let Some(payload) = extract_udp_payload(&packet) {
                        bytes_counter.fetch_add(payload.len() as u64, Ordering::Relaxed);
                        if let Some(h) = &handler {
                            h(payload);
                        }
                    }
                }
                Err(pcap::Error::TimeoutExpired) => continue,
                Err(e) => bail!("pcap error: {e}"),
            }
        }
    }

    /// Signal the capture loop to stop.
    pub async fn close(&self) {
        let _ = self.stop_tx.send(true);
    }

    pub fn adapter_ip(&self) -> &str {
        &self.adapter_ip
    }

    pub fn bytes_received(&self) -> u64 {
        self.bytes_received.load(Ordering::Relaxed)
    }

    pub fn bytes_received_arc(&self) -> Arc<AtomicU64> {
        Arc::clone(&self.bytes_received)
    }
}

// ── UDP payload extraction ────────────────────────────────────────────────────

/// Extract the UDP payload from a raw packet, filtering to Albion's port.
///
/// We do a minimal manual parse instead of pulling in `pnet` just for this.
fn extract_udp_payload<'a>(packet: &'a Packet<'a>) -> Option<&'a [u8]> {
    let data = packet.data;

    if data.len() < 14 {
        return None;
    }
    let ethertype = u16::from_be_bytes([data[12], data[13]]);

    let (ip_payload, protocol) = if ethertype == 0x0800 {
        // IPv4
        if data.len() < 14 + 20 { return None; }
        let ihl = (data[14] & 0x0F) as usize * 4;
        let protocol = data[14 + 9];
        (&data[14 + ihl..], protocol)
    } else if ethertype == 0x86dd {
        // IPv6
        if data.len() < 14 + 40 { return None; }
        let next_header = data[14 + 6]; // In basic IPv6, next_header is protocol
        (&data[14 + 40..], next_header)
    } else {
        return None;
    };

    if protocol != 17 || ip_payload.len() < 8 {
        return None;
    }

    let src_port = u16::from_be_bytes([ip_payload[0], ip_payload[1]]);
    let dst_port = u16::from_be_bytes([ip_payload[2], ip_payload[3]]);

    if src_port != ALBION_PORT && dst_port != ALBION_PORT {
        return None;
    }

    let udp_payload = &ip_payload[8..];
    if udp_payload.is_empty() {
        return None;
    }

    Some(udp_payload)
}

// ── Device opening ────────────────────────────────────────────────────────────

fn open_device(device: &str) -> Result<Capture<pcap::Active>> {
    let mut cap = Capture::from_device(device)
        .context("device not found")?
        .snaplen(SNAP_LEN)
        .promisc(PROMISCUOUS)
        .timeout(100) // 100 ms — lets us poll stop_rx regularly
        .open()
        .context("failed to open pcap device")?;

    let filter = format!("udp and port {ALBION_PORT}");
    cap.filter(&filter, true)
        .context("failed to set BPF filter")?;

    Ok(cap)
}

// ── Adapter resolution ────────────────────────────────────────────────────────

/// Full port of Go's `resolveAdapter` with the same retry / fallback logic.
fn resolve_adapter(app_dir: &Path, ip_override: &str) -> Result<(String, String)> {
    let ip = get_adapter_ip(app_dir, ip_override)?;

    match find_device_by_ip(&ip) {
        Ok(device) => {
            println!("Using adapter IP: {ip}");
            return Ok((ip, device));
        }
        Err(_) if ip_override.is_empty() => {
            // No override — let the user pick a different adapter
            println!("Adapter with IP {ip} not found. Please select a new adapter.");
            let new_ip = prompt_for_interface(app_dir)?;
            let device = find_device_by_ip(&new_ip)
                .with_context(|| format!("adapter with IP {new_ip} not found after selection"))?;
            println!("Using adapter IP: {new_ip}");
            Ok((new_ip, device))
        }
        Err(_) => {
            bail!("adapter with IP {ip} not found");
        }
    }
}

/// Priority: CLI override → ip.txt → interactive prompt.
fn get_adapter_ip(app_dir: &Path, ip_override: &str) -> Result<String> {
    if let Some(ip) = try_ip_override(ip_override) {
        return Ok(ip);
    }
    if let Some(ip) = try_ip_file(app_dir) {
        return Ok(ip);
    }
    prompt_for_interface(app_dir)
}

fn try_ip_override(ip_override: &str) -> Option<String> {
    if ip_override.is_empty() {
        return None;
    }
    IpAddr::from_str(ip_override).ok()?;
    println!("Using IP from command line: {ip_override}");
    Some(ip_override.to_string())
}

fn try_ip_file(app_dir: &Path) -> Option<String> {
    let path = app_dir.join("ip.txt");
    let content = fs::read_to_string(path).ok()?;
    let ip = content.trim().to_string();
    IpAddr::from_str(&ip).ok()?;
    Some(ip)
}

fn prompt_for_interface(app_dir: &Path) -> Result<String> {
    let interfaces = list_interfaces()?;
    if interfaces.is_empty() {
        bail!("no network interfaces found");
    }

    print_interfaces(&interfaces);
    select_interface(&interfaces, app_dir)
}

fn list_interfaces() -> Result<Vec<NetworkInterface>> {
    let devices = Device::list().context("failed to list pcap devices")?;
    let mut out = Vec::new();

    for dev in devices {
        for addr in &dev.addresses {
            if let IpAddr::V4(v4) = addr.addr {
                out.push(NetworkInterface {
                    name:    dev.desc.clone().unwrap_or_else(|| dev.name.clone()),
                    address: v4.to_string(),
                    device:  dev.name.clone(),
                });
                break; // one entry per device (first IPv4 address)
            }
        }
    }

    Ok(out)
}

fn find_device_by_ip(ip: &str) -> Result<String> {
    let devices = Device::list().context("failed to list pcap devices")?;
    for dev in devices {
        for addr in &dev.addresses {
            if addr.addr.to_string() == ip {
                return Ok(dev.name.clone());
            }
        }
    }
    bail!("no device found with IP: {ip}")
}

fn print_interfaces(interfaces: &[NetworkInterface]) {
    println!("\nPlease select the adapter used to connect to the Internet:");
    for (i, iface) in interfaces.iter().enumerate() {
        println!("  {}. {}\t ip address: {}", i + 1, iface.name, iface.address);
    }
    println!();
}

fn select_interface(interfaces: &[NetworkInterface], app_dir: &Path) -> Result<String> {
    let stdin = io::stdin();
    loop {
        print!("Enter the adapter number: ");
        io::stdout().flush()?;

        let mut line = String::new();
        stdin.lock().read_line(&mut line)?;

        match line.trim().parse::<usize>() {
            Ok(idx) if idx >= 1 && idx <= interfaces.len() => {
                let sel = &interfaces[idx - 1];
                println!("\nYou have selected \"{} - {}\"\n", sel.name, sel.address);
                save_ip_to_file(app_dir, &sel.address);
                return Ok(sel.address.clone());
            }
            _ => println!("Invalid input, please try again."),
        }
    }
}

fn save_ip_to_file(app_dir: &Path, ip: &str) {
    let path = app_dir.join("ip.txt");
    if let Err(_) = fs::write(&path, ip) {
        println!("Warning: Error while saving the IP address.");
    }
}
