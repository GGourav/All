//! capture/command.rs - stub placeholder
