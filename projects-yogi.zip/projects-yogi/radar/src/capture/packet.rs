//! capture/packet.rs - stub placeholder
