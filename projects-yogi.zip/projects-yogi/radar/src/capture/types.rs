//! capture/types.rs - stub placeholder
