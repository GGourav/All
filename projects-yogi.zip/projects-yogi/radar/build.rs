fn main() {
    // Inject build timestamp so main.rs can access it via env!("BUILD_TIME")
    let build_time = std::env::var("SOURCE_DATE_EPOCH")
        .ok()
        .and_then(|s| s.parse::<u64>().ok())
        .map(|epoch| {
            // Format as ISO-8601 date string from epoch seconds
            let secs  = epoch % 60;
            let mins  = (epoch / 60) % 60;
            let hours = (epoch / 3600) % 24;
            let days  = epoch / 86400;
            // Simple approximation — use chrono in real projects
            format!("epoch+{}d {:02}:{:02}:{:02}Z", days, hours, mins, secs)
        })
        .unwrap_or_else(|| "unknown".to_string());

    println!("cargo:rustc-env=BUILD_TIME={}", build_time);

    // Re-run if SOURCE_DATE_EPOCH changes
    println!("cargo:rerun-if-env-changed=SOURCE_DATE_EPOCH");
}
